package enums;

public enum TeacherDegree {

	TA, DY, OT;
}

package enums;

public class getEnums {
	public static StudentDegree getStudentDegree(String s) {
		StudentDegree studentDegree = StudentDegree.BACHELOR;
		switch(s) {
		case("Bachelor"): studentDegree = StudentDegree.BACHELOR;
		break;
		case("Master"): studentDegree = StudentDegree.MASTER;
		break;
		case("Doctorate"): studentDegree = StudentDegree.DOCTORATE;
		break;
		}
		return studentDegree;
	}
	
	public static TeacherDegree getTeacherDegree(String s) {
	TeacherDegree td = TeacherDegree.OT;
	switch(s) {
	case("TA"): td = TeacherDegree.TA;
	break;
	case("OT"): td = TeacherDegree.OT;
	break;
	case("DY"): td = TeacherDegree.DY;
	break;
	}
	return td;
	}
	
	
	
}

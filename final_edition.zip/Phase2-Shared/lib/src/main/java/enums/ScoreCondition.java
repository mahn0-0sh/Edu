package enums;

public enum ScoreCondition {

	TEMP, REGISTERED;
}

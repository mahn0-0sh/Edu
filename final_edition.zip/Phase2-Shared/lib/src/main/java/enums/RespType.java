package enums;

public enum RespType {

	PENDING,
	ACCEPTED,
	DENIED, FINAL
}

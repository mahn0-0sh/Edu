package enums;

public enum Departments {

	MATH, CE, EE, CHEM, PHYS;
	
	@Override
	public String toString() {
		switch (this) {
		case MATH: {
			return "Math";
		}
		case CE: {
			return "CE";
		}
		case EE: {
			return "EE";
		}
		case CHEM: {
			return "Chemistry";
		}
		case PHYS: {
			return "Physics";
		}
		default:
			return null;
		}
	}
}

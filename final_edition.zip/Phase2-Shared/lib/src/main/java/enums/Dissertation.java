package enums;
import java.util.Random;
public class Dissertation {

    static String[] array = {"1401/06/01","1401/06/02","1401/06/03","1401/06/04","1401/06/05","1401/06/06","1401/06/07"};
    
    public static String getRandom() {
        int rnd = new Random().nextInt(array.length);
        return array[rnd];
    }

}

package enums;

public enum ReqType {

	TAKE_COURSE,
	ASK_CHAT,
	RECOM, MINOR, WITHDRAW, CHANGE_GROUP, MINOR_FINAL
}

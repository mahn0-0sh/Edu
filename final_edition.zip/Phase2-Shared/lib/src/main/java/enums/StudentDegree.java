package enums;

public enum StudentDegree {

	BACHELOR, MASTER, DOCTORATE;
	
	@Override
	public String toString() {
		switch (this) {
		case BACHELOR: {
			return "Bachelor";
		}
		case MASTER: {
			return "Master";
		}
		case DOCTORATE: {
			return "Doctorate";
		}
		default:
			return null;
		}
	}
}



package enums;

public enum Status {
	STUDYING,
	GRADUATE,
	WITHDRAWN;
	
	
	@Override
	public String toString() {
		switch (this) {
		case STUDYING: {
			return "Studying";
		}
		case GRADUATE: {
			return "Graduate";
		}
		case WITHDRAWN: {
			return "Withdrawn";
		}
		default:
			return "null";
		}
	}
	
}




package phase2.shared;

import shared.model.*;

public class ScoresValidation {
	
	public static boolean isValidScore(String s) {
		if(s.equals("")) return false;
		try {
			double a = Double.parseDouble(s);
			
			if(a<0 || a>20) {
				return false;
			} else {
				return true;
			}
			
			
		} catch (Exception e) {
			return false;
		}
	}
	
	public static double getStandardScore(double a) {
		int aInt = (int) a;
		double d = a-(double)aInt;
		double fin = a;
		if(d==0) {
			fin = aInt;
		}
		else if(d-0.25<0) {
			fin = aInt+0.25;
		}	
		else if(0<d-0.25 && d-0.25<0.25) {
			fin = aInt+0.5;
		}	
		else if(0.25<d-0.25 && d-0.25<0.5) {
			fin = aInt+0.75;
		}		
		else if(0.5<d-0.25 && d-0.25<0.75) {
			fin = aInt+1;
		}
		return fin;
	}
	
	
}

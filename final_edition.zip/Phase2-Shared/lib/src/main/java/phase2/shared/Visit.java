package phase2.shared;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import shared.model.Person;

public class Visit {

	
	public static boolean isVisitDiffMoreThan3(String last_visit) {
		try {	
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
			LocalDateTime now = LocalDateTime.now(); 
			LocalDateTime lastVisitTime = LocalDateTime.parse(last_visit, dtf);
			
			LocalDateTime from = lastVisitTime;
	        LocalDateTime to = now;
	        Duration duration = Duration.between(from, to);
	        
	        int mins = (int) duration.toMinutes();
	        if(mins>=180) {
	        	return true;
	        } else {
	        	return false;
	        }
		} catch(Exception e) {
			return true;
		}
	}
	
	
}


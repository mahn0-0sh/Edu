package shared.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import enums.Departments;
import shared.model.Teacher;

public class ObjectUtil {

	private static final GsonBuilder gsonBuilder = new GsonBuilder();
    private static final Gson gson = gsonBuilder.setPrettyPrinting().create();
    
    public static Teacher JsonToTeacher(String json) {
		return gson.fromJson(json, Teacher.class);
	}
    
}

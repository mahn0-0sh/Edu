package shared.util;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import enums.Departments;
import shared.model.Chat;
import shared.model.Course;
import shared.model.Message;
import shared.model.MiniCourse;
import shared.model.Student;
import shared.model.Teacher;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class ListUtil
{
    private static final GsonBuilder gsonBuilder = new GsonBuilder();
    private static final Gson gson = gsonBuilder.setPrettyPrinting().create();
    

    public static ArrayList<Course> JsonToListCourse(String json)
    {
    	try {
            return new ArrayList<>(Arrays.asList(gson.fromJson(json, Course[].class)));
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
    }
    
    public static ArrayList<Student> JsonToListStudent(String json)
    {
    	try {
            return new ArrayList<>(Arrays.asList(gson.fromJson(json, Student[].class)));
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
    }
    
    public static ArrayList<String> JsonToListString(String json)
    {
    	try {
            return new ArrayList<>(Arrays.asList(gson.fromJson(json, String[].class)));
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
    }
    
    public static ArrayList<Double> JsonToListDouble(String json)
    {
    	try {
            return new ArrayList<>(Arrays.asList(gson.fromJson(json, Double[].class)));
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
    }

	public static ArrayList<Integer> JsonToListInt(String json) {
		try {
            return new ArrayList<>(Arrays.asList(gson.fromJson(json, Integer[].class)));
	    } catch (Exception e) {
		// TODO: handle exception
		    return null;
	    }
	}
	
	public static HashMap<String, Integer> JsonToHashMap(String json) {
		try {
			Map<String, Integer> map = new Gson().fromJson(
					json, new TypeToken<HashMap<String, Integer>>() {}.getType()
					);
			return (HashMap<String, Integer>) map;
	    } catch (Exception e) {
		    return null;
	    }
	}
	
	
	public static HashMap<String, Double> JsonToHashMapDouble(String json) {
		try {
			Map<String, Double> map = new Gson().fromJson(
					json, new TypeToken<HashMap<String, Double>>() {}.getType()
					);
			return (HashMap<String, Double>) map;
	    } catch (Exception e) {
		    return null;
	    }
	}
	
	

	public static HashMap<Integer, Integer> JsonToHashMapInteger(String json) {
		try {
			Map<Integer, Integer> map = new Gson().fromJson(
					json, new TypeToken<HashMap<Integer, Integer>>() {}.getType()
					);
			return (HashMap<Integer, Integer>) map;
	    } catch (Exception e) {
		    return null;
	    }
	}
	
	
	public static HashMap<MiniCourse, String> JsonToHashMapCourse(String json) {
		try {
			Map<MiniCourse, String> map = new Gson().fromJson(
					json, new TypeToken<HashMap<MiniCourse, String>>() {}.getType()
					);
			return (HashMap<MiniCourse, String>) map;
	    } catch (Exception e) {
	    	e.printStackTrace();
		    return null;
	    }
	}

	public static HashMap<String, ArrayList<Integer>> JsonToHashMapList(String json) {
		try {
			Map<String,  ArrayList<Integer>> map = new Gson().fromJson(
					json, new TypeToken<HashMap<String,  ArrayList<Integer>>>() {}.getType()
					);
			return (HashMap<String, ArrayList<Integer>>) map;
	    } catch (Exception e) {
	    	System.out.println(e +"popopodasij");
		    return null;
	    }
	}

	public static MiniCourse getMiniCourse(String course) {
		try {
			MiniCourse miniCourse = gson.fromJson(course, MiniCourse.class);
			return miniCourse;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	public static Chat getChat(String json) {
		try {
			Chat chat = gson.fromJson(json, Chat.class);
			return chat;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	public static Student getStudent(String json) {
		try {
			Student chat = gson.fromJson(json, Student.class);
			return chat;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}
	
	
	public static Teacher getTeacher(String json) {
		try {
			Teacher chat = gson.fromJson(json, Teacher.class);
			return chat;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	public static LinkedList<Message> JsonToListMessage(String json) {
		try {
            return new LinkedList<>(Arrays.asList(gson.fromJson(json, Message[].class)));
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
	}
	
	public static LinkedList<MiniCourse> JsonToListCourses(String json) {
		try {
            return new LinkedList<>(Arrays.asList(gson.fromJson(json, MiniCourse[].class)));
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
	}

	public static Message getMessage(String json) {
		try {
			Message chat = gson.fromJson(json, Message.class);
			return chat;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	
	
    
    
    
    
    
}
package shared.util;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.SQLException;

import javax.swing.JFileChooser;

import shared.util.extra.FileUtil;

public class FileStuff {

	public static void writeFile(String base64) { 
		byte[] decoded = FileUtil.decode(base64);
		JFileChooser fileChooser = new JFileChooser();
		
		if(fileChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			
			try {
				FileOutputStream fos = new FileOutputStream(file+".pdf");
				fos.write(decoded);
				fos.flush();
				fos.close();
				System.out.println("File saved!");
			} catch (Exception e) {
				System.out.println("Failed to save file.");
			}
		}
	}
	
	
	public static void writeFile(String base64, String ext) { 
		byte[] decoded = FileUtil.decode(base64);
		JFileChooser fileChooser = new JFileChooser();
		
		if(fileChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			
			try {
				FileOutputStream fos = new FileOutputStream(file+""+ext);
				fos.write(decoded);
				fos.flush();
				fos.close();
				System.out.println("File saved!");
			} catch (Exception e) {
				System.out.println("Failed to save file.");
				System.err.println(e);
			}
		}
	}
	
	
	public static String[] chooseFile() {
		JFileChooser fileChooser = new JFileChooser(".");
		int r = fileChooser.showOpenDialog(null);
		String path = "";
		String extension = "";
		if (r == JFileChooser.APPROVE_OPTION) {
			path = fileChooser.getSelectedFile().getAbsolutePath();
			
			if(path.endsWith(".png")) extension = ".png";			
			else if(path.endsWith(".jpg")) extension = ".jpg";
			else if(path.endsWith(".pdf")) extension = ".pdf"; //TODO complete exts
			else if(path.endsWith(".mp3")) extension = ".mp3";
			else if(path.endsWith(".mkv")) extension = ".mkv";
			else if(path.endsWith(".mp4")) extension = ".mp4";
		}
		
		String encode = "";
		if(path != "") {
		    encode = FileUtil.encode(path);
		}
		String[] s = new String[2];
		s[0] = encode;
		s[1] = extension;
		return s;
	}

	
}

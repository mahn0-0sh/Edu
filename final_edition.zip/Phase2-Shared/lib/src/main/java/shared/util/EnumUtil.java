package shared.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import enums.*;

public class EnumUtil {
	    private static final GsonBuilder gsonBuilder = new GsonBuilder();
	    private static final Gson gson = gsonBuilder.setPrettyPrinting().create();
	    
	    public static Departments JsonToDepartments(String json) {
			return gson.fromJson(json, Departments.class);
		}
	    
	    public static Status JsonToStatus(String json) {
			return gson.fromJson(json, Status.class);
		}
	    
	    public static StudentDegree JsonToStuDegree(String json) {
			return gson.fromJson(json, StudentDegree.class);
		}
	    
	    public static TeacherDegree JsonToTeachDegree(String json) {
	    	return gson.fromJson(json, TeacherDegree.class);
		}
	    
	    public static ReqType JsonToReqType(String json) {
	    	return gson.fromJson(json, ReqType.class);
		}
	    
	    public static RespType JsonToRespType(String json) {
	    	return gson.fromJson(json, RespType.class);
		}
}

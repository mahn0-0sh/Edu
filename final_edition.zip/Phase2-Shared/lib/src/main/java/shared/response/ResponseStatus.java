package shared.response;

public enum ResponseStatus {
    OK,
    ERROR,
    STU,
    TEACHER,
    FIL_FULL, 
    FIL_DEP, 
    DEP_GROUP, 
    COURSE_STATUS, 
    PRE_ERR, 
    EX_MIX, 
    CAPACITY, 
    CL_MIX,
    MAAREF, 
    FIL_DEG, 
    FIL_CRE, 
    ALIVE, 
    SAME_COURSE
}

package shared.model;

import java.util.ArrayList;

public class MsgAnnounce {

	private int id;
	private String text;
	private ArrayList<String> rec_ids;
	
	
	public MsgAnnounce(String text, ArrayList<String> rec_ids) {
		super();
		this.text = text;
		this.rec_ids = rec_ids;
	}
	
	public MsgAnnounce() {}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public ArrayList<String> getRec_ids() {
		return rec_ids;
	}

	public void setRec_ids(ArrayList<String> rec_ids) {
		this.rec_ids = rec_ids;
	}

	
	
	
	
}

package shared.model;

import java.util.HashMap;

public class Exercise {

	private int id;
	private String mini_id;
	private String name;
	private String explaination;
	private String open_time;
	private String close_time;
	private String mohlat;
	private String allowed_type; // text, media, both
	private String pdf;
	private HashMap<String, Integer> uploaded = new HashMap<>();  // student -> media
	private HashMap<String, Double> scores;  // student -> score
	
	
	
	
	
	
	public Exercise(String mini_id, String name, String explaination, String open_time, String close_time, String mohlat,
			String allowed_type, String pdf, HashMap<String, Integer> uploaded, HashMap<String, Double> scores) {
		super();
		this.mini_id = mini_id;
		this.name = name;
		this.explaination = explaination;
		this.open_time = open_time;
		this.close_time = close_time;
		this.mohlat = mohlat;
		this.allowed_type = allowed_type;
		this.pdf = pdf;
		this.uploaded = uploaded;
		this.scores = scores;
	}






	public Exercise() {
		// TODO Auto-generated constructor stub
	}






	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMini_id() {
		return mini_id;
	}
	public void setMini_id(String mini_id) {
		this.mini_id = mini_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getExplaination() {
		return explaination;
	}
	public void setExplaination(String explaination) {
		this.explaination = explaination;
	}
	public String getOpen_time() {
		return open_time;
	}
	public void setOpen_time(String open_time) {
		this.open_time = open_time;
	}
	public String getClose_time() {
		return close_time;
	}
	public void setClose_time(String close_time) {
		this.close_time = close_time;
	}
	public String getAllowed_type() {
		return allowed_type;
	}
	public void setAllowed_type(String allowed_type) {
		this.allowed_type = allowed_type;
	}
	public String getPdf() {
		return pdf;
	}
	public void setPdf(String pdf) {
		this.pdf = pdf;
	}
	public HashMap<String, Integer> getUploaded() {
		return uploaded;
	}
	public void setUploaded(HashMap<String, Integer> uploaded) {
		this.uploaded = uploaded;
	}
	public HashMap<String, Double> getScores() {
		return scores;
	}
	public void setScores(HashMap<String, Double> scores) {
		this.scores = scores;
	}






	public String getMohlat() {
		return mohlat;
	}






	public void setMohlat(String mohlat) {
		this.mohlat = mohlat;
	}
	
	
	
	
	
}
package shared.model;

public class Exam {

}

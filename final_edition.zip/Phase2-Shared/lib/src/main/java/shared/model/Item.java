package shared.model;

public class Item {
	
	private int id;
	private int subj_id;
	private String type; // text, file
	private String base64;
	private String text;
	
	
	
	public Item(int subj_id, String type, String base64, String text) {
		super();
		this.subj_id = subj_id;
		this.type = type;
		this.base64 = base64;
		this.text = text;
	}
	
	
	
	public Item() {
		// TODO Auto-generated constructor stub
	}



	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSubj_id() {
		return subj_id;
	}
	public void setSubj_id(int subj_id) {
		this.subj_id = subj_id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getBase64() {
		return base64;
	}
	public void setBase64(String base64) {
		this.base64 = base64;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}

	
}

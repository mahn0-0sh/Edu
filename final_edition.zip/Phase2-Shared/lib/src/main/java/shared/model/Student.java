package shared.model;

import java.util.ArrayList;
import java.util.HashMap;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import enums.Status;
import enums.StudentDegree;

@JsonIgnoreProperties(ignoreUnknown = true)

public class Student extends Person{

	private ArrayList<String> coursesList = new ArrayList<>(); 
	private ArrayList<Double> scoresList = new ArrayList<Double>();
	private ArrayList<String> tempCoursesList = new ArrayList<>();
	private ArrayList<Double> tempScoresList = new ArrayList<Double>();
	private ArrayList<String> coursesProtested = new ArrayList<>();
	private ArrayList<String> coursesFeedbacks = new ArrayList<>();
	private ArrayList<String> recomReqTeachers = new ArrayList<>();
	private ArrayList<String> recomFeedbacks = new ArrayList<>();
	private ArrayList<String> minorReqDepartments = new ArrayList<>();
	private ArrayList<String> minorReqFeedbacks = new ArrayList<>();
	private ArrayList<String> checked = new ArrayList<>();
	private ArrayList<String> chosen = new ArrayList<>();
	private String department;
	private String supervisor;
	private String yearOfArrival; //TODO int
	private String mojavez;
	private String signUpTime;
	private String withdrawalFeedback;
	private StudentDegree degree;
	private Status status;
	private HashMap<String, Integer> passed = new HashMap<>(); // ID -> Score
	private HashMap<Integer, Integer> exercises = new HashMap<>(); // Exc -> Score
	
	
	public Student() {}
	
	public Student(String position, String username, String password, String firstName, String lastName, String email,
			String phoneNumber, String iD, String code, String lastVisit, String lastExit, String lastPassChange) {
		super(position, username, password, firstName, lastName, email, phoneNumber, iD, code, lastVisit, lastExit, lastPassChange);
	}
	
/*	public Student(String position, String username, String password, String name, String lastname, String email,
			String phoneNumber, String code,
			StudentDegree degree, String id) {
		super(position, username, password, name, lastname, email, phoneNumber, code);
		status = Status.STUDYING;
		this.setDegree(degree);
		this.ID = id;
	} */
	
	

	public ArrayList<String> getChecked() {
		return checked;
	}

	public void setChecked(ArrayList<String> checked) {
		this.checked = checked;
	}

	public ArrayList<String> getChosen() {
		return chosen;
	}

	public void setChosen(ArrayList<String> chosen) {
		this.chosen = chosen;
	}

	public Student(String position, String username, String password, String firstname, String lastname, String email,
			String phoneNumber,String id, String code, String lastVisit, String lastExit, String lastPass,
			ArrayList<String> coursesList, ArrayList<Double> scoresList, ArrayList<String> tempCoursesList,
			ArrayList<Double> tempScoresList, String department, StudentDegree degree, Status status,
			String supervisor, String yearOfArrival, String mojavez, String signUpTime, String withdrawalFeedback,
			ArrayList<String> coursesProtested, ArrayList<String> coursesFeedbacks, ArrayList<String> recomReqTeachers,
			ArrayList<String> recomFeedbacks, ArrayList<String> minorReqDepartments,
			ArrayList<String> minorReqFeedbacks, ArrayList<String> checked, ArrayList<String> chosen,
			HashMap<String, Integer> passed) {
		super(position, username, password, firstname, lastname, email, phoneNumber, id, code, lastVisit, lastExit, lastPass);
		this.coursesList = coursesList;
		this.scoresList = scoresList;
		this.tempCoursesList = tempCoursesList;
		this.tempScoresList = tempScoresList;
		this.department = department;
		this.degree = degree;
		this.status = status;
		this.supervisor = supervisor;
		this.yearOfArrival = yearOfArrival;
		this.mojavez = mojavez;
		this.signUpTime = signUpTime;
		this.withdrawalFeedback = withdrawalFeedback;
		this.coursesProtested = coursesProtested;
		this.coursesFeedbacks = coursesFeedbacks;
		this.recomReqTeachers = recomReqTeachers;
		this.recomFeedbacks = recomFeedbacks;
		this.minorReqDepartments = minorReqDepartments;
		this.minorReqFeedbacks = minorReqFeedbacks;
		this.checked = checked;
		this.chosen = chosen;
		this.passed = passed;
		
		try {
			checked.size();
		} catch (Exception e) {
			checked = new ArrayList<>();
		}
		
		try {
			chosen.size();
		} catch (Exception e) {
			chosen = new ArrayList<>();
		}
	}
	
	public Student(String position, String username, String password, String firstname, String lastname, String email,
			String phoneNumber,String id, String code, String department, StudentDegree degree,	String supervisor, String yearOfArrival) {
		super(position, username, password, firstname, lastname, email, phoneNumber, id, code, null, null, null);
		
		this.department = department;
		this.degree = degree;
		this.supervisor = supervisor;
		this.yearOfArrival = yearOfArrival;
	}

/*	public String getTempScore(Course course) {
		for(int i=0; i<tempCoursesList.size(); i++) {
			if(tempCoursesList.get(i).equals(course.getCourseID())) {
				return tempScoresList.get(i)+"";
			}
		}
		return null;
	}

	
	public int getCourseIndex(Course course) {
		int a=0;
		for(int i=0; i<coursesList.size(); i++) {
			if(coursesList.get(i).equals(course.getCourseID())) a=i;
		}
		return a;
	} */
	
	
	public void changeRecomReqStatus(String teacherID, String status) {
		for(int i=0; i<recomReqTeachers.size(); i++) {
			if(recomReqTeachers.get(i).equals(teacherID)) {
				recomFeedbacks.set(i, status);
			}
		}
	}
	
	public void changeMinorReqStatus(String department, String status) {
		for(int i=0; i<minorReqDepartments.size(); i++) {
			if(minorReqDepartments.get(i).equals(department)) {
				minorReqFeedbacks.set(i, status);
			}
		}
	}
	
	
	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

	
	

	
	public boolean isAllowedToMinor() {
		return false;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}

	public String getYearOfArrival() {
		return yearOfArrival;
	}

	public void setYearOfArrival(String yearOfArrival) {
		this.yearOfArrival = yearOfArrival;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getMojavez() {
		return mojavez;
	}

	public void setMojavez(String mojavez) {
		this.mojavez = mojavez;
	}

	public String getSignUpTime() {
		return signUpTime;
	}

	public void setSignUpTime(String signUpTime) {
		this.signUpTime = signUpTime;
	}

	public StudentDegree getDegree() {
		return degree;
	}

	public void setDegree(StudentDegree degree) {
		this.degree = degree;
	}

	public ArrayList<String> getCoursesList() {
		return coursesList;
	}

	public void setCoursesList(ArrayList<String> coursesList) {
		this.coursesList = coursesList;
	}

	public ArrayList<Double> getScoresList() {
		return scoresList;
	}

	public void setScoresList(ArrayList<Double> scoresList) {
		this.scoresList = scoresList;
	}

	public ArrayList<String> getTempCoursesList() {
		return tempCoursesList;
	}

	public void setTempCoursesList(ArrayList<String> tempCoursesList) {
		this.tempCoursesList = tempCoursesList;
	}

	public ArrayList<Double> getTempScoresList() {
		return tempScoresList;
	}

	public void setTempScoresList(ArrayList<Double> tempScoresList) {
		this.tempScoresList = tempScoresList;
	}

	public String getWithdrawalFeedback() {
		return withdrawalFeedback;
	}

	public void setWithdrawalFeedback(String withdrawalFeedback) {
		this.withdrawalFeedback = withdrawalFeedback;
	}

	public ArrayList<String> getCoursesProtested() {
		return coursesProtested;
	}

	public void setCoursesProtested(ArrayList<String> coursesProtested) {
		this.coursesProtested = coursesProtested;
	}

	public ArrayList<String> getCoursesFeedbacks() {
		return coursesFeedbacks;
	}

	public void setCoursesFeedbacks(ArrayList<String> coursesFeedbacks) {
		this.coursesFeedbacks = coursesFeedbacks;
	}

	public ArrayList<String> getRecomReqTeachers() {
		return recomReqTeachers;
	}

	public void setRecomReqTeachers(ArrayList<String> recomReqTeachers) {
		this.recomReqTeachers = recomReqTeachers;
	}

	public ArrayList<String> getRecomFeedbacks() {
		return recomFeedbacks;
	}

	public void setRecomFeedbacks(ArrayList<String> recomFeedbacks) {
		this.recomFeedbacks = recomFeedbacks;
	}

	public ArrayList<String> getMinorReqDepartments() {
		return minorReqDepartments;
	}

	public void setMinorReqDepartments(ArrayList<String> minorReqDepartments) {
		this.minorReqDepartments = minorReqDepartments;
	}

	public ArrayList<String> getMinorReqFeedbacks() {
		return minorReqFeedbacks;
	}

	public void setMinorReqFeedbacks(ArrayList<String> minorReqFeedbacks) {
		this.minorReqFeedbacks = minorReqFeedbacks;
	}

	public HashMap<String, Integer> getPassed() {
		return passed;
	}

	public void setPassed(HashMap<String, Integer> passed) {
		this.passed = passed;
	}

	
	public void addToMinor(String depString) {
		try {
			int q = minorReqDepartments.size();
			int p = minorReqFeedbacks.size();
		} catch (Exception e1) {
			minorReqDepartments = new ArrayList<String>();
			minorReqFeedbacks = new ArrayList<String>();
		}		
		minorReqDepartments.add(depString);
		minorReqFeedbacks.add("PENDING");
	} 

	public void addToProtested(String mini_id) {
		try {
			coursesProtested.size();
		} catch (Exception e) {
			coursesProtested = new ArrayList<>();
		}
		coursesProtested.add(mini_id);
		
		try {
			coursesFeedbacks.size();
		} catch (Exception e) {
			coursesFeedbacks = new ArrayList<>();
		}
		coursesFeedbacks.add("PENDING");
	}

	public void changeProtestStat(String mini_id, String stat) {
		try {
			for(int i=0; i<coursesProtested.size(); i++) {
				if(coursesProtested.get(i).equals(mini_id)) {
					coursesFeedbacks.set(i, stat);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public String getProtestStatus(String mini_id) {
		String stat = "";
		try {
			for(int i=0; i<coursesProtested.size(); i++) {
				if(coursesProtested.get(i).equals(mini_id)) {
					stat = getName() +" -> "+ coursesFeedbacks.get(i);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return stat;
	}
	

	
    
    
    
    
    
    
    
}

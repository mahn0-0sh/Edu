package shared.model;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

public class Message {
	private int id;
	private String text;
	private String base64 = "";
	private int chatID;
	private String senderID;
	private String timeSent;
	// Time sent
	
	public int getId() {
		return id;
	}
	
	public Message() {}
	
	public Message(String text, String base64, int chatID, String senderID) {
		this.text = text;
		this.base64 = base64;
		this.chatID = chatID;
		this.senderID = senderID;
	}
	public String getTimeSent() {
		return timeSent;
	}
	public void setTimeSent(String timeSent) {
		this.timeSent = timeSent;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getChatID() {
		return chatID;
	}
	public void setChatID(int chatID) {
		this.chatID = chatID;
	}
	public String getSenderID() {
		return senderID;
	}
	public void setSenderID(String senderID) {
		this.senderID = senderID;
	}

	public String getBase64() {
		return base64;
	}

	public void setBase64(String base64) {
		this.base64 = base64;
	}
	
	

}

package shared.model;

import java.util.ArrayList;

import enums.Departments;

public class Person {
	private String position;
	private String username;
	private String password;
	private String firstName;
	private String lastName;
	private String email;
	private String phoneNumber;
	private String ID;
	private String code;
	private String lastVisit;
	private String lastExit;
	private String lastPassChange;
	private String base64;
	
	
	
	
	public Person() {
	}
	
    public Person(String position, String username, String password, String name,String lastname, String email, String phoneNumber, String code) {
		super();
		this.position = position;
		this.username = username;
		this.password = password;
		this.firstName = name;
		this.lastName = lastname;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.code = code;
	}

    public Person(String position, String username, String password, String firstName, String lastName, String email,
			String phoneNumber, String iD, String code, String lastVisit, String lastExit, String lastPassChange) {
		super();
		this.position = position;
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		ID = iD;
		this.code = code;
		this.lastVisit = lastVisit;
		this.lastExit = lastExit;
		this.lastPassChange = lastPassChange;
	}

    
	
    
	public String getPosition() {
		return position;
	}


	public void setPosition(String position) {
		this.position = position;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getID() {
		return ID;
	}


	public void setID(String iD) {
		ID = iD;
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getLastVisit() {
		return lastVisit;
	}


	public void setLastVisit(String lastVisit) {
		this.lastVisit = lastVisit;
	}


	public String getLastPassChange() {
		return lastPassChange;
	}


	public void setLastPassChange(String lastPassChange) {
		this.lastPassChange = lastPassChange;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
    
    
    public String getName() {
    	return this.getFirstName()+" "+this.getLastName();
    }

	public String getLastExit() {
		return lastExit;
	}

	public void setLastExit(String lastExit) {
		this.lastExit = lastExit;
	}

	public String getBase64() {
		return base64;
	}

	public void setBase64(String base64) {
		this.base64 = base64;
	}
    
    
    
     
    
}

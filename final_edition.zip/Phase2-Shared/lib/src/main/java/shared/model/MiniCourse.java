package shared.model;

import java.util.ArrayList;
import java.util.HashMap;

import enums.StudentDegree;

public class MiniCourse extends Course {
	
	private String courseID;
	private int group;
	private String teacher;
	private ArrayList<String> tAssisstants = new ArrayList<>();
	private String classDay;
	private String classTime; // 13-15
	private String miniCourseID;
	private int capacity;
	private ArrayList<String> protestedStudents = new ArrayList<>();
	
	public int getGroup() {
		return group;
	}
	
	
	public MiniCourse() {}
	
	
	public MiniCourse(String courseID, String name, int courseCredit, ArrayList<String> preID, ArrayList<String> conID,
			String department, StudentDegree courseDegree, String examDate, String examTime, String teacher, String classDay,
			String classTime, int group, int capacity) {
		super(courseID, name, courseCredit, preID, conID, department, courseDegree, examDate, examTime);
		this.courseID = courseID;
		this.group = group;
		this.teacher = teacher;
		this.classDay = classDay;
		this.classTime = classTime;
		this.miniCourseID = courseID+"-"+group;
		this.capacity = capacity;
	}
	
	
	
	public MiniCourse(String courseID, String teacher, String classDay,
			String classTime, int group) {
		this.courseID = courseID;
		this.group = group;
		this.teacher = teacher;
		this.classDay = classDay;
		this.classTime = classTime;
		this.miniCourseID = courseID+"-"+group;
	}






	public void setGroup(int group) {
		this.group = group;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
	public ArrayList<String> gettAssisstants() {
		return tAssisstants;
	}
	public void settAssisstants(ArrayList<String> tAssisstants) {
		this.tAssisstants = tAssisstants;
	}
	public String getClassDay() {
		return classDay;
	}
	public void setClassDay(String classDay) {
		this.classDay = classDay;
	}
	public String getClassTime() {
		return classTime;
	}
	public void setClassTime(String classTime) {
		this.classTime = classTime;
	}
	public String getCourseID() {
		return courseID;
	}
	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
	public String getMiniCourseID() {
		return miniCourseID;
	}
	public void setMiniCourseID(String miniCourseID) {
		this.miniCourseID = miniCourseID;
	}


	public int getCapacity() {
		return capacity;
	}


	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	

	public ArrayList<String> getProtestedStudents() {
		return protestedStudents;
	}


	public void setProtestedStudents(ArrayList<String> protestedStudents) {
		this.protestedStudents = protestedStudents;
	}


	public void addToProtested(String id) {
		try {
			protestedStudents.size();
		} catch (Exception e) {
			protestedStudents = new ArrayList<>();
		}
		protestedStudents.add(id);
	}


	public void removeProtest(String id) {
		for(int i=0; i<protestedStudents.size(); i++) {
			if(protestedStudents.get(i).equals(id)) protestedStudents.remove(i);
		}
	}

	
}

package shared.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import enums.Departments;
import enums.StudentDegree;
import shared.model.*;

public class Course {

	private int courseCredit;
	private String course_ID;
	private String name;
	private String department;
	private String examDate;
	private String examTime;
	private StudentDegree courseDegree;
	private ArrayList<String> preID = new ArrayList<>();
	private ArrayList<String> conID = new ArrayList<>();
	
	
	
	
	
	
	


	public Course(String courseID, String name, int courseCredit, ArrayList<String> preID, ArrayList<String> conID,
		String department, StudentDegree courseDegree, String examDate, String examTime) {
	super();
	this.course_ID = courseID;
	this.name = name;
	this.courseCredit = courseCredit;
	this.preID = preID;
	this.conID = conID;
	this.department = department;
	this.courseDegree = courseDegree;
	this.examDate = examDate;
	this.examTime = examTime;
}



	public String preString() {
		String string = "";
		try {
			for (int i = 0; i < preID.size(); i++) {
				string += preID.get(i)+"/";
			}
		} catch (Exception e) {
			
		}
		return string;
	}
	public String conString() {
		String string = "";
		try {
			for (int i = 0; i < conID.size(); i++) {
				string += conID.get(i)+"/";
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return string;
	}

	
	
	public Course() {
		// TODO Auto-generated constructor stub
	}

	public String courseExam() {
		return examDate+" - "+examTime;
	}
	
	

	public int getCourseCredit() {
		return courseCredit;
	}

	public void setCourseCredit(int courseCredit) {
		this.courseCredit = courseCredit;
	}

	
	public StudentDegree getCourseDegree() {
		return courseDegree;
	}

	public void setCourseDegree(StudentDegree courseDegree) {
		this.courseDegree = courseDegree;
	}

	public String getCourseID() {
		return course_ID;
	}

	public void setCourseID(String courseID) {
		this.course_ID = courseID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getExamDate() {
		return examDate;
	}

	public void setExamDate(String examDate) {
		this.examDate = examDate;
	}

	public String getExamTime() {
		return examTime;
	}

	public void setExamTime(String examTime) {
		this.examTime = examTime;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}



	public ArrayList<String> getPreID() {
		return preID;
	}





	public void setPreID(ArrayList<String> preID) {
		this.preID = preID;
	}


	public ArrayList<String> getConID() {
		return conID;
	}



	public void setConID(ArrayList<String> conID) {
		this.conID = conID;
	}


	public void addToPre(String data) {
		preID.add(data);
	}



	public void addToCon(String data) {
		conID.add(data);
	}


}

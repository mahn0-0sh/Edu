package shared.model;

import java.util.ArrayList;
import java.util.List;

public class Chat {
	int id;
	String name;
	String user_one;
	String user_two;
	List<Integer> messages = new ArrayList<>(); // Ids
	String lastTime;
	

	public Chat() {}
	
	
	public void addToMessages(int id) {
		List<Integer> msg = getMessages();
		try {
			msg.size();
		} catch (Exception e) {
			msg = new ArrayList<>();
		}
		msg.add(id);
		setMessages(msg);
	}
	
	
	


	public Chat(String name, String user_one, String user_two, List<Integer> messages) {
		this.name = name;
		this.user_one = user_one;
		this.user_two = user_two;
		this.messages = messages;
		
		try {
			messages.size();
		} catch (Exception e) {
			messages = new ArrayList<>();
		}
	}



	

	public String getLastTime() {
		return lastTime;
	}


	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}


	public String getUser_one() {
		return user_one;
	}




	public void setUser_one(String user_one) {
		this.user_one = user_one;
	}




	public String getUser_two() {
		return user_two;
	}




	public void setUser_two(String user_two) {
		this.user_two = user_two;
	}




	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}




	public List<Integer> getMessages() {
		return messages;
	}


	public void setMessages(List<Integer> messages) {
		this.messages = messages;
	}
	
	
}

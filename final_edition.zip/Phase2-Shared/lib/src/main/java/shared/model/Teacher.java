package shared.model;

import java.util.ArrayList;
import java.util.Collections;

import enums.Departments;
import enums.TeacherDegree;

public class Teacher extends Person{

	 private ArrayList<String> incomMinorReqStudents = new ArrayList<>();
	 private ArrayList<String> outgoMinorReqStudents = new ArrayList<>();
	 private ArrayList<String> scoresRegByTeacher = new ArrayList<>();
	 private ArrayList<String> recomReqStudents = new ArrayList<>();
	 private ArrayList<String> withdrawReqStudents = new ArrayList<>();
	 private String department;
	 private String room;
	 private TeacherDegree teacherDegree;
	 
	 
	
	public Teacher(String position, String username, String password, String name, String lastname, String email,
			String phoneNumber, String code, String department,TeacherDegree teacherDegree, String room, String id) {
		
		super(position, username, password, name, lastname, email, phoneNumber, code);
		this.department = department;
		this.teacherDegree = teacherDegree;
		this.room = room;
	}
	
	public Teacher(String position, String username, String password, String firstName, String lastName, String email,
			String code, String id, String code2, String lastVisit, String lastExit, String lastPassChange) {
		// TODO Auto-generated constructor stub
		super(position, username, password, firstName, lastName, email, code, id, code2, lastVisit, lastExit, lastPassChange);
	}
	
	

	public Teacher(String position, String username, String password, String firstname, String lastname, String email,
			String phoneNumber,String id, String code, String lastVisit, String lastExit, String lastPass
			,ArrayList<String> incomMinorReqStudents, ArrayList<String> outgoMinorReqStudents,
			ArrayList<String> scoresRegByTeacher, ArrayList<String> recomReqStudents,
			ArrayList<String> withdrawReqStudents, String department, TeacherDegree teacherDegree, String room) {
		
		super(position, username, password, firstname, lastname, email, phoneNumber, id, code, lastVisit, lastExit, lastPass);
		this.incomMinorReqStudents = incomMinorReqStudents;
		this.outgoMinorReqStudents = outgoMinorReqStudents;
		this.scoresRegByTeacher = scoresRegByTeacher;
		this.recomReqStudents = recomReqStudents;
		this.withdrawReqStudents = withdrawReqStudents;
		this.department = department;
		this.teacherDegree = teacherDegree;
		this.room = room;
	}
	
	public void acceptRecomReq(String id) {
		for(int i=0; i<recomReqStudents.size(); i++) {
			if(recomReqStudents.get(i).equals(id)) {
				recomReqStudents.remove(i);
				break;
			}
		}
	}
	
	
	public ArrayList<String> getIncomMinorReqStudents() {
		return incomMinorReqStudents;
	}

	public void setIncomMinorReqStudents(ArrayList<String> incomMinorReqStudents) {
		this.incomMinorReqStudents = incomMinorReqStudents;
	}

	public ArrayList<String> getOutgoMinorReqStudents() {
		return outgoMinorReqStudents;
	}

	public void setOutgoMinorReqStudents(ArrayList<String> outgoMinorReqStudents) {
		this.outgoMinorReqStudents = outgoMinorReqStudents;
	}

	public ArrayList<String> getScoresRegByTeacher() {
		return scoresRegByTeacher;
	}

	public void setScoresRegByTeacher(ArrayList<String> scoresRegByTeacher) {
		this.scoresRegByTeacher = scoresRegByTeacher;
	}

	public ArrayList<String> getRecomReqStudents() {
		return recomReqStudents;
	}

	public void setRecomReqStudents(ArrayList<String> recomReqStudents) {
		this.recomReqStudents = recomReqStudents;
	}

	public ArrayList<String> getWithdrawReqStudents() {
		return withdrawReqStudents;
	}

	public void setWithdrawReqStudents(ArrayList<String> withdrawReqStudents) {
		this.withdrawReqStudents = withdrawReqStudents;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public TeacherDegree getTeacherDegree() {
		return teacherDegree;
	}

	public void setTeacherDegree(TeacherDegree teacherDegree) {
		this.teacherDegree = teacherDegree;
	}

	public String getRoom() {
		return room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public void addToRecomStus(String id) {
		try {
			recomReqStudents.size();
		} catch (Exception e) {
			recomReqStudents = new ArrayList<>();
		}
		recomReqStudents.add(id);
	}
	
	
	public void addToOutgoMinor(String string) {
		try {
			outgoMinorReqStudents.size();
		} catch (Exception e) {
			outgoMinorReqStudents = new ArrayList<String>();
		}
		    outgoMinorReqStudents.add(string);
	}
	
}

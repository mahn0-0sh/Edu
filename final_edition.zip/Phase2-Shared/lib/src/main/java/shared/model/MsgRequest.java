package shared.model;

import enums.ReqType;
import enums.RespType;

public class MsgRequest {
	
	private int id;
	private String owner_id;
	private String rec_id;
	private String exp;
	private ReqType type;
	private RespType response;
	
	public MsgRequest() {}
	
	

	public MsgRequest(ReqType type, String exp,String ow_id, String rec_id) {
		super();
		this.type = type;
		this.exp = exp;
		this.owner_id = ow_id;
		this.rec_id = rec_id;
		this.response = RespType.PENDING;
	}

	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return owner_id+"   "+exp+"   "+rec_id+"    "+type;
	}


	public ReqType getType() {
		return type;
	}

	public void setType(ReqType type) {
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public RespType getResponse() {
		return response;
	}

	public void setResponse(RespType response) {
		this.response = response;
	}



	public String getOwner_id() {
		return owner_id;
	}



	public void setOwner_id(String owner_id) {
		this.owner_id = owner_id;
	}



	public String getRec_id() {
		return rec_id;
	}



	public void setRec_id(String rec_id) {
		this.rec_id = rec_id;
	}



	public String getExp() {
		return exp;
	}



	public void setExp(String exp) {
		this.exp = exp;
	}
	
	

}



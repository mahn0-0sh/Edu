package shared.model;


public class Subject {
	
	private int id;
	private String mini_id;
	private String name;
	
	
	
	public Subject(String mini_id, String name) {
		super();
		this.mini_id = mini_id;
		this.name = name;
	}



	public Subject() {
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getMini_id() {
		return mini_id;
	}



	public void setMini_id(String mini_id) {
		this.mini_id = mini_id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}
	
	
	

}

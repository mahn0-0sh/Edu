package constants;

import shared.util.Config;

public class Constants {
    public static final String CONFIG_ADDRESS = System.getProperty("user.dir")+"\\src/main/resources/config.properties";
    //public static final Config CONFIG = new Config(CONFIG_ADDRESS);   "./resources/config.properties" 
    
}

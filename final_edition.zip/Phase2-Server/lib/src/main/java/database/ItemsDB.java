package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

import com.google.gson.Gson;

import shared.model.Exercise;
import shared.model.Item;
import shared.util.ListUtil;

public class ItemsDB {
	
	private static Connection connection;
	static ItemsDB db;
	
	public static ItemsDB getDB()
    {
        if (db == null)
        {
            db = new ItemsDB();
        }
        return db;
    }
	
	public static void setConnection(Connection connection2) {
		connection = connection2;		
	}
	
	
	public Item saveItem(Item item) throws SQLException
    {
        boolean exists = Database.getDB().rowExists("items", item.getId());

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `items` SET `subj_id` = ?, `type` = ?, `base64` = ?, `text` = ?"
                    + "WHERE `id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `items` (`subj_id`, `type`, `base64`, `text`)"
            		+"VALUES (?, ?, ?, ?)");
        }
        statement.setInt(1, item.getSubj_id());
        statement.setString(2, item.getType());
        statement.setString(3, item.getBase64());
        statement.setString(4, item.getText());
        
        if(exists) {
            statement.setInt(5, item.getId());
        } else {
        	item.setId(Database.getDB().getMaxIdValue("items"));
        }
        statement.executeUpdate();
        statement.close();
        
        return loadItem(item.getId());
    }
	
	
	
	public Item loadItem(int id) throws SQLException
    {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `items` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        Item item = new Item();
        while (res.next())
        {
        	item.setId(res.getInt("id"));
        	item.setType(res.getString("type"));
        	item.setSubj_id(res.getInt("subj_id"));
        	item.setBase64(res.getString("base64"));
        	item.setText(res.getString("text"));
        }
        statement.close();
        res.close();
        return item;
    }

	public int getNum(int subj_id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `items` WHERE `subj_id` = ?");
        statement.setInt(1, subj_id);
        ResultSet res = statement.executeQuery();
        
        int num = 0;
        while (res.next())
        {
        	num++;
        }
        statement.close();
        res.close();
        return num;
	}

	public LinkedList<String> getInfos(Integer subj_id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `items` WHERE `subj_id` = ?");
        statement.setInt(1, subj_id);
        ResultSet res = statement.executeQuery();
        
        LinkedList<String> list = new LinkedList<>();
        
        while (res.next())
        {
        	list.add(res.getInt("id")+"/"+res.getString("type"));
        }
        statement.close();
        res.close();
        return list;
	}

	public String getText(Integer id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `items` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        
        String text = "";
        
        while (res.next())
        {
        	text = res.getString("text");
        }
        statement.close();
        res.close();
        return text;
	}

	public String getBase64(Integer id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `items` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        
        String base64 = "";
        
        while (res.next())
        {
        	base64 = res.getString("base64");
        }
        statement.close();
        res.close();
        return base64;
	}

	public void removeItem(Integer id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("DELETE FROM `items` WHERE `id` = ?");
        statement.setInt(1, id);
        statement.executeUpdate();
        statement.close();
	}

	

}

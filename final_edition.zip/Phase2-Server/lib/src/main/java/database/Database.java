package database;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

import com.google.gson.Gson;

import enums.ReqType;
import enums.RespType;
import enums.StudentDegree;
import shared.model.*;
import shared.util.*;

public class Database {
	
	private static Connection connection;
	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
    static Database db;
    private Database() {}
    
    public static Database getDB() {
        if (db == null) db = new Database();
        return db;
    }

    public void connectToDatabase(String url, String username, String password) throws SQLException {
        connection = DriverManager.getConnection(url, username, password);
        Statement statement = connection.createStatement();
        statement.setQueryTimeout(30);
        statement.close();
        
        CourseDB.setConnection(connection);
        ExcDB.setConnection(connection);
        MediaDB.setConnection(connection);
        PersonDB.setConnection(connection);
        SubjDB.setConnection(connection);
        ItemsDB.setConnection(connection);
        MsgDB.setConnection(connection);
    }
    
    public boolean rowIsMissing(String table, String id) throws SQLException {
        String query = "";
        switch (table) {
            case "persons":
                query = "SELECT 1 FROM `persons` WHERE `id` = ?";
                break;
            case "students":
                query = "SELECT 1 FROM `students` WHERE `id` = ?";
                break;
            case "teachers":
                query = "SELECT 1 FROM `teachers` WHERE `id` = ?";
                break;
            case "courses":
                query = "SELECT 1 FROM `courses` WHERE `id` = ?";
                break;
            case "minicourses":
                query = "SELECT 1 FROM `minicourses` WHERE `mini_id` = ?";
                break;
        }
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        boolean ans = !res.next();
        close(statement, res);
        return ans;
    }
    
    public boolean rowExists(String table, int id) throws SQLException {
        String query = "";
        switch (table) {
            case "chats":
                query = "SELECT 1 FROM `chats` WHERE `id` = ?";
                break;
            case "messages":
                query = "SELECT 1 FROM `messages` WHERE `id` = ?";
                break;
            case "exercises":
                query = "SELECT 1 FROM `exercises` WHERE `id` = ?";
                break;
            case "medias":
                query = "SELECT 1 FROM `medias` WHERE `id` = ?";
                break;
            case "subjects":
                query = "SELECT 1 FROM `subjects` WHERE `id` = ?";
                break;
            case "items":
                query = "SELECT 1 FROM `items` WHERE `id` = ?";
                break;
            case "requests":
                query = "SELECT 1 FROM `requests` WHERE `id` = ?";
                break;
            case "ancs":
                query = "SELECT 1 FROM `ancs` WHERE `id` = ?";
                break;
        }
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        boolean ans = res.next();
        close(statement, res);
        return ans;
    }
    
    public String getDepartment(String id) throws SQLException {
    	String pos = getPosition(id);
    	String query = "";
    	if(pos.equals("Student")) query = "SELECT `department` FROM `students` WHERE `id` = ?";
    	else query = "SELECT `department` FROM `teachers` WHERE `id` = ?";
                
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        res.next();
        String department = res.getString("department");
        close(statement, res);
        return department;
	}
    
    private void close(PreparedStatement statement, ResultSet res) throws SQLException {
    	statement.close();
        res.close();
	}
    
    public StudentDegree getDegree(String id) throws SQLException {
    	String query = "SELECT * FROM `students` WHERE `id` = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        res.next();
        StudentDegree department = EnumUtil.JsonToStuDegree(res.getString("stu_degree"));
        System.out.println(department+"  degree");
        close(statement, res);
        return department;
	}
    
    public String getPosition(String id) throws SQLException {
    	String query = "SELECT `position` FROM `persons` WHERE `username` = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        
        String position = "";
        if(res.next()) position = res.getString("position");
        close(statement, res);
        return position;
	}
    
    
    public String getDeputyByDep(String myDep) throws SQLException {
    	String query = "SELECT * FROM `teachers` JOIN `persons` WHERE `department` = ? AND `position` = 'Deputy' AND (`persons`.`id` = `teachers`.`id`)";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, myDep);
        ResultSet res = statement.executeQuery();
        res.next();
        String id = res.getString("username");
        close(statement, res);
        return id;
	}
    
    
    public String getSupervisorName(Student student) throws SQLException {
    	String query = "SELECT `first_name`, `last_name` FROM `students` INNER JOIN `persons` WHERE `username` = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, student.getSupervisor());
        ResultSet res = statement.executeQuery();
        res.next();
        String name = res.getString("first_name")+" "+res.getString("last_name");
        close(statement, res);
        return name;
	}    
    
    
    public ArrayList<String> getTeacherList() throws SQLException {
    	String query = "SELECT * FROM `teachers` JOIN `persons` WHERE `teachers`.`id` = `persons`.`id` group by `teachers`.`id`";
        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet res = statement.executeQuery();
        
        ArrayList<String> courseList = new ArrayList<>();
        while(res.next()) {
        	String info = res.getString("first_name")+"     -     "+res.getString("last_name")+"     -     "+res.getString("email")+"     -     "+res.getString("department");
            courseList.add(info);
        }
        close(statement, res);
        return courseList;
	}
    
    

    public ArrayList<String> getCourseList() throws SQLException {
    	String query = "SELECT `name`, `id`, `degree`, `credit` FROM `courses`";
        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet res = statement.executeQuery();
        
        ArrayList<String> courseList = new ArrayList<>();
        while(res.next()) {
        	String info = res.getString("name")+"     -     "+res.getString("id")+"     -     "+EnumUtil.JsonToStuDegree(res.getString("degree")).toString()+"     -     "+res.getInt("credit");
            courseList.add(info);
        }
        close(statement, res);
        return courseList;
	}
    
    public ArrayList<String> getFilterBy(String type, String by) throws SQLException {
    	String query = "";
    	switch (type) {
		case "dep": {
	        query = "SELECT `name`, `id`, `degree`, `credit` FROM `courses` WHERE `department` = ?";
	        break;
		}
		case "degree": {
	        query = "SELECT `name`, `id`, `degree`, `credit` FROM `courses` WHERE `degree` = ?";
	        break;
		}
		case "credit": {
	        query = "SELECT `name`, `id`, `degree`, `credit` FROM `courses` WHERE `credit` = ?";
	        break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + type);
		}
        PreparedStatement statement = connection.prepareStatement(query);
        
        if(type.equals("dep")) statement.setString(1, by);
        else if(type.equals("degree")) statement.setString(1, new Gson().toJson(by));
        else statement.setInt(1, Integer.parseInt(by));
        
        ResultSet res = statement.executeQuery();
        
        ArrayList<String> courseList = new ArrayList<>();
        while(res.next()) {
        	String info = res.getString("name")+"     -     "+res.getString("id")+"     -     "+EnumUtil.JsonToStuDegree(res.getString("degree")).toString()+"     -     "+res.getInt("credit");
            courseList.add(info);
        }
        close(statement, res);
        return courseList;
	}
    

    public LinkedList<String> prefferedCourses(String id) throws SQLException {
    	return Methods.prefferedCourses(id);
    }
    
    
    public boolean userExists(String table, String username) throws SQLException
    {
        String query = "";
        switch (table) {
            case "persons":
                query = "SELECT 1 FROM `persons` WHERE `username` = ?";
                break;
            case "students":
                query = "SELECT 1 FROM `students` WHERE `username` = ?";
                break;
            case "teachers":
                query = "SELECT 1 FROM `teachers` WHERE `username` = ?";
                break;
        }
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, username);
        ResultSet res = statement.executeQuery();
        boolean ans = !res.next();
        close(statement, res);
        return ans;
    }
    
    
    public boolean validLogin(String username, String password) throws SQLException {
        String query = "SELECT * FROM `persons` WHERE `username` = ? AND `password` = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, username);
        statement.setString(2, password);
        ResultSet res = statement.executeQuery();
        boolean ans = res.next();
        close(statement, res);
        return ans;
    }
    
    
    
    
    public Person extractPerson(ResultSet res) throws SQLException {
    	Person user = new Person();
        while (res.next()) {
            user.setID(res.getString("id"));
            user.setUsername(res.getString("username"));
            user.setPassword(res.getString("password"));
            user.setPosition(res.getString("position"));
            user.setFirstName(res.getString("first_name"));
            user.setLastName(res.getString("last_name"));
            user.setEmail(res.getString("email"));
            user.setCode(res.getString("code"));
            user.setPhoneNumber(res.getString("phone_number"));
            user.setLastExit(res.getString("last_exit"));
            user.setLastVisit(res.getString("last_visit"));
            user.setLastPassChange(res.getString("last_pass"));
            user.setBase64(res.getString("base64"));
        }
        if(user.getPosition().equals("Student")) {
        	user = new Student(user.getPosition(), user.getUsername(), user.getPassword(), user.getFirstName(), user.getLastName(),
        			user.getEmail(), user.getPhoneNumber(), user.getID(), user.getCode(), user.getLastVisit(), user.getLastExit(), user.getLastPassChange());
        }
        else {
        	user = new Teacher(user.getPosition(), user.getUsername(), user.getPassword(), user.getFirstName(), user.getLastName(),
        			user.getEmail(), user.getPhoneNumber(), user.getID(), user.getCode(), user.getLastVisit(), user.getLastExit(), user.getLastPassChange());
        }
        
        return user;
    }
    
    public Person savePerson(Person user) throws SQLException {
        boolean exists = ! rowIsMissing("persons", user.getID());

        PreparedStatement statement;
        if (exists) {
            statement = connection.prepareStatement(
                    "UPDATE `persons` SET `username` = ?, `password` = ?, `position` = ?, `first_name` = ?, `last_name` = ?,"
                    + " `email` = ?, `code` = ?, `phone_number` = ?, `last_exit` = ?, "
                    + "`last_visit` = ?, `last_pass` = ?, `base64` = ? WHERE `id` = ?");
        } else {
            statement = connection.prepareStatement(
                    "INSERT INTO `persons` (`username`, `password`, `position`, `first_name`, `last_name`, `email`, "
                    + "`code`, `phone_number`, `last_exit`, `last_visit`, "
                    + "`last_pass`, `base64`, `id`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        }
        statement.setString(1, user.getUsername());
        statement.setString(2, user.getPassword());
        statement.setString(3, user.getPosition());
        statement.setString(4, user.getFirstName());
        statement.setString(5, user.getLastName());
        statement.setString(6, user.getEmail());
        statement.setString(7, user.getCode());
        statement.setString(8, user.getPhoneNumber());
        statement.setString(9, user.getLastExit());
        statement.setString(10, user.getLastVisit());
        statement.setString(11, user.getLastPassChange());
        statement.setString(12, user.getBase64());
        
        statement.setString(13, user.getID());
        statement.executeUpdate();
        statement.close();
        
        PreparedStatement statement1 = connection.prepareStatement("SELECT * FROM `persons` WHERE `id` = ?");
        statement1.setString(1, user.getID());
        ResultSet res1 = statement1.executeQuery();
        return extractPerson(res1);
    }
    
    public Student extractStudent(ResultSet res, String id) throws SQLException {
    	 PreparedStatement statement = connection.prepareStatement("SELECT * FROM `persons` WHERE `id` = ?");
         statement.setString(1, id);
         ResultSet res1 = statement.executeQuery();
         
        Student user = (Student) extractPerson(res1);
        while (res.next()) {
            user.setCoursesList(ListUtil.JsonToListString(res.getString("courses")));
            user.setScoresList(ListUtil.JsonToListDouble(res.getString("scores")));
            user.setTempCoursesList(ListUtil.JsonToListString(res.getString("temp_courses")));
            user.setTempScoresList(ListUtil.JsonToListDouble(res.getString("temp_scores")));
            
            user.setDegree(EnumUtil.JsonToStuDegree(res.getString("stu_degree")));
            user.setStatus(EnumUtil.JsonToStatus(res.getString("status")));
            user.setDepartment(res.getString("department")); 
            user.setYearOfArrival(res.getString("year"));
            user.setMojavez(res.getString("mojavez"));
            user.setSignUpTime(res.getString("sign_up"));
            user.setWithdrawalFeedback(res.getString("withdrawed"));
            user.setSupervisor(res.getString("supervisor"));
            user.setCoursesProtested(ListUtil.JsonToListString(res.getString("protested")));
            user.setCoursesFeedbacks(ListUtil.JsonToListString(res.getString("pro_feedback")));
            user.setRecomFeedbacks(ListUtil.JsonToListString(res.getString("recom_feed")));
            user.setRecomReqTeachers(ListUtil.JsonToListString(res.getString("recom_req")));
            user.setMinorReqDepartments(ListUtil.JsonToListString(res.getString("minor_dep")));
            user.setMinorReqFeedbacks(ListUtil.JsonToListString(res.getString("minor_feed")));
            user.setChecked(ListUtil.JsonToListString(res.getString("checked")));
            user.setChosen(ListUtil.JsonToListString(res.getString("chosen")));
            user.setPassed(ListUtil.JsonToHashMap(res.getString("passed")));
            
        }
        return user;
    }

    public Student loadStudent(String id) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `students` WHERE `id` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        Student student = extractStudent(res, id);
        close(statement, res);
        return student;
    }
    
    public Student saveStudent(Student student) throws SQLException {
    	savePerson(student);
        boolean exists = ! rowIsMissing("students", student.getID());

        PreparedStatement statement;
        if (exists) {
            statement = connection.prepareStatement(
                    "UPDATE `students` SET `courses` = ?, `scores` = ?, `temp_courses` = ?, `temp_scores` = ?, `stu_degree` = ?, "
                    + "`status` = ?, `department` = ?, `year` = ?, `mojavez` = ?, `sign_up` = ?, `withdrawed` = ?, "
                    + "`supervisor` = ?, `protested` = ?, `pro_feedback` = ?, `recom_feed` = ?, `recom_req` = ?"
                    + ", `minor_dep` = ?, `minor_feed` = ?, `checked` = ?, `chosen` = ?, `passed` = ? WHERE `id` = ?");
        } else {
            statement = connection.prepareStatement(
                    "INSERT INTO `students` (`courses`, `scores`, `temp_courses`, `temp_scores`, `stu_degree`, "
            		+"`status`, `department`, `year`, `mojavez`, `sign_up`, `withdrawed`, "
                    +"`supervisor`, `protested`, `pro_feedback`, `recom_feed`, `recom_req`, `minor_dep`, `minor_feed`, "
                    + "`checked`, `chosen`, `passed`, `id`) "
            		+"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        }
        statement.setString(1, new Gson().toJson(student.getCoursesList()));
        statement.setString(2, new Gson().toJson(student.getScoresList()));
        statement.setString(3, new Gson().toJson(student.getTempCoursesList()));
        statement.setString(4, new Gson().toJson(student.getTempScoresList()));
        statement.setString(5, new Gson().toJson(student.getDegree()));
        statement.setString(6, new Gson().toJson(student.getStatus()));
        statement.setString(7, student.getDepartment());
        statement.setString(8, student.getYearOfArrival());
        statement.setString(9, student.getMojavez());
        statement.setString(10, student.getSignUpTime());
        statement.setString(11, student.getWithdrawalFeedback());
        statement.setString(12, student.getSupervisor());
        statement.setString(13, new Gson().toJson(student.getCoursesProtested()));
        statement.setString(14, new Gson().toJson(student.getCoursesFeedbacks()));
        statement.setString(15, new Gson().toJson(student.getRecomFeedbacks()));
        statement.setString(16, new Gson().toJson(student.getRecomReqTeachers()));
        statement.setString(17, new Gson().toJson(student.getMinorReqDepartments()));
        statement.setString(18, new Gson().toJson(student.getMinorReqFeedbacks()));
        statement.setString(19, new Gson().toJson(student.getChecked()));
        statement.setString(20, new Gson().toJson(student.getChosen()));
        statement.setString(21, new Gson().toJson(student.getPassed()));
        
        statement.setString(22, student.getID());
        statement.executeUpdate();
        statement.close();
        return loadStudent(student.getID());
    }
    
    
    public Teacher extractTeacher(ResultSet res, String id) throws SQLException {
    	PreparedStatement statement = connection.prepareStatement("SELECT * FROM `persons` WHERE `id` = ?");
        statement.setString(1, id);
        ResultSet res1 = statement.executeQuery();
        
       Teacher user = (Teacher) extractPerson(res1);
       while (res.next()) {
           user.setTeacherDegree(EnumUtil.JsonToTeachDegree(res.getString("teach_degree")));
           user.setDepartment(res.getString("department"));            
           
           user.setRoom(res.getString("room"));
           
           user.setIncomMinorReqStudents(ListUtil.JsonToListString(res.getString("minor_in")));
           user.setOutgoMinorReqStudents(ListUtil.JsonToListString(res.getString("minor_out")));
           user.setScoresRegByTeacher(ListUtil.JsonToListString(res.getString("scores_reg")));
           user.setRecomReqStudents(ListUtil.JsonToListString(res.getString("recom_req")));
           user.setWithdrawReqStudents(ListUtil.JsonToListString(res.getString("with_req")));
       }
       return user;
	}
    
    public Teacher loadTeacher(String id) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `teachers` WHERE `id` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        Teacher teacher = extractTeacher(res, id);
        close(statement, res);
        return teacher;
    }
    
    public Teacher saveTeacher(Teacher teacher) throws SQLException {
    	savePerson(teacher);
        boolean exists = ! rowIsMissing("teachers", teacher.getID());

        PreparedStatement statement;
        if (exists) {
            statement = connection.prepareStatement(
                    "UPDATE `teachers` SET `teach_degree` = ?, `room` = ?, `department` = ?, `scores_reg` = ?, `minor_in` = ?, "
                    + "`minor_out` = ?, `recom_req` = ?, `with_req` = ? WHERE `id` = ?");
        } else {
            statement = connection.prepareStatement(
                    "INSERT INTO `teachers` (`teach_degree`, `room`, `department`, `scores_reg`, `minor_in`, `minor_out`, `recom_req`, `with_req`, `id`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        }
        statement.setString(1, new Gson().toJson(teacher.getTeacherDegree()));
        statement.setString(2, teacher.getRoom());
        statement.setString(3, teacher.getDepartment());
        statement.setString(4, new Gson().toJson(teacher.getScoresRegByTeacher()));
        statement.setString(5, new Gson().toJson(teacher.getIncomMinorReqStudents()));
        statement.setString(6, new Gson().toJson(teacher.getOutgoMinorReqStudents()));
        statement.setString(7, new Gson().toJson(teacher.getRecomReqStudents()));
        statement.setString(8, new Gson().toJson(teacher.getWithdrawReqStudents()));
        
        statement.setString(9, teacher.getID());
        statement.executeUpdate();
        statement.close();
        return loadTeacher(teacher.getID());
    }
    
    
    
    public LinkedList<String> getInfos() throws SQLException {
    	 PreparedStatement statement = connection.prepareStatement("SELECT persons.id, `first_name`, `last_name`, `stu_degree` FROM `students` JOIN `persons` where `position` = 'student' group by persons.id  ORDER BY `year` DESC ");
         ResultSet res = statement.executeQuery();
         LinkedList<String> list = new LinkedList<>();
         while (res.next()) {
			list.add(res.getString("id")+" "+res.getString("first_name")+" "+res.getString("last_name")+" "+res.getString("stu_degree"));
		 }
         close(statement, res);
         return list;
    }
    
    
    public Chat loadChat(int id) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `chats` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        Chat chat = new Chat();
        while (res.next()) {
        	chat.setId(res.getInt("id"));
        	chat.setName(res.getString("name"));
        	chat.setUser_one(res.getString("user_one"));
        	chat.setUser_two(res.getString("user_two"));
        	chat.setMessages(ListUtil.JsonToListInt(res.getString("messages")));  
        	chat.setLastTime(res.getString("time"));
        }
        close(statement, res);
        return chat;
    }

    public Chat saveChat(Chat chat) throws SQLException {
        boolean exists = rowExists("chats", chat.getId());
        PreparedStatement statement;
        if (exists) {
            statement = connection.prepareStatement(
                    "UPDATE `chats` SET `name` = ?, `user_one` = ?, `user_two` = ?, `messages` = ?, `time` = ? WHERE `id` = ?");
        } else {
        	statement = connection.prepareStatement(
                    "INSERT INTO `chats` (`name`, `user_one`, `user_two`, `messages`, `time`) "
            		+"VALUES (?, ?, ?, ?, ?)");
        }
        statement.setString(1, chat.getName());
        statement.setString(2, chat.getUser_one());
        statement.setString(3, chat.getUser_two());
        statement.setString(4, new Gson().toJson(chat.getMessages()));
        statement.setString(5, (chat.getLastTime()));
        if(exists) {
            statement.setInt(6, chat.getId());
        } else {
        	chat.setId(getMaxIdValue("chats"));
        }
        statement.executeUpdate();
        statement.close();
        return loadChat(chat.getId());
    }
    
    
    public Message loadMessage(int id) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `messages` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        Message message = new Message();
        while (res.next()) {
        	message.setId(res.getInt("id"));
        	message.setText(res.getString("text"));
        	message.setBase64(res.getString("base64"));
        	message.setChatID((res.getInt("chatID")));
        	message.setSenderID((res.getString("senderID")));
        	message.setTimeSent(res.getString("time"));
        }
        close(statement, res);
        return message;
    }

    public Message saveMessage(Message message) throws SQLException {
        boolean exists = rowExists("messages", message.getId());

        PreparedStatement statement;
        if (exists) {
            statement = connection.prepareStatement(
                    "UPDATE `messages` SET `text` = ?, `base64` = ?, `chatID` = ?, `senderID` = ?, `time` = ? WHERE `id` = ?");
        } else {
        	statement = connection.prepareStatement(
                    "INSERT INTO `messages` (`text`, `base64`, `chatID`, `senderID`, `time`) "
            		+"VALUES (?, ?, ?, ?, ?)");
        }
        message.setTimeSent(dtf.format(LocalDateTime.now()));
        
        statement.setString(1, message.getText());
        statement.setString(2, message.getBase64());
        statement.setInt(3, (message.getChatID()));
        statement.setString(4, (message.getSenderID()));
        statement.setString(5, message.getTimeSent());
        
        if(exists) statement.setInt(6, message.getId());
        else message.setId(getMaxIdValue("messages"));
                
        Chat chat = loadChat(message.getChatID());
        chat.setLastTime(message.getTimeSent());
        saveChat(chat);
        statement.executeUpdate();
        statement.close();
        
        return loadMessage(message.getId());
    }
    

    int getMaxIdValue(String table) throws SQLException {
            String query = "";
            String query1 = "";
            switch (table) {
                case "chats":
                    query = "SELECT MAX(id) FROM `chats`";
                    query1 = "ALTER TABLE `chats` AUTO_INCREMENT = ?";
                    break;
                case "messages":
                    query = "SELECT MAX(id) FROM `messages`";
                    query1 = "ALTER TABLE `messages` AUTO_INCREMENT = ?";
                    break;
                case "exercises":
                    query = "SELECT MAX(id) FROM `exercises`";
                    query1 = "ALTER TABLE `exercises` AUTO_INCREMENT = ?";
                    break;
                case "medias":
                    query = "SELECT MAX(id) FROM `medias`";
                    query1 = "ALTER TABLE `medias` AUTO_INCREMENT = ?";
                    break;
                case "subjects":
                    query = "SELECT MAX(id) FROM `subjects`";
                    query1 = "ALTER TABLE `subjects` AUTO_INCREMENT = ?";
                    break;
                case "items":
                    query = "SELECT MAX(id) FROM `items`";
                    query1 = "ALTER TABLE `items` AUTO_INCREMENT = ?";
                    break;
                case "requests":
                    query = "SELECT MAX(id) FROM `requests`";
                    query1 = "ALTER TABLE `requests` AUTO_INCREMENT = ?";
                    break;
                case "ancs":
                    query = "SELECT MAX(id) FROM `ancs`";
                    query1 = "ALTER TABLE `ancs` AUTO_INCREMENT = ?";
                    break;
            }
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet res = statement.executeQuery();
            int max;
            if(res.next()) {
                max = res.getInt("MAX(id)");
            } else {
				max = 0;
			}
            close(statement, res);
            
            PreparedStatement statement1 = connection.prepareStatement(query1);
            statement1.setInt(1, max+1);
            statement1.executeUpdate();
            statement1.close();
            return max+1;
    }
    
    public boolean chatExists(String id, String other_id) throws SQLException {
		String name_one = id+"-"+other_id;
		String name_two = other_id+"-"+id;
		String query = "SELECT * FROM `chats` WHERE `name`=? OR `name`=? ";
		PreparedStatement statement = connection.prepareStatement(query);
		statement.setString(1, name_one);
		statement.setString(2, name_two);
        ResultSet res = statement.executeQuery();
        boolean b = res.next();
        close(statement, res);
        return b;
	}
    
    
    public Chat getChat(String id, String other_id) throws SQLException {
		String name_one = id+"-"+other_id;
		String name_two = other_id+"-"+id;
		int chatID = 0;
		Chat chat;
		
		String query = "SELECT * FROM `chats` WHERE `name`=? OR `name`=? ";
		PreparedStatement statement = connection.prepareStatement(query);
		statement.setString(1, name_one);
		statement.setString(2, name_two);
        ResultSet res = statement.executeQuery();
        if(res.next()) {
        	chatID = res.getInt("id");
        	chat = loadChat(chatID);
        } else {
        	chat = new Chat(name_one, id, other_id, null);
        	chat = saveChat(chat);
        }
        close(statement, res);
        return chat;
	}
    
    
    
    public HashMap<String, String> chatDataMap(String id) throws SQLException {
    	HashMap<String, String> chats_msgs = new HashMap<>();
    	LinkedList<Message> messages;
    	
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `chats` WHERE `user_one` = ? OR `user_two` = ?");
        statement.setString(1, id);
        statement.setString(2, id);
        ResultSet res = statement.executeQuery(); 
        while (res.next()) {
        	messages = new LinkedList<>();
        	Chat chat = loadChat(res.getInt("id"));
        	ArrayList<Integer> msgs = (ArrayList<Integer>) chat.getMessages();
        	int max = 10;
        	
        	if(max > msgs.size()) {
        		max = msgs.size();
        		for(int i=0; i<max; i++) {
            		messages.add(loadMessage(msgs.get(i)));
            	}
        	} else {
        		for(int i=max-10; i<max; i++) {
            		messages.add(loadMessage(msgs.get(i)));
            	}
        	}
        	
        	chats_msgs.put(new Gson().toJson(chat), new Gson().toJson(messages));
        }
        close(statement, res);
        return chats_msgs;
    }
    
    
    
    
    public LinkedList<String> getMyChats(String id) throws SQLException { //TODO time
		LinkedList<String> myChats = new LinkedList<>();
		String query = "SELECT * FROM `chats` WHERE `user_one`=? OR `user_two`=? ORDER BY `time` DESC";
		PreparedStatement statement = connection.prepareStatement(query);
		statement.setString(1, id);
		statement.setString(2, id);
        ResultSet res = statement.executeQuery();
        while (res.next()) {
        	Chat chat = loadChat(res.getInt("id"));
			myChats.add(Methods.getChatStatus(id, chat));
		}
        close(statement, res);
        return myChats;
	}
    
    
    public LinkedList<String> fullChats(String id) throws SQLException {
    	String position = getPosition(id);
    	LinkedList<String> list = new LinkedList<>(); 
    	LinkedList<String> ids;
    	
    	if(position.equals("Student")) {
    		Student student = loadStudent(id);
        	String year = student.getYearOfArrival();
        	String supervisorID = student.getSupervisor();
        	String department = student.getDepartment();
        	ids = getSameYearDep(year, department);
        	
        	for(String iD : ids) list.add(iD+" "+loadStudent(iD).getName());
        	list.add(Methods.getSupervisor(supervisorID));
        	list.add("1"+" "+"Admin");
    	} else if(position.equals("Teacher")) {
        	ids = getWhereIsSupervisor(id);
        	
        	for(String iD : ids) list.add(iD+" "+loadStudent(iD).getName());    		
    	} else {
    		String dep = getDepartment(id);
    		ids = getEveryIdDep(dep);
    		
    		for(String iD : ids) list.add(iD+" "+loadStudent(iD).getName()); 
    	}
    	return list;
    }
    
    
    public LinkedList<String> fullChatsIds(String id) throws SQLException {
    	String position = getPosition(id);
    	LinkedList<String> list = new LinkedList<>(); 
    	LinkedList<String> ids;
    	
    	if(position.equals("Student")) {
    		Student student = loadStudent(id);
        	String year = student.getYearOfArrival();
        	String department = student.getDepartment();
        	ids = getSameYearDep(year, department);
        	for(String iD : ids) list.add(iD);
        	list.add(student.getSupervisor());
        	list.add("1");
    	} else if(position.equals("Teacher")) {
        	list = getWhereIsSupervisor(id);		
    	} else {
    		String dep = getDepartment(id);
    		list = getEveryIdDep(dep);
    	}
    	return list;
    }
    
    
    public LinkedList<String> getSameYearDep(String year, String department) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `students` WHERE `year` = ? AND `department` = ?");
        statement.setString(1, year);
        statement.setString(2, department);
        ResultSet res = statement.executeQuery();
        LinkedList<String> list = new LinkedList<>();
        while (res.next()) list.add(res.getString("id"));
        close(statement, res);
        return list;
    }
    
    
    public LinkedList<String> getWhereIsSupervisor(String id) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `students` WHERE `supervisor` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        LinkedList<String> list = new LinkedList<>();
        while (res.next()) list.add(res.getString("id"));
        close(statement, res);
        return list;
    }
    
    public LinkedList<String> getEveryIdDep(String dep) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `students` WHERE `department` = ?");
        statement.setString(1, dep);
        ResultSet res = statement.executeQuery();
        LinkedList<String> list = new LinkedList<>();
        while (res.next()) list.add(res.getString("id"));
        close(statement, res);
        return list;
    }

	public int getChatId(String id, String other_id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `chats` WHERE (`user_one` = ? AND `user_two` = ?)"
				+ "OR (`user_two` = ? AND `user_one` = ?)");
        statement.setString(1, id);
        statement.setString(2, other_id);
        statement.setString(3, id);
        statement.setString(4, other_id);
        ResultSet res = statement.executeQuery();
        int chat_id = 0;
        while (res.next()) chat_id = res.getInt("id");
        close(statement, res);
        return chat_id;
	}

	public String getName(String other_id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `persons` WHERE `id` = ?");
        statement.setString(1, other_id);
        ResultSet res = statement.executeQuery();
        String name = "";
        while (res.next()) name = res.getString("first_name")+" "+res.getString("last_name");
        close(statement, res);
        return name;
	}

	public String getBase64(String other_id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `persons` WHERE `id` = ?");
        statement.setString(1, other_id);
        ResultSet res = statement.executeQuery();
        String base64 = "";
        while (res.next()) base64 = res.getString("base64");
        close(statement, res);
        return base64;
	}

	public LinkedList<String> getFilteredMohseni(String degree, String dep, String year) throws SQLException {
		LinkedList<String> ids = new LinkedList<>();
		System.out.println(degree+" "+dep+" "+year);
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `students` WHERE `stu_degree` = ?"
        		+ "AND `department` = ? AND `year` = ?");
        statement.setString(1, new Gson().toJson(degree));
        statement.setString(2, dep);
        statement.setString(3, year);
        ResultSet res = statement.executeQuery();
        while (res.next()) ids.add(res.getString("id"));
        close(statement, res);
        return ids;
	}
	
	
	public LinkedList<String> getWeekSchd(String id) throws SQLException {
		String pos = getPosition(id);
		LinkedList<String> schd = new LinkedList<>();
		String query = "";
		if(pos.equals("Student")) query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1";
		else query = "SELECT * FROM `minicourses` WHERE `teacher` = ?";
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        if(pos.equals("Student")) {
        	while (res.next()) {
        		MiniCourse miniCourse = CourseDB.getDB().loadMiniCourse(res.getString("course_id")); 
            	schd.add(miniCourse.getName()+"                                     "+miniCourse.getClassDay()+"                "+miniCourse.getClassTime());
            }
        } else {
        	 while (res.next()) {
             	schd.add(res.getString("mini_id")+"                                       "+res.getString("c_day")+"                   "+res.getString("c_time"));
             }
        }
        close(statement, res);
        return schd;
	}
	
	
	public LinkedList<String> getExamSchd(String id) throws SQLException { //TODO sort by time
		String pos = getPosition(id);
		LinkedList<String> schd = new LinkedList<>();
		String query = "";
		if(pos.equals("Student")) query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1";
		else query = "SELECT * FROM `minicourses` WHERE `teacher` = ?";
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        if(pos.equals("Student")) {
        	while (res.next()) {
        		MiniCourse miniCourse = CourseDB.getDB().loadMiniCourse(res.getString("course_id"));
            	schd.add(miniCourse.getName()+"   "+miniCourse.getExamDate()+"   "+miniCourse.getExamTime());
            }
        } else {
        	 while (res.next()) {
        		MiniCourse miniCourse = CourseDB.getDB().loadMiniCourse(res.getString("mini_id"));
        		schd.add(miniCourse.getName()+"   "+miniCourse.getExamDate()+"   "+miniCourse.getExamTime());
             }
        }
        close(statement, res);
        return schd;
	}
    
	
	
	public LinkedList<String> getTempScores(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		String query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1 AND (`score_stat` = 'Temp')";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next()) list.add(res.getString("course_id")+"   Temp: "+res.getDouble("score"));
        close(statement, res);
        return list;
	}
    
	
	public LinkedList<String> getScoreListForCourse(String mini_id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		String query = "SELECT * FROM `stu_course` WHERE `course_id` = ? AND `taken` = 1 AND (`score_stat` = 'Temp' OR `score_stat` = 'N/A')";
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, mini_id);
        ResultSet res = statement.executeQuery();
        while (res.next()) list.add(res.getString("student_id")+"   Score: "+res.getDouble("score"));
        close(statement, res);
        return list;
	}
	
	
	public void updateScore(String mini_id, String stu_id, Double score, String stat) throws SQLException {
		boolean hasPassed = false;
        PreparedStatement statement;
        statement = connection.prepareStatement(
                    "UPDATE `stu_course` SET `score` = ?, `score_stat` = ? "
                    + "WHERE `student_id` = ? AND `course_id` = ? AND `taken` = 1");
       
        statement.setDouble(1, score);
        statement.setString(2, stat);
        statement.setString(3, stu_id);
        statement.setString(4, mini_id);
        
        if(stat.equals("Reg") && score>10) hasPassed = true;
        
        statement.executeUpdate();
        statement.close();
        
        if(hasPassed) {
        	PreparedStatement statement1;
            statement1 = connection.prepareStatement(
                            "UPDATE `stu_course` SET `passed` = 1 "
                            + "WHERE `student_id` = ? AND `course_id` = ? AND `taken` = 1");
                
                statement1.setString(1, stu_id);
                statement1.setString(2, mini_id);
                
                statement1.executeUpdate();
                statement1.close();
        }
    }
	
	
	
	public LinkedList<String> getFullScores(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		LinkedList<Double> sc_list = new LinkedList<>();
		
		String query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        	while (res.next()) {
        		String score = "N/A";
        		if(res.getString("score_stat").equals("Reg")) {
        			sc_list.add(res.getDouble("score"));
        			score = res.getDouble("score")+"";
        		}
        		list.add(res.getString("course_id")+"   Score: "+score);
            }
        close(statement, res);
        return list;
	}
	
	
	public Double getGPA(String id) throws SQLException {
		String query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1 AND `score_stat` = 'Reg'";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        Double scoreSum = 0.0;
        int credits = 0;
        
        	while (res.next()) {
        		MiniCourse course = CourseDB.getDB().loadMiniCourse(res.getString("course_id"));
        		int credit = course.getCourseCredit();
        		credits += credit;
        		Double scr = res.getDouble("score");
        		scoreSum += scr*credit;
            }
        Double gpa = scoreSum/credits;
        close(statement, res);
        return gpa;
	}
	
	
	public int passedCredits(String id) throws SQLException {
		String query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1 AND `passed` = 1";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        int credits = 0;
        	while (res.next()) {
        		MiniCourse course = CourseDB.getDB().loadMiniCourse(res.getString("course_id"));
        		int credit = course.getCourseCredit();
        		credits += credit;
            }
        close(statement, res);
        return credits;
	}

	public void setChooseTime(Integer year, String dep, String time) throws SQLException {
		PreparedStatement statement;
        statement = connection.prepareStatement(
                    "UPDATE `students` SET `sign_up` = ?"
                    + " WHERE `year` = ? AND `department` = ?");
        statement.setString(1, time);
        statement.setInt(2, year);
        statement.setString(3, dep);
        
        statement.executeUpdate();
        statement.close();
	} //TODO

	public HashMap<String, String> studentCourseDataMap(String id) throws SQLException {
		HashMap<String, String> course_stat = new HashMap<>();
        String query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1";
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        	while (res.next())
            {
        		MiniCourse course = CourseDB.getDB().loadMiniCourse(res.getString("course_id"));
        		String stat = res.getString("student_id")+"`"+res.getBoolean("taken")+"`"+res.getString("score")+"`"+res.getBoolean("passed")+"`"+res.getString("score_stat");
        		course_stat.put(new Gson().toJson(course), stat);
            } 
        
        statement.close();
        res.close();
        return course_stat;
	}
	
	
	public LinkedList<MiniCourse> teacherCourseDataList(String id) throws SQLException {
		LinkedList<MiniCourse> courses = new LinkedList<>();
        String query = "SELECT * FROM `minicourses` WHERE `teacher` = ?"; 
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        
        	while (res.next())
            {
        		MiniCourse course = CourseDB.getDB().loadMiniCourse(res.getString("mini_id"));
        		courses.add(course);
            }
		
        
        statement.close();
        res.close();
        return courses;
	}
	
	

	public String getIdByName(String name) throws SQLException {
		String id = null;
		String query = "SELECT * FROM persons JOIN students WHERE (`persons`.`id` = `students`.`id`) "
				+ "AND `first_name` = ? AND `last_name` = ?";
		String s[] = name.split("\\s+");
			
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setString(1, s[0]);
	        statement.setString(2, s[1]);
	        ResultSet res = statement.executeQuery();
	        
	        while (res.next())
            {
        		id = res.getString("id"); //TODO duplicate ids
            }
	        	
	        statement.close();
	        res.close();
	        return id;
	}

	public String getCourseEduStat(String mini_id) throws SQLException {
		String query = "SELECT * FROM stu_course WHERE `taken` = 1 AND `course_id` = ?";
			
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setString(1, mini_id);
	        ResultSet res = statement.executeQuery();
	        
	        Double gpa = 0.0;
	        Double pass_gpa = 0.0;
	        int passed = 0;
	        int failed = 0;
	        
	        while (res.next())
            {
	        	if(res.getString("score_stat").equals("Reg")) {
	        		gpa += res.getDouble("score");
	        		if(res.getBoolean("passed")) {
	        			pass_gpa += res.getDouble("score");
	        			passed++;
	        		} else {
	        			failed++;
	        		}
	        	}        		           
        	}
	        
	        int whole = failed + passed;
	        gpa /= whole;
	        pass_gpa /= whole;
	        
	        String status = gpa+"`"+passed+"`"+failed+"`"+pass_gpa;
	        	
	        statement.close();
	        res.close();
	        return status;
	}

	
	
	public LinkedList<String> getFullScoreListForCourse(String mini_id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		String query = "";
		
		query = "SELECT * FROM `stu_course` WHERE `course_id` = ? AND `taken` = 1";
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, mini_id);
        ResultSet res = statement.executeQuery();
        
        	while (res.next())
            {
        		list.add(res.getString("student_id")+"   Score: "+res.getDouble("score")+"   Stat: "+res.getString("score_stat"));
            }
        
       
        statement.close();
        res.close();
        return list;
	}
	
	

	public void updateAdminChats(String id, LinkedList<Message> messages) throws SQLException { //TODO check
		String query = "SELECT * FROM `chats` WHERE (`user_one` = ? AND `user_two`=?) OR (`user_one` = ? AND `user_two`=?)";
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        statement.setString(2, "1");
        statement.setString(3, "1");
        statement.setString(4, id);
        ResultSet res = statement.executeQuery();
        
        while (res.next())
        {
        	System.out.println("sending...");
    		int chat_id = res.getInt("id");
    		Chat chat = loadChat(chat_id);
    		for(Message message : messages) {
    			message.setChatID(chat_id);
    			//message.setId(-1);
    			saveMessage(message);
    			chat.addToMessages(message.getId());
    			saveChat(chat);
    		}
        }      
       
        statement.close();
        res.close();
	}

	public LinkedList<String> recomList(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		String query = "SELECT * FROM `requests` WHERE `owner_id` = ? AND `type` = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        statement.setString(2, new Gson().toJson(ReqType.RECOM));
        ResultSet res = statement.executeQuery();
        while (res.next()) {
			list.add(res.getString("rec_id")+" - "+EnumUtil.JsonToRespType(res.getString("response")));
		}
        close(statement, res);
        return list;
	}

	public String recomText(String id, String teacher_id) throws SQLException {
		String text = null;
		String query = "SELECT * FROM `requests` WHERE `owner_id` = ? AND `type` = ? AND `rec_id` = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        statement.setString(2, new Gson().toJson(ReqType.RECOM));
        statement.setString(3, teacher_id);
        ResultSet res = statement.executeQuery();
        while (res.next()) {
			text = "I "+getName(teacher_id)+" vouch that"+"\n"+
            "mr/mrs "+getName(id)+" with student ID "+id+"\n"+
         	"has passed enough courses";
		}
        close(statement, res);
        return text;
	}

	public LinkedList<String> teacherTempScores(String teach_id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		LinkedList<MiniCourse> courses = teacherCourseDataList(teach_id);
		
		for(MiniCourse course : courses) {
			String query = "SELECT * FROM `stu_course` WHERE `course_id` = ? AND `score_stat` = ?";
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setString(1, course.getMiniCourseID());
	        statement.setString(2, "Temp");
	        ResultSet res = statement.executeQuery();
	        while (res.next()) {
				list.add(course.getName()+" - "+res.getString("student_id")+" - "+res.getDouble("score"));
			}
	        close(statement, res);
		}
        return list;
	}

	public void removeTeacher(String id) {
		// TODO Auto-generated method stub
		
	}

	public void updateLastVisit(String string, String id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(
                    "UPDATE `persons` SET `last_visit` = ? WHERE `id` = ?");
        statement.setString(1, string);
        statement.setString(2, id);
        statement.executeUpdate();
        statement.close();
	}

	public void updatePass(String id, String pass) throws SQLException {
		PreparedStatement statement = connection.prepareStatement(
                "UPDATE `persons` SET `password` = ? WHERE `id` = ?");
        statement.setString(1, pass);
        statement.setString(2, id);
        statement.executeUpdate();
        statement.close();
        
        PreparedStatement statement1 = connection.prepareStatement(
                "UPDATE `persons` SET `last_pass` = ? WHERE `id` = ?");
        statement1.setString(1, dtf.format(LocalDateTime.now()));
        statement1.setString(2, id);
        statement1.executeUpdate();
        statement1.close();
	}

	public String getLastVisit(String id) throws SQLException {
		String last = "";
		String query = "SELECT * FROM `persons` WHERE `id` = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next()) {
			last = res.getString("last_visit");
		}
        close(statement, res);
        return last;
	}

	public void updateData(String id, String type, String data) throws SQLException {
		String query = null;
		if(type.equals("email")) query = "UPDATE `persons` SET `email` = ? WHERE `id` = ?";
		else query = "UPDATE `persons` SET `phone_number` = ? WHERE `id` = ?";
		PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, data);
        statement.setString(2, id);
        statement.executeUpdate();
        statement.close();
	}
	
	
	

	

	
	
	
}// 1550 -> 1494 -> 1383 -> 1233

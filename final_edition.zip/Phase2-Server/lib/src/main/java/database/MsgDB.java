package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;

import com.google.gson.Gson;

import shared.model.Item;
import shared.model.MsgAnnounce;
import shared.model.MsgRequest;
import shared.util.EnumUtil;
import shared.util.ListUtil;

public class MsgDB {
	
	private static Connection connection;
	static MsgDB db;
	
	public static MsgDB getDB()
    {
        if (db == null)
        {
            db = new MsgDB();
        }
        return db;
    }
	
	public static void setConnection(Connection connection2) {
		connection = connection2;		
	}
	
	
	public MsgRequest saveReq(MsgRequest req) throws SQLException
    {
        boolean exists = Database.getDB().rowExists("requests", req.getId());

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `requests` SET `owner_id` = ?, `rec_id` = ?, `type` = ?, `response` = ?, `exp` = ?"
                    + "WHERE `id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `requests` (`owner_id`, `rec_id`, `type`, `response`, `exp`)"
            		+"VALUES (?, ?, ?, ?, ?)");
        }
        statement.setString(1, req.getOwner_id());
        statement.setString(2, req.getRec_id());
        statement.setString(3, new Gson().toJson(req.getType()));
        statement.setString(4, new Gson().toJson(req.getResponse()));
        statement.setString(5, req.getExp());
        
        if(exists) {
            statement.setInt(6, req.getId());
        } else {
        	req.setId(Database.getDB().getMaxIdValue("requests"));
        }
        statement.executeUpdate();
        statement.close();
        
        return loadReq(req.getId());
    }
	
	
	
	public MsgRequest loadReq(int id) throws SQLException
    {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `requests` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        MsgRequest req = new MsgRequest();
        while (res.next())
        {
        	req.setId(res.getInt("id"));
        	req.setType(EnumUtil.JsonToReqType(res.getString("type")));
        	req.setResponse(EnumUtil.JsonToRespType(res.getString("response")));
        	req.setOwner_id(res.getString("owner_id"));
        	req.setRec_id(res.getString("rec_id"));
        	req.setExp(res.getString("exp"));
        }
        statement.close();
        res.close();
        return req;
    }
	
	
	
	
	
	public MsgAnnounce saveAnc(MsgAnnounce anc) throws SQLException
    {
        boolean exists = Database.getDB().rowExists("ancs", anc.getId());
        

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `ancs` SET `text` = ?, `rec_ids` = ?"
                    + "WHERE `id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `ancs` (`text`, `rec_ids`)"
            		+"VALUES (?, ?)");
        }
        statement.setString(1, anc.getText());
        statement.setString(2, new Gson().toJson(anc.getRec_ids()));
                
        if(exists) {
            statement.setInt(3, anc.getId());
        } else {
        	anc.setId(Database.getDB().getMaxIdValue("ancs"));
        }
        statement.executeUpdate();
        statement.close();
        
        return loadAnc(anc.getId());
    }
	
	
	
	public MsgAnnounce loadAnc(int id) throws SQLException
    {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `ancs` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        MsgAnnounce anc = new MsgAnnounce();
        while (res.next())
        {
        	anc.setId(res.getInt("id"));
        	anc.setText(res.getString("text"));
        	anc.setRec_ids(ListUtil.JsonToListString(res.getString("rec_ids")));
        }
        statement.close();
        res.close();
        return anc;
    }
	
	public LinkedList<MsgAnnounce> getAncFullList() throws SQLException {
		LinkedList<MsgAnnounce> list = new LinkedList<>();
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `ancs`");
	        ResultSet res = statement.executeQuery();
	        MsgAnnounce anc;
	        while (res.next())
	        {
	        	anc = loadAnc(res.getInt("id"));
	        	list.add(anc);
	        }
	        statement.close();
	        res.close();
		return list;
	}

	public LinkedList<String> getAncList(String id) throws SQLException {
		LinkedList<MsgAnnounce> fullList = getAncFullList();
		LinkedList<String> list = new LinkedList<>();
		ArrayList<String> rec_ids;
		for(MsgAnnounce announce : fullList) {
			rec_ids = announce.getRec_ids();
			if(rec_ids.contains(id)) list.add(announce.getId()+"      "+announce.getText());
		}
		return list;
	}

	public LinkedList<String> getReqList(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `requests` WHERE `rec_id` = ?");
		statement.setString(1, id);
	        ResultSet res = statement.executeQuery();
	        while (res.next())
	        {
	        	list.add(res.getInt("id")+"    "+EnumUtil.JsonToReqType(res.getString("type")));
	        }
	        statement.close();
	        res.close();
		return list;
	}
	
	public LinkedList<String> getRespList(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `requests` WHERE `owner_id` = ?");
		statement.setString(1, id);
	        ResultSet res = statement.executeQuery();
	        while (res.next())
	        {
	        	list.add(res.getString("response")+"   "+EnumUtil.JsonToReqType(res.getString("type"))+"    "+res.getString("rec_id")); //TODO
	        }
	        statement.close();
	        res.close();
		return list;
	}

	public String getAncText(int id) throws SQLException {
		String string = "";
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `ancs` WHERE `id` = ?");
		statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	string = res.getString("text");
        }
        statement.close();
        res.close();
	    return string;
	}

	public String getReqInfo(int id) throws SQLException {
		String string = "";
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `requests` WHERE `id` = ?");
		statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	string += res.getString("type");
        	string += "`";
        	string += res.getString("owner_id");
        	string += "`";
        	string += res.getString("exp");
        }
        statement.close();
        res.close();
	    return string;
	}

	public MsgRequest getMinorReq(String id, String dep) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `requests` WHERE `owner_id` = ? AND `exp` = ?");
		statement.setString(1, id);
		statement.setString(1, id+" : "+dep);
        ResultSet res = statement.executeQuery();
        MsgRequest request = null;
        while (res.next()) {
        	request = loadReq(res.getInt("id"));
        }
        statement.close();
        res.close();
	    return request;
	}

	

}

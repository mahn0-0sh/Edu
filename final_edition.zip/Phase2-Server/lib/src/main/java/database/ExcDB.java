package database;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

import com.google.gson.Gson;

import shared.model.Course;
import shared.model.Exercise;
import shared.model.MiniCourse;
import shared.model.Student;
import shared.util.ListUtil;

public class ExcDB {
	
	private static Connection connection;
	static ExcDB db;
	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	
	public static ExcDB getDB()
    {
        if (db == null)
        {
            db = new ExcDB();
        }
        return db;
    }

	// 2022/08/05 23:23:00
	
	
	public Exercise saveExc(Exercise exc) throws SQLException
    {
        boolean exists = Database.getDB().rowExists("exercises", exc.getId());

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `exercises` SET `mini_id` = ?, `name` = ?, `explaination` = ?, `open_time` = ?, "
                    + "`close_time` = ?, `allowed_types` = ?, `pdf` = ?, `uploaded` = ?, `scores` = ?, `mohlat` = ?, `teacher` = ? WHERE `id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `exercises` (`mini_id`, `name`, `explaination`, `open_time`, "
            		+"`close_time`, `allowed_types`, `pdf`, `uploaded`, `scores`, `mohlat`, `teacher`)"
            		+"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        }
        statement.setString(1, exc.getMini_id());
        statement.setString(2, exc.getName());
        statement.setString(3, exc.getExplaination());
        statement.setString(4, exc.getOpen_time());
        statement.setString(5, exc.getClose_time());
        statement.setString(6, exc.getAllowed_type());
        statement.setString(7, exc.getPdf());
        statement.setString(8, new Gson().toJson(exc.getUploaded()));
        statement.setString(9, new Gson().toJson(exc.getScores()));
        statement.setString(10, exc.getMohlat());
        MiniCourse course = CourseDB.getDB().loadMiniCourse(exc.getMini_id());
        statement.setString(11, course.getTeacher());
        if(exists) {
            statement.setInt(12, exc.getId());
        } else {
        	exc.setId(Database.getDB().getMaxIdValue("exercises"));
        }
        statement.executeUpdate();
        statement.close();
        
        return loadExc(exc.getId());
    }
	
	
	
	public Exercise loadExc(int id) throws SQLException
    {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `exercises` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        Exercise exc = new Exercise();
        while (res.next())
        {
        	exc.setId(res.getInt("id"));
        	exc.setName(res.getString("name"));
        	exc.setExplaination(res.getString("explaination"));
        	exc.setPdf(res.getString("pdf"));
        	exc.setMini_id(res.getString("mini_id"));
        	exc.setOpen_time(res.getString("open_time"));
        	exc.setClose_time(res.getString("close_time"));
        	exc.setMohlat(res.getString("mohlat"));
        	exc.setAllowed_type(res.getString("allowed_types"));
        	exc.setUploaded(ListUtil.JsonToHashMap(res.getString("uploaded")));
        	exc.setScores(ListUtil.JsonToHashMapDouble(res.getString("scores")));
        }
        statement.close();
        res.close();
        return exc;
    }

	
	private boolean rowExists(String table, int exc_id, String stu_id) throws SQLException {
		 String query = "";
	        switch (table)
	        {
	            case "exc_stu":
	                query = "SELECT 1 FROM `exc_stu` WHERE `student_id` = ? AND `exc_id` = ?";
	                break;
	        }
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setString(1, stu_id);
	        statement.setInt(2, exc_id);
	        ResultSet res = statement.executeQuery();
	        boolean ans = res.next();
	        statement.close();
	        res.close();
	        return ans;
	}
	
	
	public void updateScore(int exc_id, String stu_id, Double score) throws SQLException
    {
        boolean exists = rowExists("exc_stu", exc_id, stu_id);

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `exc_stu` SET `score` = ? "
                    + "WHERE `student_id` = ? AND `exc_id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `exc_stu` (`score`, `student_id`, `exc_id`) "
            		+"VALUES (?, ?, ?)");
        }
        statement.setDouble(1, score);
        statement.setString(2, stu_id);
        statement.setInt(3, exc_id);
        
        statement.executeUpdate();
        statement.close();
    }
	
	
	public void updateMedia(int exc_id, String stu_id, int media_id) throws SQLException
    {
        boolean exists = rowExists("exc_stu", exc_id, stu_id);

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `exc_stu` SET `media_id` = ? "
                    + "WHERE `student_id` = ? AND `exc_id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `exc_stu` (`media_id`, `student_id`, `exc_id`) "
            		+"VALUES (?, ?, ?)");
        }
        statement.setInt(1, media_id);
        statement.setString(2, stu_id);
        statement.setInt(3, exc_id);
        
        statement.executeUpdate();
        statement.close();
    }
	
	
	
	public void updateStatus(int exc_id, String stu_id, String status) throws SQLException
    {
        boolean exists = rowExists("exc_stu", exc_id, stu_id);

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `exc_stu` SET `status` = ? "
                    + "WHERE `student_id` = ? AND `exc_id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `exc_stu` (`status`, `student_id`, `exc_id`) "
            		+"VALUES (?, ?, ?)");
        }
        statement.setString(1, status);
        statement.setString(2, stu_id);
        statement.setInt(3, exc_id);
        
        statement.executeUpdate();
        statement.close();
    }
	
	
    public LinkedList<String> getCourseExercises(String id) throws SQLException {
		MiniCourse course = CourseDB.getDB().loadMiniCourse(id);
		LinkedList<String> list = new LinkedList<>();
		
		
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `exercises` WHERE `mini_id` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	list.add(res.getInt("id")+" - "+res.getString("name"));
        }
        statement.close();
        res.close();
		
		return list;
	}



	public static void setConnection(Connection connection2) {
		connection = connection2;		
	}

	public String getPDF(int id) throws SQLException {
		String string = "";
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `exercises` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	string = res.getString("pdf");
        }
        statement.close();
        res.close();
		
		return string;
	}

	public LinkedList<String> getCourseCalendar(String course_id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `exercises` WHERE `mini_id` = ? ORDER BY `mohlat` ASC");
        statement.setString(1, course_id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	list.add(res.getString("name")+"   "+res.getString("mohlat"));
        }
        statement.close();
        res.close();
		
		return list;
	}
	
	
	
	public LinkedList<String> getCourseExcs(String course_id, String sortBy) throws SQLException {
		
		LinkedList<Exercise> list = new LinkedList<>();
		LinkedList<String> last_list = new LinkedList<>();
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `exercises` WHERE `mini_id` = ?");
		
        statement.setString(1, course_id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	if(dtf.format(LocalDateTime.now()).compareTo(res.getString("close_time"))<=0) {
            	list.add(loadExc(res.getInt("id")));
        	} 
        	
        }
        statement.close();
        res.close();
        
        if(sortBy.equals("release")) {
        	Collections.sort(list, new Comparator<Exercise>() {

				@Override
				public int compare(Exercise o1, Exercise o2) {
					return o1.getOpen_time().compareTo(o2.getOpen_time());
				}
        		
			});
        } else {
        	Collections.sort(list, new Comparator<Exercise>() {

				@Override
				public int compare(Exercise o1, Exercise o2) {
					return o1.getClose_time().compareTo(o2.getClose_time());
				}
        		
			});
        }
        
        for(Exercise exc : list) {
        	last_list.add(exc.getId()+" - "+exc.getName());
        }
        
		return last_list;
	}

	public String getDelStatus(int exc_id, String id) throws SQLException {
		String status = "";
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `exc_stu` WHERE `exc_id` = ? "
        		+ "AND `student_id` = ?");
        
        statement.setInt(1, exc_id);
        statement.setString(2, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	status = res.getString("status");       	
        }
        
        statement.close();
        res.close();
        return status;
	}

	public String getScore(int exc_id, String id) throws SQLException {
		String status = "";
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `exc_stu` WHERE `exc_id` = ? "
        		+ "AND `student_id` = ?");
        
        statement.setInt(1, exc_id);
        statement.setString(2, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	status = res.getString("score");       	
        }
        statement.close();
        res.close();
        return status;
	}
	
	
	public LinkedList<String> getStuExams(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();

		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `student_id` = ? "
				+ "AND `taken` = 1");
        
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	Course course = CourseDB.getDB().loadCourse(res.getString("course"));
        	list.add(course.getName()+"   "+course.courseExam());
        }
        statement.close();
        res.close();
        
		return list;
	}
	
	
	
	public LinkedList<String> getStuCalendar(String id) throws SQLException { //TODO cheeeeeeck!
		LinkedList<String> list = new LinkedList<>();

		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` JOIN `exercises` WHERE `student_id` = ? AND `taken` = 1 AND (`mini_id` = `course_id`)");
        
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	Exercise exercise = loadExc(res.getInt("id"));
        	list.add(exercise.getName()+"   "+exercise.getMohlat());
        }
        statement.close();
        res.close();
        
		return list;
	}
	
	
	public LinkedList<String> getTeacherExams(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();

		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `minicourses` WHERE `teacher` = ?");
        
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	MiniCourse course = CourseDB.getDB().loadMiniCourse(res.getString("mini_id"));
        	list.add(course.getName()+"   "+course.courseExam());
        }
        statement.close();
        res.close();
        
		return list;
	}


	public LinkedList<String> getTeacherCalendar(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();

		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `exercises` WHERE `teacher` = ? ");
        
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	Exercise exercise = loadExc(res.getInt("id"));
        	list.add(exercise.getName()+"   "+exercise.getMohlat());
        }
        statement.close();
        res.close();
        
		return list;
	}
	
	
}

package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import com.google.gson.Gson;

import shared.model.Course;
import shared.model.MiniCourse;
import shared.model.Student;
import shared.model.Teacher;
import shared.util.EnumUtil;
import shared.util.ListUtil;

public class CourseDB {
	
	private static Connection connection;
	static CourseDB db;
	
	public static CourseDB getDB()
    {
        if (db == null)
        {
            db = new CourseDB();
        }
        return db;
    }

	
	
	public Course saveCourse(Course course) throws SQLException
    {
        boolean exists = ! Database.getDB().rowIsMissing("courses", course.getCourseID());

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `courses` SET `name` = ?, `credit` = ?, `pre_id` = ?, `con_id` = ?, "
                    + "`department` = ?, `degree` = ?, `e_date` = ?, `e_time` = ? WHERE `id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `courses` (`name`, `credit`, `pre_id`, `con_id`, "
            		+"`department`, `degree`, `e_date`, `e_time`, "
                    +"`id`) "
            		+"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        }
        statement.setString(1, course.getName());
        statement.setInt(2, course.getCourseCredit());
        statement.setString(3, new Gson().toJson(course.getPreID()));
        statement.setString(4, new Gson().toJson(course.getConID()));
        statement.setString(5, course.getDepartment());
        statement.setString(6, new Gson().toJson(course.getCourseDegree()));        
        statement.setString(7, (course.getExamDate()));
        statement.setString(8, (course.getExamTime()));
       
        statement.setString(9, course.getCourseID());
        statement.executeUpdate();
        statement.close();
        return loadCourse(course.getCourseID());
    }
	
	
	
	
	public Course loadCourse(String id) throws SQLException
    {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `courses` WHERE `id` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        Course course = new MiniCourse();
        while (res.next())
        {
        	course.setCourseID(res.getString("id"));
        	course.setName(res.getString("name"));
        	course.setCourseCredit(res.getInt("credit"));
        	course.setPreID(ListUtil.JsonToListString(res.getString("pre_id")));
        	course.setConID(ListUtil.JsonToListString(res.getString("con_id")));
        	course.setDepartment(res.getString("department"));
        	course.setCourseDegree(EnumUtil.JsonToStuDegree(res.getString("degree")));
        	course.setExamDate(res.getString("e_date"));
        	course.setExamTime(res.getString("e_time"));
        }
        statement.close();
        res.close();
        return course;
    }
	
	
	
	
	
	public MiniCourse saveMiniCourse(MiniCourse course) throws SQLException
    {
		saveCourse(course);
        boolean exists = ! Database.getDB().rowIsMissing("minicourses", course.getMiniCourseID());

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `minicourses` SET `course_id` = ?, `group` = ?, `teacher` = ?, `ta` = ?, "
                    + "`c_day` = ?, `c_time` = ?, `capacity` = ?, `protested` = ? WHERE `mini_id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `minicourses` (`course_id`, `group`, `teacher`, `ta`, "
            		+"`c_day`, `c_time`, `capacity`, `protested`, `mini_id`)"
            		+"VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        }
        statement.setString(1, course.getCourseID());
        statement.setInt(2, course.getGroup());
        statement.setString(3, course.getTeacher());
        statement.setString(4, new Gson().toJson(course.gettAssisstants()));
        statement.setString(5, course.getClassDay());
        statement.setString(6, course.getClassTime()); 
        statement.setInt(7, course.getCapacity()); 
        statement.setString(8, new Gson().toJson(course.getProtestedStudents()));
        
       
        statement.setString(9, course.getMiniCourseID());
        statement.executeUpdate();
        statement.close();
        return loadMiniCourse(course.getMiniCourseID());
    }
	
	
	
	public MiniCourse loadMiniCourse(String id) throws SQLException
    {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `minicourses` WHERE `mini_id` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        MiniCourse course = (MiniCourse) loadCourse(id.split("-")[0]);
        while (res.next())
        {
        	course.setMiniCourseID(res.getString("mini_id"));
        	course.setCourseID(res.getString("course_id"));
        	course.setTeacher(res.getString("teacher"));
        	course.setGroup(res.getInt("group"));
        	course.settAssisstants(ListUtil.JsonToListString(res.getString("ta")));
        	course.setClassDay(res.getString("c_day"));
        	course.setClassTime(res.getString("c_time"));  	
        	course.setCapacity(res.getInt("capacity"));
        	course.setProtestedStudents(ListUtil.JsonToListString(res.getString("protested")));
        }
        statement.close();
        res.close();
        return course;
    }
	
	
	
	
	
	public ArrayList<String> getCourseList() throws SQLException {
    	String query = "";
        query = "SELECT `name`, `id`, `degree`, `credit` FROM `courses`";
                
        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet res = statement.executeQuery();
        
        ArrayList<String> courseList = new ArrayList<>();
        while(res.next()) {
        String info = res.getString("name")+"     -     "+res.getString("id")+"     -     "+EnumUtil.JsonToStuDegree(res.getString("degree")).toString()+"     -     "+res.getInt("credit");
        courseList.add(info);
        }
        statement.close();
        res.close();
        return courseList;
	}
	
	
	public String getPosType(String course_id, String id) throws SQLException {    
		
    	PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `student_id` = ? AND"
    			+ "`course_id` = ?");
        statement.setString(1, id);
        statement.setString(2, course_id);
        ResultSet res = statement.executeQuery();
        String type = "";
        while (res.next())
        {
        	type = res.getString("type");
        }
        statement.close();
        res.close();
        
    	return type;
	}
	
	
	public LinkedList<String> getStudentCourses(String id) throws SQLException {    	
        LinkedList<String> list = new LinkedList<>();
    	
    	PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `student_id` = ? AND "
    			+ "(`taken` = 1 OR `type` = 'TA')");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	list.add(Methods.getCourseName(res.getString("course_id")));
        }
        statement.close();
        res.close();
        
    	return list;
	}
	
	
	public LinkedList<String> getTeacherCourses(String id) throws SQLException {
    	LinkedList<String> list = new LinkedList<>();
    	
    	PreparedStatement statement = connection.prepareStatement("SELECT * FROM `minicourses` WHERE `teacher` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	list.add(Methods.getCourseName(res.getString("mini_id")));
        }
        statement.close();
        res.close();
        
    	return list;
	}
	
	
	
	
	
	public static void setConnection(Connection connection) {
		CourseDB.connection = connection;
	}



	public List<MiniCourse> getMiniByDep(String dep, String sort) throws SQLException {
		String query = "";
		query = "SELECT * FROM `courses` JOIN `minicourses` WHERE `department` = ? AND `course_id` = `id` GROUP BY `mini_id`";
	            
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, dep);
        ResultSet res = statement.executeQuery();
        
        ArrayList<MiniCourse> courseList = new ArrayList<>();
        
        while(res.next()) {
        	courseList.add(CourseDB.getDB().loadMiniCourse(res.getString("mini_id")));
        }
        
        if(sort.equals("Degree")) {
        	Collections.sort(courseList, new Comparator<MiniCourse>() {

				@Override
				public int compare(MiniCourse o1, MiniCourse o2) {
					return o1.getCourseDegree().compareTo(o2.getCourseDegree());
				}
        		
			});
        } 
        else if(sort.equals("Exam")) {
        	Collections.sort(courseList, new Comparator<MiniCourse>() {

				@Override
				public int compare(MiniCourse o1, MiniCourse o2) {
					return o1.courseExam().compareTo(o2.courseExam());
				}
        		
			});
        }
        else {
        	Collections.sort(courseList, new Comparator<MiniCourse>() {

				@Override
				public int compare(MiniCourse o1, MiniCourse o2) {
					return o1.getName().compareTo(o2.getName());
				}
        		
			});
        }

        statement.close();
        res.close();
        return courseList;
	}
	
	
	
	
	
	
	public List<MiniCourse> getMiniByDep(String dep) throws SQLException {
		String query = "";
		query = "SELECT `mini_id` FROM `courses` JOIN `minicourses` WHERE `department` = ? GROUP BY `mini_id`";
	            
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, dep);
        ResultSet res = statement.executeQuery();
        
        ArrayList<MiniCourse> courseList = new ArrayList<>();
        while(res.next()) {
        	courseList.add(CourseDB.getDB().loadMiniCourse(res.getString("mini_id")));
        }
        
        statement.close();
        res.close();
        return courseList;
	}



	public ArrayList<Integer> getCourseGroups(String id) throws SQLException {
		ArrayList<Integer> list = new ArrayList<>();
    	
    	PreparedStatement statement = connection.prepareStatement("SELECT `group` FROM `minicourses` WHERE `course_id` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	list.add(res.getInt("group"));
        }
        statement.close();
        res.close();
        
    	return list;
	}



	public int getLastGroup(String id, String courseID) throws SQLException {
		Student student = Database.getDB().loadStudent(id);
		ArrayList<String> chosen = student.getChosen();
		
		for(String string : chosen) {
			if(string.split("-")[0].equals(courseID)) {
				int grp = Integer.parseInt(string.split("-")[1]);
				return grp;
			}
		}
        
    	return 0;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private boolean rowExists(String table, String course_id, String stu_id) throws SQLException {
		 String query = "";
	        switch (table)
	        {
	            case "stu_course":
	                query = "SELECT 1 FROM `stu_course` WHERE `student_id` = ? AND `course_id` = ?";
	                break;
	        }
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setString(1, stu_id);
	        statement.setString(2, course_id);
	        ResultSet res = statement.executeQuery();
	        boolean ans = res.next();
	        statement.close();
	        res.close();
	        return ans;
	}
	
	
	
	
	public void updateScore(String course_id, String stu_id, Double score) throws SQLException
    {
        boolean exists = rowExists("stu_course", course_id, stu_id);

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `stu_course` SET `score` = ? "
                    + "WHERE `student_id` = ? AND `course_id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `stu_course` (`score`, `student_id`, `course_id`, `course`) "
            		+"VALUES (?, ?, ?, ?)");
        	statement.setString(4, course_id.split("-")[0]);
        }
        statement.setDouble(1, score);
        statement.setString(2, stu_id);
        statement.setString(3, course_id);
        
        statement.executeUpdate();
        statement.close();
    }
	
	
	public void updateType(String course_id, String stu_id, String type) throws SQLException
    {
        boolean exists = rowExists("stu_course", course_id, stu_id);

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `stu_course` SET `type` = ? "
                    + "WHERE `student_id` = ? AND `course_id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `stu_course` (`type`, `student_id`, `course_id`, `course`) "
            		+"VALUES (?, ?, ?, ?)");
        	statement.setString(4, course_id.split("-")[0]);
        }
        statement.setString(1, type);
        statement.setString(2, stu_id);
        statement.setString(3, course_id);
        
        statement.executeUpdate();
        statement.close();
    }
	
	
	
	public boolean isChecked(String course_id, String stu_id) throws SQLException
    {
        boolean isChecked = true;
        if(checkedStatus(course_id, stu_id).equals("Check")) {
        	isChecked = false;
        }
		return isChecked;
    }
	
	
	
	public void updateChecked(String course_id, String stu_id, boolean isChecked) throws SQLException
    {
        boolean exists = rowExists("stu_course", course_id, stu_id);

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `stu_course` SET `checked` = ? "
                    + "WHERE `student_id` = ? AND `course_id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `stu_course` (`checked`, `student_id`, `course_id`, `course`) "
            		+"VALUES (?, ?, ?, ?)");
        	statement.setString(4, course_id.split("-")[0]);
        }
        statement.setBoolean(1, isChecked);
        statement.setString(2, stu_id);
        statement.setString(3, course_id);
        
        statement.executeUpdate();
        statement.close();
    }
	
	public void updateChosen(String course_id, String stu_id, boolean isChosen) throws SQLException
    {
        boolean exists = rowExists("stu_course", course_id, stu_id);

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `stu_course` SET `chosen` = ? "
                    + "WHERE `student_id` = ? AND `course_id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `stu_course` (`chosen`, `student_id`, `course_id`, `course`) "
            		+"VALUES (?, ?, ?, ?)");
        	statement.setString(4, course_id.split("-")[0]);
        }
        statement.setBoolean(1, isChosen);
        statement.setString(2, stu_id);
        statement.setString(3, course_id);
        
        statement.executeUpdate();
        statement.close();
    }
	
	public void updateTaken(String course_id, String stu_id, boolean isTaken) throws SQLException
    {
        boolean exists = rowExists("stu_course", course_id, stu_id);

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `stu_course` SET `taken` = ? "
                    + "WHERE `student_id` = ? AND `course_id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `stu_course` (`taken`, `student_id`, `course_id`, `course`) "
            		+"VALUES (?, ?, ?, ?)");
        	statement.setString(4, course_id.split("-")[0]);
        }
        statement.setBoolean(1, isTaken);
        statement.setString(2, stu_id);
        statement.setString(3, course_id);
        
        statement.executeUpdate();
        statement.close();
    }



	public String checkedStatus(String mini_id, String id) throws SQLException {
        boolean status = false;
    	
    	PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `student_id` = ?"
    			+ "AND `course_id` = ?");
        statement.setString(1, id);
        statement.setString(2, mini_id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	status = res.getBoolean("checked");
        	
        }
        statement.close();
        res.close();
        
        if(status) return "Uncheck";
        else return "Check";
	}
	
	
	public String chosenStatus(String mini_id, String id) throws SQLException {
        boolean status = false;
    	
    	PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `student_id` = ?"
    			+ "AND `course_id` = ?");
        statement.setString(1, id);
        statement.setString(2, mini_id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	status = res.getBoolean("chosen");
        	
        }
        statement.close();
        res.close();
        
        if(status) return "Delete";
        else return "Choose";
	}



	public LinkedList<String> getChosenIds(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `student_id` = ?");
    			
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	if(res.getBoolean("chosen")) list.add(res.getString("course_id"));
        	
        }
        statement.close();
        res.close();
        
        return list;
	}
	
	
	public LinkedList<String> getChosenCourseIds(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `student_id` = ?");
    			
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	if(res.getBoolean("chosen")) list.add(res.getString("course"));
        	
        }
        statement.close();
        res.close();
        
        return list;
	}
	
	
	public LinkedList<String> getCheckedIds(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `student_id` = ?");
    			
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	if(res.getBoolean("checked")) list.add(res.getString("course_id"));
        	
        }
        statement.close();
        res.close();
        
        return list;
	}



	public LinkedList<String> getPassedIds(String id) throws SQLException {
        LinkedList<String> list = new LinkedList<>();
		
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `student_id` = ?");
    			
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	if(res.getBoolean("passed")) list.add(res.getString("course"));
        	
        }
        statement.close();
        res.close();
        
        return list;
	}



	public boolean hasMaaref(String id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `student_id` = ?");
		
		boolean hasMaaref = false;
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	MiniCourse miniCourse = loadMiniCourse(res.getString("course_id"));
        	if(miniCourse.getDepartment().equals("Maaref")) hasMaaref = true;
        }
        statement.close();
        res.close();
        
        return hasMaaref;
	}



	public LinkedList<String> getAllProtested(String mini_id) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `stu_course` WHERE `taken` = 1 AND `course_id` = ?");
        LinkedList<String> linkedList = new LinkedList<>();
        statement.setString(1, mini_id);
        ResultSet res = statement.executeQuery();
        while (res.next()) {
        	linkedList.add(res.getString("student_id"));
        }
        statement.close();
        res.close();
        return linkedList;
	}
	
	
	
	
	
	
	
	
	
	
}

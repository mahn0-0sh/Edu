package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

import com.google.gson.Gson;

import shared.model.Exercise;
import shared.model.MiniCourse;
import shared.model.Subject;
import shared.util.ListUtil;

public class SubjDB {

	private static Connection connection;
	static SubjDB db;
	
	public static SubjDB getDB()
    {
        if (db == null)
        {
            db = new SubjDB();
        }
        return db;
    }

	public static Connection getConnection() {
		return connection;
	}

	public static void setConnection(Connection connection) {
		SubjDB.connection = connection;
	}
	
	
	
	public Subject saveSub(Subject sub) throws SQLException
    {
        boolean exists = Database.getDB().rowExists("subjects", sub.getId());

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `subjects` SET `mini_id` = ?, `name` = ? WHERE `id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `subjects` (`mini_id`, `name`)"
            		+"VALUES (?, ?)");
        }
        statement.setString(1, sub.getMini_id());
        statement.setString(2, sub.getName());
        if(exists) {
            statement.setInt(3, sub.getId());
        } else {
        	sub.setId(Database.getDB().getMaxIdValue("subjects"));
        }
        statement.executeUpdate();
        statement.close();
        
        return loadSub(sub.getId());
    }
	
	
	
	public Subject loadSub(int id) throws SQLException
    {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `subjects` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        Subject sub = new Subject();
        while (res.next())
        {
        	sub.setId(res.getInt("id"));
        	sub.setName(res.getString("name"));
        	sub.setMini_id(res.getString("mini_id"));
        }
        statement.close();
        res.close();
        return sub;
    }
	
	
	
	

	public LinkedList<String> getCourseSubjects(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `subjects` WHERE `mini_id` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	list.add(res.getInt("id")+" - "+res.getString("name"));
        }
        statement.close();
        res.close();
        
		return list;
	}

	public void removeSubj(int id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("DELETE FROM `subjects` WHERE `id` = ?");
        statement.setInt(1, id);
        statement.executeUpdate();
        statement.close();
	}
	
	 
}

package database;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

import server.Library;
import shared.model.Chat;
import shared.model.Course;
import shared.model.Message;
import shared.model.MiniCourse;
import shared.model.Student;
import shared.model.Teacher;

public class Methods {

	static boolean hasMaaref(String id) throws SQLException {
    	Student student = Database.getDB().loadStudent(id);
    	MiniCourse course;
    	ArrayList<String> chosen = student.getChosen();
    	try {
			chosen.size();
		} catch (Exception e) {
			chosen = new ArrayList<String>();
		}
    	try {
    		for(String s : chosen) {
        		course = CourseDB.getDB().loadMiniCourse(s);
        		if(course.getDepartment().equals("Maaref")) return true;
        	}
		} catch (Exception e) {
			// TODO: handle exception
		}
    	
		return false;		
	}
	
	
	public static void correctPres(String id) throws SQLException {
		LinkedList<String> courses = CourseDB.getDB().getChosenIds(id);
		LinkedList<String> passedIds = CourseDB.getDB().getPassedIds(id);
		
		for(String mini_id : courses) {
			MiniCourse course = CourseDB.getDB().loadMiniCourse(mini_id);
			if(!Library.prePassed(passedIds, course)) {
				CourseDB.getDB().updateChosen(mini_id, id, false);
			}
		}
	}
	
	
	public static void correctCons(String id) throws SQLException {
		LinkedList<String> courses = CourseDB.getDB().getChosenIds(id);
		ArrayList<String> chosen = turnToCourseIds(courses);
		LinkedList<String> passedIds = CourseDB.getDB().getPassedIds(id);
		
		for(int i=0; i<passedIds.size(); i++) {
			chosen.add(passedIds.get(i));
		}
		
		for(String mini_id : courses) {
			MiniCourse course = CourseDB.getDB().loadMiniCourse(mini_id);
			if(!Library.conChose(chosen, course)) { 
				CourseDB.getDB().updateChosen(mini_id, id, false);
			}
		}
	}
	
	
	static ArrayList<String> turnToCourseIds(LinkedList<String> mini_chosen) {
		ArrayList<String> course_ids = new ArrayList<>();
		for(String string : mini_chosen) {
			course_ids.add(string.split("-")[0]);
		}
		return course_ids;
	}
	
	
	static LinkedList<String> prefferedCourses(String id) throws SQLException {
		Student student = Database.getDB().loadStudent(id);
		ArrayList<MiniCourse> courses = (ArrayList<MiniCourse>) CourseDB.getDB().getMiniByDep(student.getDepartment());
		LinkedList<String> passedIds = CourseDB.getDB().getPassedIds(id);
		LinkedList<String> sugList = new LinkedList<String>();
		
		for(MiniCourse course : courses) {
			if(Library.prePassed(passedIds, course)) {
				if(course.getCourseDegree() == student.getDegree()) {
					    if(course.getCapacity()>0) sugList.add(course.getMiniCourseID());
				}
			}
		}
		return sugList;		
	}
	
	public static String getCourseName(String id) throws SQLException {
		MiniCourse course = CourseDB.getDB().loadMiniCourse(id);
		return id+" - "+course.getName();
	}
	
	
	public static String getSupervisor(String id) throws SQLException {
		Teacher teacher = Database.getDB().loadTeacher(id);
		return id+" "+teacher.getName();
	}

	public static String getChatStatus(String id, Chat chat) throws SQLException {
		String status = "";
		String other_id = chat.getUser_one();
		if(other_id.equals(id)) other_id = chat.getUser_two();
		
		Message message = getLastMessage(chat);
		if(message != null) {
			try {
				String text = message.getText().split(":")[1];
				status += other_id+": ";
				status += text;
			} catch (Exception e) {
				status += message.getText();
			}
		} else {
			status += other_id+": ";
		}
		return status;
	}
	
	public static Message getLastMessage(Chat chat) throws SQLException {
		try {
			int size = chat.getMessages().size();
			Message message = Database.getDB().loadMessage(chat.getMessages().get(size-1));
			return message;
		} catch (Exception e) {
			return null;
		}		
	}
	
}

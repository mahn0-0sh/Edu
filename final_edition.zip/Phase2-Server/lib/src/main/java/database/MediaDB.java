package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

import com.google.gson.Gson;

import shared.model.Exercise;
import shared.model.Media;
import shared.model.MiniCourse;
import shared.util.ListUtil;

public class MediaDB {
	
	private static Connection connection;
	static MediaDB db;
	
	public static MediaDB getDB()
    {
        if (db == null)
        {
            db = new MediaDB();
        }
        return db;
    }
	
	
	public Media saveMedia(Media media) throws SQLException
    {
        boolean exists = Database.getDB().rowExists("medias", media.getId());

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `medias` SET `mini_id` = ?, `exc_id` = ?, `type` = ?, `base64` = ?, "
                    + "`text` = ?, `owner_id` = ? WHERE `id` = ?");
        }
        else
        {
        	statement = connection.prepareStatement(
                    "INSERT INTO `medias` (`exc_id`, `type`, `base64`, `text`, "
            		+"`owner_id`)"
            		+"VALUES (?, ?, ?, ?, ?)");
        }
        statement.setInt(1, media.getExc_id());
        statement.setString(2, media.getType());
        statement.setString(3, media.getBase64());
        statement.setString(4, media.getText());
        statement.setString(5, media.getOwner_id());
        if(exists) {
            statement.setInt(6, media.getId());
        } else {
        	media.setId(Database.getDB().getMaxIdValue("medias"));
        }
        statement.executeUpdate();
        statement.close();
        
        return loadMedia(media.getId());
    }
	
	
	
	public Media loadMedia(int id) throws SQLException
    {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `medias` WHERE `id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        Media media = new Media();
        while (res.next())
        {
        	media.setId(res.getInt("id"));
        	media.setExc_id(res.getInt("exc_id"));
        	media.setText(res.getString("text"));
        	media.setBase64(res.getString("base64"));
        	media.setOwner_id(res.getString("owner_id"));
        	media.setType(res.getString("type"));
        }
        statement.close();
        res.close();
        
        return media;
    }

	
	
	



	public static void setConnection(Connection connection2) {
		connection = connection2;		
	}


	public void removeLastMedia(String id, Integer exc_id) throws SQLException {
		PreparedStatement statement = connection.prepareStatement("DELETE FROM `medias` WHERE `exc_id` = ? AND `owner_id` = ?");
        statement.setInt(1, exc_id);
        statement.setString(2, id);
        statement.executeUpdate();
        statement.close();
	}

	
	
	public LinkedList<String> getSentList(int id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `medias` WHERE `exc_id` = ?");
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	list.add(res.getString("owner_id"));
        }
        System.out.println(list+"     MediaDB");
        statement.close();
        res.close();
		
		return list;
	}


	public String[] getStuMedia(String id, Integer exc_id) throws SQLException {
		String[] media = new String[2];
		PreparedStatement statement = connection.prepareStatement("SELECT * FROM `medias` WHERE `exc_id` = ? AND `owner_id` = ?");
        statement.setInt(1, exc_id);
        statement.setString(2, id);
        ResultSet res = statement.executeQuery();
        while (res.next())
        {
        	media[0] = res.getString("text");
        	media[1] = res.getString("base64");
        }
        statement.close();
        res.close();
        return media;
	}
	
	
}

package database;

import java.util.LinkedList;
import java.util.List;

import shared.model.Chat;

public class Lists {
	List<Chat> chats = new LinkedList<>();

}

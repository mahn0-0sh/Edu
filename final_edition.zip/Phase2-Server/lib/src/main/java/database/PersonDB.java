package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import shared.model.Person;

public class PersonDB {
	
	private static Connection connection;
	static PersonDB db;
	
	public static PersonDB getDB()
    {
        if (db == null)
        {
            db = new PersonDB();
        }
        return db;
    }
	
	public static void setConnection(Connection connection2) {
		connection = connection2;		
	}
	
	public Person savePerson(Person user) throws SQLException {
		boolean exists = ! Database.getDB().rowIsMissing("persons", user.getID());

        PreparedStatement statement;
        if (exists)
        {
            statement = connection.prepareStatement(
                    "UPDATE `persons` SET `username` = ?, `password` = ?, `position` = ?, `first_name` = ?, `last_name` = ?,"
                    + " `email` = ?, `code` = ?, `phone_number` = ?, `last_exit` = ?, `last_visit` = ?, `last_pass` = ? WHERE `id` = ?");
        }
        else
        {
            statement = connection.prepareStatement(
                    "INSERT INTO `persons` (`username`, `password`, `position`, `first_name`, `last_name`, `email`, `code`, `phone_number`, `last_exit`, `last_visit`, `last_pass`, `id`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        }
        statement.setString(1, user.getUsername());
        statement.setString(2, user.getPassword());
        statement.setString(3, user.getPosition());
        statement.setString(4, user.getFirstName());
        statement.setString(5, user.getLastName());
        statement.setString(6, user.getEmail());
        statement.setString(7, user.getCode());
        statement.setString(8, user.getPhoneNumber());
        statement.setString(9, user.getLastExit());
        statement.setString(10, user.getLastVisit());
        statement.setString(11, user.getLastPassChange());
        
        statement.setString(12, user.getID());
        statement.executeUpdate();
        statement.close();
        
        return loadPerson(user.getID());
	}
	
	
	public Person loadPerson(String id) throws SQLException {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `persons` WHERE `id` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        Person person = new Person();
        while (res.next())
        {
        	person.setID(res.getString("id"));
        	person.setFirstName(res.getString("first_name"));
        	person.setLastName(res.getString("last_name"));
        	person.setUsername(res.getString("username"));
        	person.setPassword(res.getString("password"));
        	person.setPosition(res.getString("position"));
        	person.setLastName(res.getString("last_name")); 
        	person.setEmail(res.getString("email"));
        	person.setCode(res.getString("code"));
        	person.setPhoneNumber(res.getString("phone_number"));
        	person.setLastVisit(res.getString("last_visit"));
        	person.setLastPassChange(res.getString("last_pass"));
        	person.setLastExit(res.getString("last_exit"));
        }
        statement.close();
        res.close();
        return person;
    }
   

}

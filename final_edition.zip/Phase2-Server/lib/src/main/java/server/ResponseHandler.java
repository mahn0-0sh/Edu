package server;

import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JOptionPane;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;

import database.Database;
import enums.ReqType;
import enums.RespType;
import enums.StudentDegree;
import enums.TeacherDegree;
import phase2.shared.Visit;
import shared.model.Chat;
import shared.model.Course;
import shared.model.Exercise;
import shared.model.Item;
import shared.model.Media;
import shared.model.Message;
import shared.model.MiniCourse;
import shared.model.MsgAnnounce;
import shared.model.MsgRequest;
import database.*;
import shared.model.Person;
import shared.model.Student;
import shared.model.Subject;
import shared.model.Teacher;
import shared.response.Response;
import shared.response.ResponseStatus;
import shared.util.Config;
import shared.util.extra.Token;

public class ResponseHandler {
	
	private Server server;
	private Token tokenGenerator = new Token();
	private Logger logger = LogManager.getLogger(Server.class);
	
	public ResponseHandler(Server server) {
		this.server = server;
	}
	

	void sendLoginResponse(int clientId, Boolean result, String username) throws SQLException {
        Response response = new Response(ResponseStatus.OK);
        if (result) {
            response.addData("username", username);
            response.addData("position", Database.getDB().getPosition(username));
            try {
            	response.addData("dep", Database.getDB().getDepartment(username));
			} catch (Exception e) {
				response.addData("dep", "ALL");
			}
            String token = tokenGenerator.generateToken();
            response.addData("token", token);
            server.setId(clientId, username);
            server.getClientHandler(clientId).setAuthToken(token);
        } else {
            response = new Response(ResponseStatus.ERROR);
            String message = Config.getConfig().getProperty(String.class, "passwordWrongError");
            response.setErrorMessage(message);
        }
        server.findClientAndSendResponse(clientId, response);
    }

	
	
	void sendMainPageResponse(int clientId, String username) throws SQLException {
        Response response = null;
        String pos = Database.getDB().getPosition(username);

        if(pos.equals("Student")) {
        	Student student = Database.getDB().loadStudent(username);
            response = new Response(ResponseStatus.STU);
            response.addData("name", student.getName());
            response.addData("email", student.getEmail());
            response.addData("vaziat", student.getStatus());
            response.addData("supervisor", Database.getDB().getSupervisorName(student)); //TODO
            response.addData("mojavez", student.getMojavez());
            response.addData("signUpTime", student.getSignUpTime());
            response.addData("lastVisit", student.getLastVisit());
            response.addData("username", student.getUsername());
        } else {
        	Teacher teacher = Database.getDB().loadTeacher(username);
        	response = new Response(ResponseStatus.TEACHER);
        	response.addData("lastVisit", teacher.getLastVisit());
        	response.addData("name", teacher.getName());
        	response.addData("email", teacher.getEmail());
        	// TODO add picture
        }
        server.findClientAndSendResponse(clientId, response);
    }

	
	void sendFilterCourseResponse(int clientId, String type, String by) throws SQLException {
		Response response = new Response();
		switch (type) {
		case "ALL": {
			response = new Response(ResponseStatus.FIL_FULL);
    		List<String> list = Database.getDB().getCourseList();
			response.addData("full", list);
			break;
		} case "dep": {
			response = new Response(ResponseStatus.FIL_DEP);
    		List<String> list = Database.getDB().getFilterBy(type, by);
			response.addData("dep", list);
			break;
		} case "degree": {
			response = new Response(ResponseStatus.FIL_DEG);
    		List<String> list = Database.getDB().getFilterBy(type, by);
			response.addData("degree", list);
			break;
		} case "credit": {
			response = new Response(ResponseStatus.FIL_CRE);
    		List<String> list = Database.getDB().getFilterBy(type, by);
			response.addData("credit", list);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + type);
		}
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendMiniByDepResponse(int clientId, String dep, String sort) throws SQLException {
		Response response = new Response(ResponseStatus.DEP_GROUP);
		response.addData("list", CourseDB.getDB().getMiniByDep(dep, sort));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendChooseResponse(int clientId, String mini_id, String id) { 
		try { 
			Response response = new Response();
			LinkedList<String> chosen = CourseDB.getDB().getChosenIds(id);
			LinkedList<String> chosen_course = CourseDB.getDB().getChosenCourseIds(id);
			MiniCourse course = CourseDB.getDB().loadMiniCourse(mini_id);
			LinkedList<String> passedIds = CourseDB.getDB().getPassedIds(id);
			
			boolean hasTheSameCourse = chosen_course.contains(mini_id.split("-")[0]);
			boolean isMaaref = course.getDepartment().equals("Maaref");
			boolean hasMaaref = CourseDB.getDB().hasMaaref(id);
			boolean prePassed = Library.prePassed(passedIds, course); //TODO
			boolean exMixed = true;
			boolean clMixed = true;
			boolean hasCapacity = false;
			
			if(!hasTheSameCourse) {
				if(!chosen.contains(mini_id)) {
					if(prePassed) {
						logger.info("pre course is passed");
					    MiniCourse c;
					    if(chosen.size() == 0) {
					    	 exMixed = false;
							 clMixed = false;
					    } else {
					    	for(String ids : chosen) {
							    c = CourseDB.getDB().loadMiniCourse(ids);
							    exMixed &= Library.courseExamMix(course, c);
							    clMixed &= Library.courseClassMix(course, c);
						    }
					    }
					    
					    if(isMaaref && hasMaaref) {
							response = new Response(ResponseStatus.MAAREF);
						} else {
							logger.info("no maaref error");
						   if(! exMixed) {
						   	   logger.info("course is not mixed");
						   	   
						   	   if(clMixed) {
						   		response = new Response(ResponseStatus.CL_MIX);
						   	   } else {
						   		   if(course.getCapacity()>0) hasCapacity = true;
								   if(!hasCapacity) response = new Response(ResponseStatus.CAPACITY);
							   }
						   } else {
							   response = new Response(ResponseStatus.EX_MIX);
						   } 
						}	
					    
					} else {
						response = new Response(ResponseStatus.PRE_ERR);
					}
				}
			} else {
				response = new Response(ResponseStatus.SAME_COURSE);
			}
			
			if(hasCapacity) {
				CourseDB.getDB().updateChosen(mini_id, id, true);
				response = new Response(ResponseStatus.OK);
				course.setCapacity(course.getCapacity()-1);
				
				CourseDB.getDB().saveMiniCourse(course);
				logger.info("valid course choice");
			} 
			server.findClientAndSendResponse(clientId, response);			
		} catch (Exception e) {
			System.out.println(e);
		}		
	}



	public void sendDeleteResponse(int clientId, String mini_id, String id) throws SQLException {
		MiniCourse course = CourseDB.getDB().loadMiniCourse(mini_id);
		CourseDB.getDB().updateChosen(mini_id, id, false);
		course.setCapacity(course.getCapacity()+1);
		CourseDB.getDB().saveMiniCourse(course);
	}

	
	public void sendCourseStatusResponse(int clientId, String mini_id, String id) throws SQLException {
		Response response = new Response(ResponseStatus.COURSE_STATUS);
		response.addData("check", CourseDB.getDB().checkedStatus(mini_id, id));
		response.addData("choose", CourseDB.getDB().chosenStatus(mini_id, id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendChangeGroupResponse(int clientId, String last_mini_id, String courseID, int group, String id) throws SQLException { //TODO
		Response response;
		String dep = Database.getDB().getDepartment(id);
		String depId = Database.getDB().getDeputyByDep(dep);
		String mini_id = courseID+"-"+group;
		MiniCourse miniCourse = CourseDB.getDB().loadMiniCourse(mini_id);
		int cap = miniCourse.getCapacity();
		boolean b = cap >= 1;
		
		if(b) {
			response = new Response(ResponseStatus.OK);
			miniCourse.setCapacity(cap - 1);
			CourseDB.getDB().saveMiniCourse(miniCourse);
			CourseDB.getDB().updateChosen(last_mini_id, id, false);
			CourseDB.getDB().updateChosen(mini_id, id, true);
		} else {
			response = new Response(ResponseStatus.ERROR); 
			MsgRequest request = new MsgRequest(ReqType.CHANGE_GROUP, last_mini_id+"   "+mini_id, id, depId);
			MsgDB.getDB().saveReq(request);
		}	
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendChangeCheckedResponse(int clientId, String mini_id, String id) throws SQLException {
		if(CourseDB.getDB().isChecked(mini_id, id)) {
			CourseDB.getDB().updateChecked(mini_id, id, false);
		} else {
			CourseDB.getDB().updateChecked(mini_id, id, true);
		}
	}


	public void sendCheckMapResponse(int clientId, String id) throws SQLException {
		Response response = new Response(ResponseStatus.OK);
		response.addData("map", CourseDB.getDB().getCheckedIds(id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendSugMapResponse(int clientId, String id) throws SQLException {
		Response response = new Response(ResponseStatus.OK);
		response.addData("map", Database.getDB().prefferedCourses(id));
		server.findClientAndSendResponse(clientId, response);
	}


	// sends list of chats' messages
	public void sendGetMessagesResponse(int clientId, int chatID) throws SQLException { 
		Chat chat = Database.getDB().loadChat(chatID);
		ArrayList<Integer> ids = (ArrayList<Integer>) chat.getMessages();
        ArrayList<Message> msg = new ArrayList<>();
        for(int i : ids) msg.add(Database.getDB().loadMessage(i));
        
        Response response = new Response(ResponseStatus.OK);
		response.addData("list", msg);
		server.findClientAndSendResponse(clientId, response);
	}



	// finds and sends chat
	public void sendChatResponse(int clientId, int chatID) throws SQLException {
		Response response = new Response(ResponseStatus.OK);
		response.addData("chat", Database.getDB().loadChat(chatID));
		server.findClientAndSendResponse(clientId, response);
	}


	// send text message
	public void sendSendMessageResponse(int clientId, int chatID, String id, String other_id, String message) throws SQLException {
		Message msg = new Message(id+": "+message, "", chatID, id);
		msg = Database.getDB().saveMessage(msg);
		Chat chat = Database.getDB().loadChat(chatID);
		chat.addToMessages(msg.getId());
		Database.getDB().saveChat(chat);
	}


	public void sendNewChatResponse(int clientId, String id, String other_id) throws SQLException {
		boolean chatExists = Database.getDB().chatExists(id, other_id);
		Response response = new Response(ResponseStatus.OK);
		String msg;
		if(!chatExists) {
			newChat(id, other_id);
			msg = "Done!";
		} else {
			msg = "Chat already exists.";
		}
		response.addData("msg", msg);
		server.findClientAndSendResponse(clientId, response);
	}
	
	
	public void newChat(String id, String other_id) throws SQLException {
		boolean chatExists = Database.getDB().chatExists(id, other_id);
		if(!chatExists) {
			Database.getDB().saveChat(new Chat(id+"-"+other_id, id, other_id, new ArrayList<>()));		
		}
	}
	

	public void sendSendFileResponse(int clientId, Integer chatID, String id, String other_id, String encode,
			String extension) throws SQLException {
		Chat chat = Database.getDB().loadChat(chatID);
		Message message = new Message(id+": "+extension, encode, chatID, id);
		message = Database.getDB().saveMessage(message);
		chat.addToMessages(message.getId());
		Database.getDB().saveChat(chat);
	}



	public void sendGetMyCoursesResponse(int clientId, String id, String position) throws SQLException {
		Response response = new Response();
		if(position.equals("Student")) response.addData("list", CourseDB.getDB().getStudentCourses(id));
		else response.addData("list", CourseDB.getDB().getTeacherCourses(id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendGetFullChatsResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().fullChats(id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendToMultipleResponse(int clientId, String id, LinkedList<String> ids, String messageText) throws SQLException {
		Chat chat;
		Message message;
		for(String string : ids) {
			chat = Database.getDB().getChat(id, string);
			message = new Message(id+": "+messageText, "", chat.getId(), id); 
			Database.getDB().saveMessage(message);
			chat.addToMessages(message.getId());
			Database.getDB().saveChat(chat);
		}
	}
	
	public void sendMediaToMultipleResponse(String id, String encode, String ext, LinkedList<String> ids) throws SQLException {
		for(String string : ids) {
			Chat chat = Database.getDB().getChat(id, string);
			Message message = new Message(id+": "+ext, encode, chat.getId(), id);  
			Database.getDB().saveMessage(message);
			chat.addToMessages(message.getId());
			Database.getDB().saveChat(chat);
		}  
	}
	
	public void sendTextToAll(int clientId, String id, String messageText) throws SQLException {
		sendToMultipleResponse(clientId, id, Database.getDB().fullChatsIds(id), messageText);
	}
	
	public void sendMediaToAll(int clientId, String id, String enc, String ext) throws SQLException {
		sendMediaToMultipleResponse(id, enc, ext, Database.getDB().fullChatsIds(id));
	}



	public void sendGetMyChatsResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().getMyChats(id));
		server.findClientAndSendResponse(clientId, response);
	}

	public void sendCreateExcResponse(int clientId, String mini_id, String name, String exp, String open, String close,
			String mohlat, String type, String pdf) throws SQLException {
		Exercise exc = new Exercise(mini_id, name, exp, open, close, mohlat, type, pdf, null, null);
		ExcDB.getDB().saveExc(exc);
	}


	public void sendGetCourseExcResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", ExcDB.getDB().getCourseExercises(id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendExcStatusResponse(int clientId, int id) throws SQLException {
		Response response = new Response();
		Exercise exc = ExcDB.getDB().loadExc(id);
		String status = exc.getName()+" ` "+exc.getExplaination()+" ` "+exc.getOpen_time()+" ` "+exc.getClose_time()+" ` "
				+exc.getAllowed_type()+" ` "+exc.getMohlat();
		
		response.addData("status", status);
		server.findClientAndSendResponse(clientId, response);		
	}
	
	public void sendExcPDFResponse(int clientId, int id) throws SQLException {
		Response response = new Response();
		String string = ExcDB.getDB().getPDF(id);
		
		response.addData("pdf", string);
		server.findClientAndSendResponse(clientId, response);		
	}


	public void sendTextAnsResponse(int clientId, String id, Integer exc_id, String text) throws SQLException {
		MediaDB.getDB().removeLastMedia(id, exc_id);
		Media media = new Media(id, exc_id, "Text", null, text);
		MediaDB.getDB().saveMedia(media);
		
		ExcDB.getDB().updateStatus(exc_id, id, "Text sent.");
		ExcDB.getDB().updateMedia(exc_id, id, media.getId());
	}

	
	public void sendExcSentResponse(int clientId, int id) throws SQLException {
		Response response = new Response();
		response.addData("list", MediaDB.getDB().getSentList(id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendExcStuMediaResponse(int clientId, String id, Integer exc_id) throws SQLException {
		Response response = new Response();
		response.addData("media", MediaDB.getDB().getStuMedia(id, exc_id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendGradeExcResponse(int clientId, String id, Integer exc_id, Double score) throws SQLException {
		ExcDB.getDB().updateScore(exc_id, id, score);
	}



	public void sendGetCourseSubjResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", SubjDB.getDB().getCourseSubjects(id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendNewSubjResponse(int clientId, String mini_id, String name) throws SQLException {
		Response response = new Response();
		Subject subject = new Subject(mini_id, name);
		response.addData("subj_id", SubjDB.getDB().saveSub(subject).getId());
		server.findClientAndSendResponse(clientId, response);
	}

	public void sendNewTextItemResponse(int clientId, int subj_id, String text) throws SQLException {
		Item item = new Item(subj_id, "Text", null, text);
		ItemsDB.getDB().saveItem(item);
	}

	public void sendNewMediaItemResponse(int clientId, Integer subj_id, String encode, String ext) throws SQLException {
		Item item = new Item(subj_id, "Media", encode, ext);
		ItemsDB.getDB().saveItem(item);
	}

	public void sendItemsNumberResponse(int clientId, Integer subj_id) throws SQLException {
		Response response = new Response();
		response.addData("num", ItemsDB.getDB().getNum(subj_id));
		server.findClientAndSendResponse(clientId, response);
	}

	
	public void sendItemsInfoResponse(int clientId, Integer subj_id) throws SQLException {
		Response response = new Response();
		response.addData("list", ItemsDB.getDB().getInfos(subj_id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendItemTextResponse(int clientId, int id) throws SQLException {
		Response response = new Response();
		response.addData("text", ItemsDB.getDB().getText(id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendItemBase64Response(int clientId, int id) throws SQLException {
		Response response = new Response();
		response.addData("base64", ItemsDB.getDB().getBase64(id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendItemEditTextResponse(int clientId, int item_id, String text) throws SQLException {
		Item item = ItemsDB.getDB().loadItem(item_id);
		item.setText(text);
		ItemsDB.getDB().saveItem(item);
	}


	public void sendItemEditMediaResponse(int clientId, int id, String encode, String ext) throws SQLException {
		Item item = ItemsDB.getDB().loadItem(id);
		item.setText(ext);
		item.setBase64(encode);
		ItemsDB.getDB().saveItem(item);
	}


	public void sendDeleteItemResponse(int clientId, int id) throws SQLException {
		ItemsDB.getDB().removeItem(id);
	}

	public void sendDeleteSubjResponse(int clientId, int id) throws SQLException {
		SubjDB.getDB().removeSubj(id);
	}


	public void sendCourseGroupsResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", CourseDB.getDB().getCourseGroups(id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendAncListResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", MsgDB.getDB().getAncList(id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendReqListResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", MsgDB.getDB().getReqList(id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendRespListResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", MsgDB.getDB().getRespList(id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendAncTextResponse(int clientId, int id) throws SQLException {
		Response response = new Response();
		response.addData("text", MsgDB.getDB().getAncText(id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendReqInfoResponse(int clientId, int id) throws SQLException {
		Response response = new Response();
		response.addData("info", MsgDB.getDB().getReqInfo(id));
		server.findClientAndSendResponse(clientId, response);
	}

	public void sendChatIdResponse(int clientId, String id, String other_id) throws SQLException {
		Response response = new Response();
		response.addData("chat_id", Database.getDB().getChatId(id, other_id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendOtherNameResponse(int clientId, String other_id) throws SQLException {
		Response response = new Response();
		response.addData("info", Database.getDB().getName(other_id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendOtherBase64Response(int clientId, String other_id) throws SQLException {
		Response response = new Response();
		response.addData("info", Database.getDB().getBase64(other_id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendAskChatResponse(int clientId, String id, String other_id) throws SQLException {
		Response response = new Response();
		String resp = "";
		String exp = Database.getDB().getName(id)+" wants to chat with you.";
		MsgRequest request = new MsgRequest(ReqType.ASK_CHAT, exp, id, other_id);
		MsgDB.getDB().saveReq(request);
		
		
		resp = "Request sent.";
		response.addData("resp", resp);
		server.findClientAndSendResponse(clientId, response);
	}
	
	
	
	public void sendStudentProfileResponse(int clientId, String id) throws SQLException {
    	Response response = null;
        Student student = Database.getDB().loadStudent(id);
        
    	response = new Response();
        response.addData("name", student.getName());
        response.addData("code", student.getCode());
        response.addData("id", student.getID());
        response.addData("phone", student.getPhoneNumber());
        response.addData("email", student.getEmail());
        response.addData("department", student.getDepartment());
        response.addData("gpa", Database.getDB().getGPA(id)); 
        response.addData("supervisor", student.getSupervisor());
        response.addData("year", student.getYearOfArrival());
        response.addData("degree", student.getDegree());
        response.addData("status", student.getStatus()); 
        
        server.findClientAndSendResponse(clientId, response);
	}



	public void sendGetInfosResponse(int clientId) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().getInfos());
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendAddToCourseResponse(int clientId, String course_id, String type, String id) throws SQLException {
		CourseDB.getDB().updateType(course_id, id, type);
		if(type.equals("TA")) {
			CourseDB.getDB().updateTaken(course_id, id, false);
		} else {
			CourseDB.getDB().updateTaken(course_id, id, true);
		}	
		Response response = new Response();
		response.addData("resp", "Ok");
		
		Student student = Database.getDB().loadStudent(id);
		ArrayList<String> courses = student.getCoursesList();
		courses.add(course_id);
		student.setCoursesList(courses);
		Database.getDB().saveStudent(student); 
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendAddToCourseAncResponse(int clientId, String courseID, String type, String id) throws SQLException {
		ArrayList<String> rec = new ArrayList<>();
		rec.add(id);
		String text = "You have been added to course "+courseID+" As "+type;
		MsgAnnounce announce = new MsgAnnounce(text, rec);
		MsgDB.getDB().saveAnc(announce);
	}



	public void sendGetPosTypeResponse(int clientId, String course_id, String id) throws SQLException {
		Response response = new Response();
		response.addData("type", CourseDB.getDB().getPosType(course_id, id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendCourseCalResponse(int clientId, String course_id) throws SQLException {
		Response response = new Response();
		response.addData("list", ExcDB.getDB().getCourseCalendar(course_id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendExcSortResponse(int clientId, String mini_id, String sortBy) throws SQLException {
		Response response = new Response();
		response.addData("list", ExcDB.getDB().getCourseExcs(mini_id, sortBy));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendExcScoreResponse(int clientId, String id, int exc_id) throws SQLException {
		Response response = new Response();
		response.addData("score", ExcDB.getDB().getScore(exc_id, id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendExcDelStatusResponse(int clientId, String id, int exc_id) throws SQLException {
		Response response = new Response();
		response.addData("status", ExcDB.getDB().getDelStatus(exc_id, id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendStuCalResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		LinkedList<String> excs = ExcDB.getDB().getStuCalendar(id);
		LinkedList<String> exms = ExcDB.getDB().getStuExams(id);
		
		for(String string : exms) excs.add(string);
		
		response.addData("list", excs);
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendTeacherCalResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		LinkedList<String> excs = ExcDB.getDB().getTeacherCalendar(id);
		LinkedList<String> exms = ExcDB.getDB().getTeacherExams(id);
		
		for(String string : exms) excs.add(string);
		
		response.addData("list", excs);
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendMohseniTextResponse(int clientId, String text, String recp) throws SQLException {
		String[] s = recp.split("`");
		LinkedList<String> ids = Database.getDB().getFilteredMohseni(s[0], s[1], s[2]);
		sendToMultipleResponse(clientId, "m", ids, text);
	}



	public void sendTeacherListResponse(int clientId) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().getTeacherList());
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendExamSchd(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().getExamSchd(id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendWeekSchd(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().getWeekSchd(id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendTempScores(int clientId, String data) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().getTempScores(data));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendFullScores(int clientId, String data) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().getFullScores(data));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendCredits(int clientId, String data) throws SQLException {
		Response response = new Response();
		response.addData("info", Database.getDB().passedCredits(data));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendGPA(int clientId, String data) throws SQLException {
		Response response = new Response();
		response.addData("info", Database.getDB().getGPA(data));
		server.findClientAndSendResponse(clientId, response);
	}

	
	public void sendProfileResponse(int clientId, String username) throws SQLException {
	    	Response response = null;
	    	String pos = Database.getDB().getPosition(username);
	    	if(pos.equals("Student")) {
	    		Student student = Database.getDB().loadStudent(username);
	        	response = new Response(ResponseStatus.STU);
		        response.addData("name", student.getName());
		        response.addData("code", student.getCode());
		        response.addData("id", student.getID());
		        response.addData("phone", student.getPhoneNumber());
		        response.addData("email", student.getEmail());
		        response.addData("department", student.getDepartment());
		        response.addData("gpa", Database.getDB().getGPA(username)+"");
		        response.addData("supervisor", Database.getDB().getSupervisorName(student));
		        response.addData("year", student.getYearOfArrival()+"");
		        response.addData("degree", student.getDegree());
		        response.addData("status", student.getStatus()); 
	    	} else {
	    		Teacher teacher = Database.getDB().loadTeacher(username);
	    		response = new Response(ResponseStatus.TEACHER);
	    		response.addData("name", teacher.getName());
	    		response.addData("code", teacher.getCode());
	    		response.addData("id", teacher.getID());
	    		response.addData("phone", teacher.getPhoneNumber());
	    		response.addData("email", teacher.getEmail());
	    		response.addData("department", teacher.getDepartment());
	    		response.addData("room", teacher.getRoom());
	    		response.addData("degree", teacher.getTeacherDegree());
	    	}
	        server.findClientAndSendResponse(clientId, response);
	}


	public void sendScoreListForCourse(int clientId, String mini_id) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().getScoreListForCourse(mini_id));
		server.findClientAndSendResponse(clientId, response);
	}
	

	public void sendTempReg(int clientId, String mini_id, HashMap<String, Double> map) throws SQLException {
		for(String id : map.keySet()) {
			Database.getDB().updateScore(mini_id, id, map.get(id), "Temp");
		}
	}


	public void sendFinReg(int clientId, String mini_id, HashMap<String, Double> map) throws SQLException {
		for(String id : map.keySet()) {
			Database.getDB().updateScore(mini_id, id, map.get(id), "Reg");
		}
	}


	public void sendAddNewCourseResponse(int clientId, String id, String name, int groups, String degree,
			int credit, String dep) throws SQLException {
		
		Response response = new Response();
		StudentDegree studentDegree;
		
		switch (degree) {
		case "BACHELOR": {
			studentDegree = StudentDegree.BACHELOR;
			break;
		}
		case "MASTER": {
			studentDegree = StudentDegree.MASTER;
			break;
		}
		default:
			studentDegree = StudentDegree.DOCTORATE;
			break;
		}
		
		MiniCourse miniCourse = null;
		
		if(groups != 0) {
			for(int i=0; i<groups; i++) {
				miniCourse = new MiniCourse(id, name, credit, null, null, dep, studentDegree, null, null, null, null, null, i+1, 0);	
				try {
			    	CourseDB.getDB().saveMiniCourse(miniCourse);
			    	response.addData("resp", "Done!");
				} catch (Exception e) {
					e.printStackTrace();
					response.addData("resp", "Error");
				}
			}
		} else {
			miniCourse = new MiniCourse(id, name, credit, null, null, dep, studentDegree, null, null, null, null, null, 0, 0);
			try {
		    	CourseDB.getDB().saveMiniCourse(miniCourse);
		    	response.addData("resp", "Done!");
			} catch (Exception e) {
				e.printStackTrace();
				response.addData("resp", "Error");
			}
		}
		
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendStuReqResponse(int clientId, ReqType reqType, String recp, String dep, String id) throws SQLException {
		MsgRequest request;
		String exp = "";
		String myDep = Database.getDB().getDepartment(id);
		String myDeputyId = Database.getDB().getDeputyByDep(myDep);
		
		switch (reqType) {
		case RECOM: {
			recp = myDeputyId;
			exp = id+" wants recom letter.";
			handleRecom(id, recp);
			break;
		}
		case MINOR: {
			recp = myDeputyId;
			exp = id+" : "+dep;
			handleMinor(id, dep, myDeputyId, false);
			break;
		}
		case WITHDRAW: {
			recp = myDeputyId;
			exp = id+" wants to withdraw";
			break;
		}
		default:
			break;
		}
		
		request = new MsgRequest(reqType, exp, id, recp);
		MsgDB.getDB().saveReq(request);
	}
	

	public void handleRecom(String stu_id, String teach_id) throws SQLException {
		Teacher teacher = Database.getDB().loadTeacher(teach_id);
		teacher.addToRecomStus(stu_id);
		Database.getDB().saveTeacher(teacher);
	}
	
	public void handleMinor(String stu_id, String dep, String myDeputyId, boolean accepted) throws SQLException {
		if(accepted) {
			String depDeputyId = Database.getDB().getDeputyByDep(dep);
			MsgRequest request = new MsgRequest(ReqType.MINOR_FINAL, stu_id+" : "+dep, myDeputyId, depDeputyId);
			MsgDB.getDB().saveReq(request);
		} else {
			Student student = Database.getDB().loadStudent(stu_id);
			student.addToMinor(dep);
			Teacher myDeputy = Database.getDB().loadTeacher(myDeputyId);
			String string = student.getName()+" "+student.getID()+" to "+dep;
			myDeputy.addToOutgoMinor(string);
			Database.getDB().saveTeacher(myDeputy);
			Database.getDB().saveStudent(student);
		}
	}

	public void sendGetDegreeResponse(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("degree", Database.getDB().getDegree(id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendSetChooseTimeResponse(int clientId, Integer year, String dep, String time) throws SQLException {
		Database.getDB().setChooseTime(year, dep, time);
	}
	
	
	public void editCourse(String type, String course_id, String data) throws SQLException {
		Course course = CourseDB.getDB().loadCourse(course_id);
		switch (type) {
		case "add_pre": {
			course.addToPre(data);
			break;
		}
		case "add_con": {
			course.addToCon(data);
			break;
		}
		case "e_date": {
			course.setExamDate(data);
			break;
		}
		case "e_time": {
			course.setExamTime(data);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + type);
		}
		CourseDB.getDB().saveCourse(course);
	}
	
	
	public void editCourse(String type, String course_id, String data, int group) throws SQLException {
		String mini_id = course_id+"-"+group;
		MiniCourse course = CourseDB.getDB().loadMiniCourse(mini_id);
		switch (type) {
		case "capacity": {
			course.setCapacity(Integer.parseInt(data));
			break;
		}
		case "c_day": {
			course.setClassDay(data);
			break;
		}
		case "c_time": {
			course.setClassTime(data);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + type);
		}
		CourseDB.getDB().saveMiniCourse(course);
	}



	public void sendPingMain(int clientId, String id) throws SQLException { //TODO passed, taken, score, stat
		String pos = Database.getDB().getPosition(id);
		Person person;
		HashMap<String, String> chats_msgs = Database.getDB().chatDataMap(id); // chat listMessage
		Response response = new Response();
		
		if(pos.equals("Student")) {
			person = Database.getDB().loadStudent(id);
			response.addData("course_map", Database.getDB().studentCourseDataMap(id));
		} else {
			person = Database.getDB().loadTeacher(id);
			response.addData("courses", Database.getDB().teacherCourseDataList(id));
		}
		String personString = new Gson().toJson(person);
		
		response.addData("person", personString);
		response.addData("chats", chats_msgs);
		server.findClientAndSendResponse(clientId, response);
	}
	
	
	public void protest(int clientId, String id, String mini_id) throws SQLException {
		Student student = Database.getDB().loadStudent(id);
		student.addToProtested(mini_id);
		MiniCourse course = CourseDB.getDB().loadMiniCourse(mini_id);
		course.addToProtested(id);
		Database.getDB().saveStudent(student);
		CourseDB.getDB().saveMiniCourse(course);
	}



	public void sendProtestFeedbacks(int clientId, String id) throws SQLException {
		Student student = Database.getDB().loadStudent(id);
		LinkedList<String> feedbacks = new LinkedList<>();
		for(int i=0; i<student.getCoursesProtested().size(); i++) {
			feedbacks.add(student.getCoursesProtested().get(i)+"    "+student.getCoursesFeedbacks().get(i));
		}
		Response response = new Response();
		response.addData("list", feedbacks);
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendProtestStudents(int clientId, String mini_id) throws SQLException {
		MiniCourse course = CourseDB.getDB().loadMiniCourse(mini_id);
		ArrayList<String> pList = course.getProtestedStudents();
		LinkedList<String> list  = new LinkedList<>();
		try {
			for(String string : pList) {
				list.add(Database.getDB().loadStudent(string).getName()+"   "+string);
			}
		} catch (Exception e) {
		}
		Response response = new Response();
		response.addData("list", list);
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendProtestRespond(int clientId, String id, String mini_id, String stat) throws SQLException {
		Student student = Database.getDB().loadStudent(id);
		student.changeProtestStat(mini_id, stat);
		Database.getDB().saveStudent(student);
		MiniCourse course = CourseDB.getDB().loadMiniCourse(mini_id);
		course.removeProtest(id);
		CourseDB.getDB().saveMiniCourse(course);
	}



	public void sendIdByName(int clientId, String name) throws SQLException {
		String id = Database.getDB().getIdByName(name);
		Response response;
		if(id != null) {
			response = new Response(ResponseStatus.OK);
			response.addData("id", id);
		} else {
			response = new Response();
			response.addData("err", "err");
		}
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendCourseEduStat(int clientId, String mini_id) throws SQLException {
		Response response = new Response();
		response.addData("edu_stat", Database.getDB().getCourseEduStat(mini_id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendFullCourseScores(int clientId, String data) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().getFullScoreListForCourse(data));
		server.findClientAndSendResponse(clientId, response);
	}


	public void removeTeacher(int clientId, String id, String dep) throws SQLException {
		Teacher teacher = Database.getDB().loadTeacher(id);
		if(dep.equals(teacher.getDepartment())) { // TODO stus, course, messages
			Database.getDB().removeTeacher(id);
		}
	}


	public void changeDeputy(int clientId, String id, String dep) throws SQLException {
		String deputyId = Database.getDB().getDeputyByDep(dep);
		Teacher deputy = Database.getDB().loadTeacher(deputyId);
		Teacher newDep = Database.getDB().loadTeacher(id);
		deputy.setPosition("Teacher");
		newDep.setPosition("Deputy");
		Database.getDB().saveTeacher(deputy);
		Database.getDB().saveTeacher(newDep);
	}



	public void sendReqToTakeCourse(int clientId, String mini_id, String id) throws SQLException {
		String dep = Database.getDB().getDepartment(id);
		String depId = Database.getDB().getDeputyByDep(dep);
		MsgRequest request = new MsgRequest(ReqType.TAKE_COURSE, id + ":" + mini_id, id, depId);
		MsgDB.getDB().saveReq(request);
	}


	
	public void changeResponseToRequest(int clientId, int req_id, String resp) throws SQLException {
		MsgRequest request = MsgDB.getDB().loadReq(req_id);
		if(resp.equals("DENIED")) {
			request.setResponse(RespType.DENIED);
			MsgDB.getDB().saveReq(request);
		} else { // TODO complete
			ReqType type = request.getType();
			String owner = request.getOwner_id();
			String recp = request.getRec_id();
			request.setResponse(RespType.ACCEPTED);
			MsgDB.getDB().saveReq(request);
			
			switch (type) {
			case TAKE_COURSE: {
				String mini_id = request.getExp().split(":")[1];
				CourseDB.getDB().updateChosen(mini_id, owner, true);
				break;
			}
			case ASK_CHAT: {
				newChat(owner, recp);
				break;
			}
			case CHANGE_GROUP: {
				String g[] = request.getExp().split("\\s+");
				changeGroup(g[0], g[1], owner);
				break;
			}
			case MINOR: {
				String dep = request.getExp().split(" : ")[1]; 
				handleMinor(owner, dep, recp, true);
				break;
			}
			case MINOR_FINAL: {
				String[] s = request.getExp().split(" : "); 
				MsgRequest minor_req = MsgDB.getDB().getMinorReq(s[0], s[1]);
				minor_req.setResponse(RespType.FINAL);
				MsgDB.getDB().saveReq(minor_req);
				break;
			}
			case WITHDRAW: {
			//	removeStudent(owner);
				break;
			} default:
				break;
			}
		}
	}
	
	
	
	public void changeGroup(String last_mini_id, String mini_id, String id) throws SQLException {
		CourseDB.getDB().updateChosen(last_mini_id, id, false);
		CourseDB.getDB().updateChosen(mini_id, id, true);
	}
	
	
	public void correctCourses(String id) throws SQLException { //TODO run this shit
		Methods.correctPres(id);
		Methods.correctCons(id);
		
		LinkedList<String> final_chosen = CourseDB.getDB().getChosenIds(id);
		Student student = Database.getDB().loadStudent(id);
		ArrayList<String> courses = new ArrayList<>(final_chosen); //TODO check
		student.setCoursesList(courses);
		Database.getDB().saveStudent(student);
		for(String mini_id : courses) {
			CourseDB.getDB().updateTaken(mini_id, id, true);
		}
		logger.info("corrected");
	}


	public void sendAdminOfflineMessaged(int clientId, LinkedList<Message> messages, String id) throws SQLException {
		if(messages != null && messages.size()>0) {
			boolean chatExists = Database.getDB().chatExists(id, "1");
			if(!chatExists) {
				List<Integer> messages_id = new ArrayList<>();
				Chat chat = new Chat(id+"-1", id, "1", messages_id);
				Database.getDB().saveChat(chat);		
			}
			Database.getDB().updateAdminChats(id, messages);
		}
	}

	public void sendMediaAns(String id, Integer exc_id, String encode, String ext) throws SQLException {
		MediaDB.getDB().removeLastMedia(id, exc_id);
		Media media = new Media(id, exc_id, "Media", encode, ext);
		MediaDB.getDB().saveMedia(media);
		
		ExcDB.getDB().updateStatus(exc_id, id, "Media sent.");
		ExcDB.getDB().updateMedia(exc_id, id, media.getId());
	}


	public void sendRecomList(int clientId, String id) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().recomList(id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendRecomText(int clientId, String id, String teacher_id) throws SQLException {
		Response response = new Response();
		response.addData("text", Database.getDB().recomText(id, teacher_id));
		server.findClientAndSendResponse(clientId, response);
	}



	public void newStu(int clientId, Student student) throws SQLException {
		Database.getDB().saveStudent(student);
	}



	public void sendMohseniMediaResponse(int clientId, String encode, String ext, String recp) throws SQLException {
		String[] s = recp.split("`");
		LinkedList<String> ids = Database.getDB().getFilteredMohseni(s[0], s[1], s[2]);
		sendMediaToMultipleResponse("m", encode, ext, ids);
	}



	public void sendCertificateResponse(int clientId, String id) {
		Response response = new Response();
		response.addData("data", id + " is currently studying in Sharif university.");
		server.findClientAndSendResponse(clientId, response);
	}



	public void sendAllProtestsResponse(int clientId, String mini_id) throws SQLException {
		LinkedList<String> ids = CourseDB.getDB().getAllProtested(mini_id);
		LinkedList<String> allProtests = new LinkedList<>();
		for(String id : ids) {
			Student student = Database.getDB().loadStudent(id);
			allProtests.add(student.getProtestStatus(mini_id));
		}
		Response response = new Response();
		response.addData("list", allProtests);
		server.findClientAndSendResponse(clientId, response);
	}


	public void sendTeachTempResponse(int clientId, String teach_id) throws SQLException {
		Response response = new Response();
		response.addData("list", Database.getDB().teacherTempScores(teach_id));
		server.findClientAndSendResponse(clientId, response);
	}


	public void changePass(String id, String pass) throws SQLException {
		Database.getDB().updatePass(id, pass);
	}
	

	public void sendShouldChangePassResponse(int clientId, String id) throws SQLException {
		String last_visit = Database.getDB().getLastVisit(id);
		Response response = new Response();
		response.addData("data", Visit.isVisitDiffMoreThan3(last_visit));
		server.findClientAndSendResponse(clientId, response);
	}



	public void changeData(String id, String type, String data) throws SQLException {
		Database.getDB().updateData(id, type, data);
	}



	public void editTeacher(String id, String room, String degree, String m_id) throws SQLException {
		Teacher teacher = Database.getDB().loadTeacher(id);
		if(Database.getDB().getPosition(m_id).equals(Database.getDB().getPosition(id))) {
			teacher.setRoom(room);
			teacher.setTeacherDegree(getTeacherDegree(degree));
			Database.getDB().saveTeacher(teacher);
		} else {
			logger.info("Departments not equal");
		}
	}

	private TeacherDegree getTeacherDegree(String degree) {
		TeacherDegree teacherDegree;
		switch (degree) {
		case "TA": {
			teacherDegree = TeacherDegree.TA;
			break;
		} case "DY": {
			teacherDegree = TeacherDegree.DY;
			break;
		} default:
			teacherDegree = TeacherDegree.OT;
		}
		return teacherDegree;
	}


	public void addNewTeacher(String id, String user, String pass, String first, String last, String email,
			String phone, String code, String room, String degree, String m_id) throws SQLException {
		String dep = Database.getDB().getDepartment(m_id);
		Teacher teacher = new Teacher("Teacher",user, pass, first, last, email, phone, code, dep, getTeacherDegree(degree), room, id);
		Database.getDB().saveTeacher(teacher);
	}

	
}

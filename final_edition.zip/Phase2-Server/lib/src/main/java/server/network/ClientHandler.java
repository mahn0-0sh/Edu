package server.network;

import server.Server;
import shared.model.Person;
import shared.request.Request;
import org.codehaus.jackson.map.ObjectMapper;
import shared.response.Response;
import shared.util.Jackson;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

//import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.*;

import database.Database;


public class ClientHandler {
    private PrintStream printStream;
    private Scanner scanner;

    private ObjectMapper objectMapper;
    private final Server server;
    private Socket socket;

    private Person person;
    private final int clientId;
    private String iD;
    private String authToken;
    
    public void kill() throws IOException {
    	try {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            Database.getDB().updateLastVisit(dtf.format(LocalDateTime.now())+"", iD);
		} catch (Exception e) {
			// TODO: handle exception
		}
		socket.close();
		Server.server.clientDisconnected(this);
	}
    
    

	public String getiD() {
		return iD;
	}



	public void setiD(String iD) {
		this.iD = iD;
	}



	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	
	public ClientHandler(int clientId, Server server, Socket socket) {
        this.clientId = clientId;
        this.server = server;

        try {
        	this.socket = socket;
            printStream = new PrintStream(socket.getOutputStream());
            scanner = new Scanner(socket.getInputStream());
            objectMapper = Jackson.getNetworkObjectMapper();

            makeListenerThread();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void makeListenerThread() {
        Thread thread = new Thread(() -> {
            while (!socket.isClosed()) {
                try {
                	String requestString = scanner.nextLine();
                    try {
                        Request request = objectMapper.readValue(requestString, Request.class);
                        handleRequest(request);
                    } catch (IOException | SQLException e) {
                        e.printStackTrace();
                    }
				} catch (Exception e2) {
					try {
						kill();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
            }
        });
        thread.start();
    }

    private void handleRequest(Request request) throws SQLException, IOException {
    	String token = (String) request.getData("token");
    	if(token == null || token.equals(authToken)) {
    		server.handleRequest(clientId, request);    		
    	}
    	else kill();
    }

    public void sendResponse(Response response) {
        try {
            String responseString = objectMapper.writeValueAsString(response);
            printStream.println(responseString);
            printStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getId() {
        return clientId;
    }

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}
}

package server;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import constants.Constants;
import database.CourseDB;
import database.Database;
import database.MsgDB;
import database.PersonDB;
import enums.Departments;
import enums.ReqType;
import enums.Status;
import enums.StudentDegree;
import enums.TeacherDegree;
import shared.model.Chat;
import shared.model.Course;
import shared.model.Message;
import shared.model.MiniCourse;
import shared.model.MsgAnnounce;
import shared.model.MsgRequest;
import shared.model.Person;
import shared.model.Student;
import shared.model.Teacher;
import shared.util.*;

public class ServerMain {

	public static void main(String[] args) {
		Integer port = Config.getConfig().getProperty(Integer.class, "serverPort");
		
		String url = new Config(Constants.CONFIG_ADDRESS).getProperty(String.class, "db_url");
        String username = new Config(Constants.CONFIG_ADDRESS).getProperty(String.class, "db_username");
        String password = new Config(Constants.CONFIG_ADDRESS).getProperty(String.class, "db_password");
        
        // havaset bashe az aval bezani data hat null mishan
        try
        {
            Database.getDB().connectToDatabase(url, username, password);
            System.out.println("weee");
        }
        catch (SQLException throwable)
        {
            System.err.println(throwable);
        }
        
        
        Server server = new Server(port);
        server.start();
	}
	
	static Student createStudent() {
		/*
		 * String position, String username, String password, String firstname, String lastname, String email,
			String phoneNumber,String id, String code, String lastVisit, String lastExit, String lastPass,
			Map coursesList, ArrayList<Double> scoresList, ArrayList<String> tempCoursesList,
			ArrayList<Double> tempScoresList, Departments department, StudentDegree degree, Status status,
			String supervisor, String yearOfArrival, String mojavez, String signUpTime, String withdrawalFeedback,
			ArrayList<String> coursesProtested, ArrayList<String> coursesFeedbacks, ArrayList<String> recomReqTeachers,
			ArrayList<String> recomFeedbacks, ArrayList<String> minorReqDepartments,
			ArrayList<String> minorReqFeedbacks, Map checked, Map chosen, Map passed
		 */
		
		ArrayList<String> courses = new ArrayList<>();
		
	/*	Student student = new Student("Student", "0b", "0b", "Mahnoosh", "Azimian", "mah@gmail.com", "0904",
				"0b", "020", null, null, null, courses, null, null, null, "Math", StudentDegree.BACHELOR, Status.STUDYING,
				"0t", "1400", null, null, null, null, null, null, null, null, null, null, null, null); */
	/*	Student student = new Student("Student", "2b", "2b", "Ali", "Hosseini", "ali@gmail.com", "0904",
				"2b", "020", null, null, null, courses, null, null, null, "Math", StudentDegree.BACHELOR, Status.STUDYING,
				"0t", "1400", null, null, null, null, null, null, null, null, null, null, null, null); */
		Student student = new Student("Student", "3b", "3b", "Sara", "Amiri", "sara@gmail.com", "0904",
				"3b", "020", null, null, null, courses, null, null, null, "CE", StudentDegree.BACHELOR, Status.STUDYING,
				"1t", "1400", null, null, null, null, null, null, null, null, null, null, null, null);
		return student;
	}
	
	static Teacher createTeacher() {
		/*
		 * String position, String username, String password, String firstname, String lastname, String email,
			String phoneNumber,String id, String code, String lastVisit, String lastExit, String lastPass
			,ArrayList<String> incomMinorReqStudents, ArrayList<String> outgoMinorReqStudents,
			ArrayList<String> scoresRegByTeacher, ArrayList<String> recomReqStudents,
			ArrayList<String> withdrawReqStudents, Departments department, TeacherDegree teacherDegree, String room
		 */
	/*	Teacher teacher = new Teacher("Teacher", "0t", "0t", "Saeed", "Akbari", "sakbari@gm.com", 
				"0912", "0t", "010", null, null, null, null, null, null, null, null,
				"Math", TeacherDegree.OT, "0-A"); */
		Teacher teacher = new Teacher("Teacher", "1t", "1t", "Amir", "Majidi", "amrj@gm.com", 
				"0912", "1t", "010", null, null, null, null, null, null, null, null,
				"CE", TeacherDegree.OT, "0-C");
		return teacher;
	}
	
	
	static Teacher createDeputy() {
		Teacher teacher = new Teacher("Deputy", "0d", "0d", "Shahram", "Khazaei", "shr@gm.com", 
				"0912", "0d", "010", null, null, null, null, null, null, null, null,
				"Math", TeacherDegree.OT, "0-D");
		return teacher;
	}
	
	
	static Teacher createManager() {
		Teacher teacher = new Teacher("Manager", "0m", "0m", "Matin", "Hasani", "mtn@gm.com", 
				"0912", "0m", "010", null, null, null, null, null, null, null, null,
				"Math", TeacherDegree.OT, "0-M");
		return teacher;
	}
	
	static MiniCourse createCourse() {
		/*
		 * String courseID, String name, int courseCredit, List teachers, String preID, String conID,
			Map groups, ArrayList<String> tAssisstants, Departments department, StudentDegree courseDegree,
			String examDate, String examTime, String classDay, String classTime,
			ArrayList<Double> tempNotRegisteredScores, ArrayList<Double> tempRegisteredScores,
			ArrayList<String> protestedStudents
		 */
	/*	MiniCourse miniCourse = new MiniCourse("1", "Calculus", 4, null, null, "Math", StudentDegree.BACHELOR, 
				"1401/04/03", "14-16", "0t", "Monday", "08-10", 1); */
		
		MiniCourse miniCourse = new MiniCourse("2", "Linear Algebra", 4, null, null, "Math", StudentDegree.BACHELOR, 
				"1401/04/04", "12-14", "0t", "Sunday", "09-11", 1, 12);
		return miniCourse;
	}
	
	
	static Person createAdmin() {
		Person person = new Person("Admin", "1", "1", "", "", "edu@edu.edu", null, "1", null, null, null, null);
		return person;
	}
	
	static Person createMohsen() {
		Person person = new Person("Mohseni", "m", "m", "", "", "mohseni@edu.edu", null, "m", null, null, null, null);
		return person;
	}

}

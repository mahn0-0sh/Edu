package server;

import server.network.ClientHandler;
import shared.model.Chat;
import shared.model.Course;
import shared.model.Message;
import shared.model.Person;
import shared.model.Student;
import shared.request.Request;
import shared.response.Response;
import shared.response.ResponseStatus;
import shared.util.Config;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

import database.Database;
import enums.ReqType;

public class Server {
    private final ArrayList<ClientHandler> clients; // All of clients
    private static int clientCount = 0;
    public static Server server;

    private ServerSocket serverSocket;
    private Library library;

    private final int port;
    private boolean running;
    
    private ResponseHandler responseHandler;

    public Server(int port) {
        this.port = port;
        clients = new ArrayList<>();
        server = this;
    }
    

    public void start() {
        try {
            serverSocket = new ServerSocket(port);
            running = true;

            initializeLibrary();
            listenForNewConnection();
        } catch (IOException e) {
            e.printStackTrace(); // Failed to run the server
        }
    }

    @SuppressWarnings("unused")
    public void stop() {
        try {
            serverSocket.close();
            running = false;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initializeLibrary() {
        // Load library from database
    	responseHandler = new ResponseHandler(this);
        library = new Library();
    }

    private void listenForNewConnection() {
        while (running) {
            try {
                clientCount++;
                Socket socket = serverSocket.accept();
                ClientHandler clientHandler = new ClientHandler(clientCount, this, socket);
                clients.add(clientHandler);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @SuppressWarnings("unused")
    public void clientDisconnected(ClientHandler clientHandler) {
        // Remove client from clients
        clients.remove(clientHandler);
    }

    public void handleRequest(int clientId, Request request) throws SQLException {
        boolean result;
        
        switch (request.getRequestType()) {
            case PING -> {
            	Response response = new Response(ResponseStatus.ALIVE);
                findClientAndSendResponse(clientId, response);
            }
            case PING_MAIN -> {
                responseHandler.sendPingMain(clientId, (String) request.getData("id"));
            }
            case LOGIN -> {
                result = library.canLogin((String) request.getData("username"), (String) request.getData("password"));
                responseHandler.sendLoginResponse(clientId, result, (String) request.getData("username"));
            }
            case MAIN_STATUS -> {
            	responseHandler.sendMainPageResponse(clientId, (String) request.getData("username"));
            }
            case PROFILE -> {
            	responseHandler.sendProfileResponse(clientId, (String) request.getData("username"));
            }
            case FULL_COURSE -> {
            	responseHandler.sendFilterCourseResponse(clientId, (String) request.getData("type"), (String) request.getData("by"));
            }
            case TEACHER_LIST -> {
            	responseHandler.sendTeacherListResponse(clientId);
            }
            case MINI_BY_DEP -> {
            	responseHandler.sendMiniByDepResponse(clientId, (String) request.getData("department"), (String) request.getData("sort"));
            }
            case CHOOSE_COURSE -> {
            	responseHandler.sendChooseResponse(clientId, (String) request.getData("mini_id"), (String) request.getData("id"));
            }
            case DELETE_COURSE -> {
            	responseHandler.sendDeleteResponse(clientId, (String) request.getData("mini_id"), (String) request.getData("id"));
            }
            case COURSE_STATUS -> {
            	responseHandler.sendCourseStatusResponse(clientId, (String) request.getData("mini_id"), (String) request.getData("id"));
            }
            case COURSE_GROUPS -> {
            	responseHandler.sendCourseGroupsResponse(clientId, (String) request.getData("course_id"));
            }
            case CHANGE_GROUP -> { //TODO
            	responseHandler.sendChangeGroupResponse(clientId, (String) request.getData("mini_id"), (String) request.getData("course_id"), (int) request.getData("group"), (String) request.getData("id"));
            }
            case REQ_TAKE_COURSE -> { //TODO
            	responseHandler.sendReqToTakeCourse(clientId, (String) request.getData("mini_id"), (String) request.getData("id"));
            }
            case CHANGE_CHECKED -> {
            	responseHandler.sendChangeCheckedResponse(clientId, (String) request.getData("mini_id"), (String) request.getData("id"));
            }
            case CHECKED_LIST -> {
            	responseHandler.sendCheckMapResponse(clientId, (String) request.getData("id"));
            }
            case SUG_LIST -> {
            	responseHandler.sendSugMapResponse(clientId, (String) request.getData("id"));
            }
            case CHAT -> {
            	responseHandler.sendChatResponse(clientId, (Integer) request.getData("chatID"));
            }
            case GET_MESSAGES -> {
            	responseHandler.sendGetMessagesResponse(clientId, (Integer) request.getData("chatID"));
            }
            case SEND_MESSAGE -> {
            	responseHandler.sendSendMessageResponse(clientId, (Integer) request.getData("chat"), (String) request.getData("id"), (String) request.getData("other_id"), (String) request.getData("message"));
            }
            case SEND_FILE -> {
            	responseHandler.sendSendFileResponse(clientId, (Integer) request.getData("chatID"), (String) request.getData("id"), (String) request.getData("other_id"), (String) request.getData("encode"), (String) request.getData("extension"));
            }
            case NEW_CHAT -> {
            	responseHandler.sendNewChatResponse(clientId, (String) request.getData("id"), (String) request.getData("other_id"));
            }
            case GET_FULL_CHATS -> {
            	responseHandler.sendGetFullChatsResponse(clientId, (String) request.getData("id"));
            }
            case SEND_TO_MULTIPLE -> {
            	responseHandler.sendToMultipleResponse(clientId, (String) request.getData("id"), (LinkedList<String>) request.getData("ids"), (String) request.getData("text"));
            }
            case GET_MY_CHATS -> {
            	responseHandler.sendGetMyChatsResponse(clientId, (String) request.getData("id"));
            }
            case CHAT_ID -> {
            	responseHandler.sendChatIdResponse(clientId, (String) request.getData("id"), (String) request.getData("other_id"));
            }
            case GET_POS_TYPE -> {
            	responseHandler.sendGetPosTypeResponse(clientId, (String) request.getData("course_id"), (String) request.getData("id"));
            }
            case GET_MY_COURSES -> {
            	responseHandler.sendGetMyCoursesResponse(clientId, (String) request.getData("id"), (String) request.getData("position"));
            }
            case CREATE_EXC -> {
            	responseHandler.sendCreateExcResponse(clientId, (String) request.getData("mini_id"), (String) request.getData("name"), (String) request.getData("exp"), (String) request.getData("open"), (String) request.getData("close"), (String) request.getData("mohlat"), (String) request.getData("type"), (String) request.getData("pdf"));
            }
            case GET_COURSE_EXCS -> {
            	responseHandler.sendGetCourseExcResponse(clientId, (String) request.getData("id"));
            }
            case EXC_STATUS -> {
            	responseHandler.sendExcStatusResponse(clientId, (Integer) request.getData("id"));
            }
            case EXC_PDF -> {
            	responseHandler.sendExcPDFResponse(clientId, (Integer) request.getData("id"));
            }
            case TEXT_ANS -> {
            	responseHandler.sendTextAnsResponse(clientId, (String) request.getData("id"), (Integer) request.getData("mini_id"), (String) request.getData("text"));
            }
            case EXC_SENT -> {
            	responseHandler.sendExcSentResponse(clientId, (Integer) request.getData("id"));
            }
            case EXC_STU_MEDIA -> {
            	responseHandler.sendExcStuMediaResponse(clientId, (String) request.getData("id"), (Integer) request.getData("exc_id"));
            }
            case GRADE_EXC -> {
            	responseHandler.sendGradeExcResponse(clientId, (String) request.getData("id"), (Integer) request.getData("exc_id"), (Double) request.getData("score"));
            }
            case GET_INFO -> { //TODO
            	responseHandler.sendGetInfosResponse(clientId);
            }
            case MOHSENI_PRO -> { //TODO
            	responseHandler.sendStudentProfileResponse(clientId, (String) request.getData("id"));
            }
            case GET_COURSE_SUBJ -> {
            	responseHandler.sendGetCourseSubjResponse(clientId, (String) request.getData("id"));
            }
            case NEW_SUBJ -> {
            	responseHandler.sendNewSubjResponse(clientId, (String) request.getData("mini_id"), (String) request.getData("name"));
            }
            case NEW_TEXT_ITEM -> {
            	responseHandler.sendNewTextItemResponse(clientId, (Integer) request.getData("subj_id"), (String) request.getData("text"));
            }
            case NEW_MEDIA_ITEM -> {
            	responseHandler.sendNewMediaItemResponse(clientId, (Integer) request.getData("subj_id"), (String) request.getData("encode"), (String) request.getData("ext"));
            }
            case ITEM_NUM -> {
            	responseHandler.sendItemsNumberResponse(clientId, (Integer) request.getData("subj_id"));
            }
            case ITEMS_INFO -> {
            	responseHandler.sendItemsInfoResponse(clientId, (Integer) request.getData("subj_id"));
            }
            case ITEM_TEXT -> {
            	responseHandler.sendItemTextResponse(clientId, (Integer) request.getData("item_id"));
            }
            case ITEM_BASE64 -> {
            	responseHandler.sendItemBase64Response(clientId, (Integer) request.getData("item_id"));
            }
            case EDIT_TEXT -> {
            	responseHandler.sendItemEditTextResponse(clientId, (Integer) request.getData("item_id"), (String) request.getData("text"));
            }
            case EDIT_MEDIA -> {
            	responseHandler.sendItemEditMediaResponse(clientId, (Integer) request.getData("item_id"), (String) request.getData("encode"), (String) request.getData("ext"));
            }
            case DELETE_ITEM -> {
            	responseHandler.sendDeleteItemResponse(clientId, (Integer) request.getData("item_id"));
            }
            case DELETE_SUBJ -> {
            	responseHandler.sendDeleteSubjResponse(clientId, (Integer) request.getData("subj_id"));
            }
            case ANC_LIST -> {
            	responseHandler.sendAncListResponse(clientId, (String) request.getData("id"));
            }
            case REQ_LIST -> {
            	responseHandler.sendReqListResponse(clientId, (String) request.getData("id"));
            }
            case RESP_LIST -> {
            	responseHandler.sendRespListResponse(clientId, (String) request.getData("id"));
            }
            case ANC_TEXT -> {
            	responseHandler.sendAncTextResponse(clientId, (Integer) request.getData("id"));
            }
            case REQ_INFO -> {
            	responseHandler.sendReqInfoResponse(clientId, (Integer) request.getData("id"));
            }
            case OTHER_NAME -> {
            	responseHandler.sendOtherNameResponse(clientId, (String) request.getData("other_id"));
            }
            case OTHER_BASE64 -> {
            	responseHandler.sendOtherBase64Response(clientId, (String) request.getData("other_id"));
            }
            case ASK_CHAT -> {
            	responseHandler.sendAskChatResponse(clientId, (String) request.getData("id"), (String) request.getData("other_id"));
            }
            case ADD_TO_COURSE -> {
            	responseHandler.sendAddToCourseResponse(clientId, (String) request.getData("course_id"), (String) request.getData("type"), (String) request.getData("id"));
            }
            case ADD_TO_COURSE_ANC -> {
            	responseHandler.sendAddToCourseAncResponse(clientId, (String) request.getData("course_id"), (String) request.getData("type"), (String) request.getData("id"));
            }
            case COURSE_CAL -> {
            	responseHandler.sendCourseCalResponse(clientId, (String) request.getData("course_id"));
            }
            case EXC_SORT -> {
            	responseHandler.sendExcSortResponse(clientId, (String) request.getData("mini_id"), (String) request.getData("sort"));
            }
            case EXC_SCORE -> {
            	responseHandler.sendExcScoreResponse(clientId, (String) request.getData("id"), (Integer) request.getData("exc_id"));
            }
            case EXC_DEL_STATUS -> {
            	responseHandler.sendExcDelStatusResponse(clientId, (String) request.getData("id"), (Integer) request.getData("exc_id"));
            } 
            case STU_CAL -> {
            	responseHandler.sendStuCalResponse(clientId, (String) request.getData("id"));
            } 
            case TEACHER_CAL -> {
            	responseHandler.sendTeacherCalResponse(clientId, (String) request.getData("id"));
            } 
            case MOHSENI_TEXT -> {
            	responseHandler.sendMohseniTextResponse(clientId, (String) request.getData("text"), (String) request.getData("recp"));
            } 
            case EXAM_SCHD -> {
            	responseHandler.sendExamSchd(clientId, (String) request.getData("id"));
            } 
            case WEEK_SCHD -> {
            	responseHandler.sendWeekSchd(clientId, (String) request.getData("id"));
            } 
            case TEMP_SCORES -> {
            	responseHandler.sendTempScores(clientId, (String) request.getData("id"));
            } 
            case FULL_SCORES -> {
            	responseHandler.sendFullScores(clientId, (String) request.getData("id"));
            } 
            case CREDITS -> {
            	responseHandler.sendCredits(clientId, (String) request.getData("id"));
            } 
            case GPA -> {
            	responseHandler.sendGPA(clientId, (String) request.getData("id"));
            } 
            case COURSE_SCORES -> {
            	responseHandler.sendScoreListForCourse(clientId, (String) request.getData("mini_id"));
            }
            case TEMP_REG -> {
            	responseHandler.sendTempReg(clientId, (String) request.getData("mini_id"), (HashMap<String, Double>) request.getData("hashMap"));
            }
            case FIN_REG -> {
            	responseHandler.sendFinReg(clientId, (String) request.getData("mini_id"), (HashMap<String, Double>) request.getData("hashMap"));
            }
            case ADD_NEW_COURSE -> {
            	responseHandler.sendAddNewCourseResponse(clientId, (String) request.getData("id"), (String) request.getData("name"), (Integer) request.getData("groups"), (String) request.getData("degree"), (Integer) request.getData("credit"), (String) request.getData("dep"));
            }
            case STU_REQ -> {
            	responseHandler.sendStuReqResponse(clientId, (ReqType) request.getData("reqType"), (String) request.getData("recp"), (String) request.getData("dep"), (String) request.getData("id"));
            }
            case GET_DEGREE -> {
            	responseHandler.sendGetDegreeResponse(clientId, (String) request.getData("id"));
            }
            case SET_CHOOSE_TIME -> {
            	responseHandler.sendSetChooseTimeResponse(clientId, (Integer) request.getData("year"), (String) request.getData("dep"), (String) request.getData("time"));
            }
            case PROTEST -> {
            	responseHandler.protest(clientId, (String) request.getData("id"), (String) request.getData("mini_id"));
            }
            case PROTEST_FEED -> {
            	responseHandler.sendProtestFeedbacks(clientId, (String) request.getData("id"));
            }
            case PROTEST_STUDENTS -> {
            	responseHandler.sendProtestStudents(clientId, (String) request.getData("mini_id"));
            }
            case PROTEST_RESPOND -> {
            	responseHandler.sendProtestRespond(clientId, (String) request.getData("id"), (String) request.getData("mini_id"), (String) request.getData("stat"));
            }
            case ID_BY_NAME -> {
            	responseHandler.sendIdByName(clientId, (String) request.getData("name"));
            }
            case COURSE_EDU_STAT -> {
            	responseHandler.sendCourseEduStat(clientId, (String) request.getData("mini_id"));
            }
            case FULL_COURSE_SCORES -> {
            	responseHandler.sendFullCourseScores(clientId, (String) request.getData("mini_id"));
            }
            case REMOVE_TEACHER -> {
            	responseHandler.removeTeacher(clientId, (String) request.getData("id"), (String) request.getData("dep"));
            }
            case CHANGE_DEPUTY -> {
            	responseHandler.changeDeputy(clientId, (String) request.getData("id"), (String) request.getData("dep"));
            }
            case RES_TO_REQ -> {
            	responseHandler.changeResponseToRequest(clientId, (Integer) request.getData("req_id"), (String) request.getData("resp"));
            }
            case ADMIN_OFF_MSG -> {
            	responseHandler.sendAdminOfflineMessaged(clientId, (LinkedList<Message>) request.getData("messages"), (String) request.getData("id"));
            }
            case CORRECT -> {
            	responseHandler.correctCourses((String) request.getData("id"));
            }
            case MEDIA_ANS -> {
            	responseHandler.sendMediaAns((String) request.getData("id"), (Integer) request.getData("exc_id"), (String) request.getData("encode"), (String) request.getData("ext"));
            }
            case RECOM_LIST -> {
            	responseHandler.sendRecomList(clientId, (String) request.getData("id"));
            }
            case RECOM_TEXT -> {
            	responseHandler.sendRecomText(clientId, (String) request.getData("id"), (String) request.getData("teacher_id"));
            }
            case NEW_STU -> {
            	responseHandler.newStu(clientId, (Student) request.getData("stu"));
            }
            case MOHSENI_MEDIA -> {
            	responseHandler.sendMohseniMediaResponse(clientId, (String) request.getData("encode"), (String) request.getData("ext"), (String) request.getData("recp"));
            }
            case CERTIFICATE -> {
            	responseHandler.sendCertificateResponse(clientId, (String) request.getData("id"));
            }
            case ALL_PROTESTS -> {
            	responseHandler.sendAllProtestsResponse(clientId, (String) request.getData("mini_id"));
            }
            case TEACH_TEMP -> {
            	responseHandler.sendTeachTempResponse(clientId, (String) request.getData("teach_id"));
            }
            case PASS_CHANGE -> {
            	responseHandler.changePass((String) request.getData("id"), (String) request.getData("pass"));
            }
            case SHOULD_CHANGE_PASS -> {
            	responseHandler.sendShouldChangePassResponse(clientId, (String) request.getData("id"));
            }
            case CHANGE_DATA -> {
            	responseHandler.changeData((String) request.getData("id"), (String) request.getData("type"), (String) request.getData("data"));
            }
            case FILE_TO_MULTIPLE -> {
            	responseHandler.sendMediaToMultipleResponse((String) request.getData("id"), (String) request.getData("encode"), (String) request.getData("ext"), (LinkedList<String>) request.getData("ids"));
            }
            case EDIT_TEACHER -> {
            	responseHandler.editTeacher((String) request.getData("id"), (String) request.getData("room"), (String) request.getData("degree"), (String) request.getData("m_id"));
            }
            case ADD_TEACHER -> {
            	responseHandler.addNewTeacher((String) request.getData("id"), (String) request.getData("user"), (String) request.getData("pass"), (String) request.getData("first"), (String) request.getData("last"), (String) request.getData("email"), (String) request.getData("phone"), (String) request.getData("code"), (String) request.getData("room"), (String) request.getData("degree"), (String) request.getData("m_id"));
            }
		    case EXIT -> {
		    	sendExitResponse(clientId, (String) request.getData("username"));
		    }
		    
		default -> throw new IllegalArgumentException("Unexpected value: " + request.getRequestType());
        } //TODO
    }

   

	private void sendExitResponse(int clientId, String data) throws SQLException {
        try {
			getClientHandler(clientId).kill();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	ClientHandler getClientHandler(int clientId) {
        for(ClientHandler clientHandler: clients) {
            if (clientHandler.getId() == clientId) {
                return clientHandler;
            }
        }
        return null;
    }

    void findClientAndSendResponse(int clientId, Response response) {
        ClientHandler clientHandler = getClientHandler(clientId);
        if (clientHandler != null) {
            clientHandler.sendResponse(response);
        }
    }


	public void setId(int clientId, String id) {
		getClientHandler(clientId).setiD(id);
	}
	
}

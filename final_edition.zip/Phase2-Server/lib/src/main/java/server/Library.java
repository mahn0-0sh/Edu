package server;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import database.Database;
import shared.model.*;

public class Library {

    private int lastId = 0;

    public Library() {
    }

 /*   public boolean isStudent(String username, String password) {
    	System.out.println(username+" "+password+" "+Person.validLoginS(username, password));
        return Person.validLoginS(username, password);
    } */
    
    public boolean canLogin(String username, String password) throws SQLException {
    	boolean b = Database.getDB().validLogin(username, password);
		return b;
    }
    
    public static boolean courseClassMix(MiniCourse course1, MiniCourse course2) {
    	if(course1.getMiniCourseID().equals(course2.getMiniCourseID())) return false;
    	
    	if(course1.getClassDay().equals(course2.getClassDay())) {
    		
    		String[] t1 = course1.getClassTime().split("-");
        	String[] t2 = course2.getClassTime().split("-");
        	
        	if(t2[0].compareTo(t1[1]) > 0 || t2[1].compareTo(t1[0]) < 0) return false;
        	return true;   	
    	
    	} else {
			return false;
		}
	}
    
    public static boolean courseExamMix(Course course1, Course course2) {
    	if(course1.getCourseID().equals(course2.getCourseID())) return false;
    	if(course1.getExamDate().equals(course2.getExamDate())) {
    		String[] t1 = course1.getExamTime().split("-");
        	String[] t2 = course2.getExamTime().split("-");
        	if(t2[0].compareTo(t1[1]) > 0 || t2[1].compareTo(t1[0]) < 0) return false;
        	return true;    	
    	} else {
			return false;
		}
	}
    
    public static boolean prePassed(LinkedList<String> passed, Course course) {
    	List<String> preIds = course.getPreID();
    	try {
    		preIds.size();
		} catch (Exception e) {
			// TODO: handle exception
			preIds = new ArrayList<String>();
		}
		boolean b = true;
		if(preIds.size() != 0) {
			for(String string : preIds) {
				if(!passed.contains(string)) b &= false;
			}		
		}
		return b;
	}
    
    
    public static boolean conChose(ArrayList<String> chosen_and_passed, Course course) {
    	List<String> conIds = course.getConID();
    	try {
    		conIds.size();
		} catch (Exception e) {
			// TODO: handle exception
			conIds = new ArrayList<String>();
		}
		boolean b = true;
		if(conIds.size() != 0) {
			for(String string : conIds) {
				if(!chosen_and_passed.contains(string)) b &= false;
			}		
		}
		return b;
	}
    
    
    

   
}

-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: phase2
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stu_course`
--

DROP TABLE IF EXISTS `stu_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stu_course` (
  `student_id` varchar(45) DEFAULT NULL,
  `course_id` varchar(45) DEFAULT NULL,
  `checked` tinyint DEFAULT '0',
  `chosen` tinyint DEFAULT '0',
  `taken` tinyint DEFAULT '0',
  `score` double DEFAULT '-1',
  `type` varchar(45) DEFAULT 'Student',
  `passed` tinyint DEFAULT '0',
  `course` varchar(45) DEFAULT NULL,
  `score_stat` varchar(45) DEFAULT 'N/A',
  KEY `c_key_idx` (`course_id`),
  KEY `s_key_idx` (`student_id`),
  KEY `coursee_idx` (`course`),
  CONSTRAINT `course_key` FOREIGN KEY (`course_id`) REFERENCES `minicourses` (`mini_id`) ON DELETE CASCADE,
  CONSTRAINT `coursee` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stu_key` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stu_course`
--

LOCK TABLES `stu_course` WRITE;
/*!40000 ALTER TABLE `stu_course` DISABLE KEYS */;
INSERT INTO `stu_course` VALUES ('0b','1-1',1,1,1,16.5,'Student',1,'1','Reg'),('0b','2-1',1,1,1,-1,'Student',0,'2','N/A'),('3b','1-1',0,0,0,-1,'TA',0,'1','N/A'),('1b','1-1',0,0,1,17,'Student',1,'1','Reg'),('0b','3-2',0,1,1,-1,'Student',0,'3','N/A'),('0b','3-3',0,0,0,-1,'Student',0,'3','N/A'),('0b','3-1',0,0,0,-1,'Student',0,'3','N/A'),('1b','3-1',1,1,0,-1,'Student',0,'3','N/A'),('1b','3-2',0,0,0,-1,'Student',0,'3','N/A'),('1b','2-1',0,0,0,-1,'Student',0,'2','N/A');
/*!40000 ALTER TABLE `stu_course` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-16  2:47:01

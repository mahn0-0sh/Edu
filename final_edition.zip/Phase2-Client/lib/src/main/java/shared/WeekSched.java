package shared;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import client.ConnectionStatus;
import login.PhaseController;
import student.StudentMain;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.LinkedList;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class WeekSched extends JFrame {

	private JPanel contentPane = new JPanel();
	private PhaseController controller = new PhaseController();
	private LinkedList<String> schd;

	
	public WeekSched(LinkedList<String> schd) {
		this.schd = schd;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Course");
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(10, 11, 197, 14);
		contentPane.add(lblNewLabel);
		
		
		JLabel lblDay = new JLabel("Day");
		lblDay.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 13));
		lblDay.setBounds(217, 11, 113, 14);
		contentPane.add(lblDay);
		
		JLabel label = new JLabel("Time");
		label.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 13));
		label.setBounds(340, 12, 59, 14);
		contentPane.add(label);
		
		JLabel lblDuration = new JLabel("Duration");
		lblDuration.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 13));
		lblDuration.setBounds(409, 11, 67, 14);
		contentPane.add(lblDuration);
		
		JButton btnNewButton = new JButton("Home page");
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					controller.visitHome();
			}
		});
		btnNewButton.setBounds(539, 45, 121, 23);
		contentPane.add(btnNewButton);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnExit.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnExit.setBounds(539, 11, 121, 23);
		contentPane.add(btnExit);
		
		refresh();
		
	}


	public void refresh() { // graphics problem ping
		if(ConnectionStatus.getStatus().isOnline()) schd = controller.getWeekSchd();
		if(schd != null) UpdatePane.updateSchedList(contentPane, schd);
		else controller.visitHome();
	}
}

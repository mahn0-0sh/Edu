package shared;
import java.awt.Font;
import java.awt.TextField;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import student.EducationalStatus;
import student.StudentMain;
import teacher.TeacherMain;

public class UpdatePane {

	
	public static void updateSchedList(JPanel contentPane, LinkedList<String> exams) {
		int a=0;
		for(int i=0; i<exams.size(); i++) {
			JLabel lblNewLabel_2 = new JLabel(exams.get(i));
			lblNewLabel_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 15));
			lblNewLabel_2.setBounds(10, 36+25*a, 424, 14);
			contentPane.add(lblNewLabel_2);
			a++;
		}
	}
	
	
	
	public static void updateExamList(JPanel contentPane, LinkedList<String> exams) {
		int a=0;
		for(int i=0; i<exams.size(); i++) {
			JLabel lblNewLabel_2 = new JLabel(exams.get(i));
			lblNewLabel_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 15));
			lblNewLabel_2.setBounds(10, 36+25*a, 424, 14);
			contentPane.add(lblNewLabel_2);
			a++;
		}
	}
	
	
	public static void updateTempScores(JPanel contentPane, LinkedList<String> exams) {
		int a=0;
		for(int i=0; i<exams.size(); i++) {
			JLabel lblNewLabel_2 = new JLabel(exams.get(i));
			lblNewLabel_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 15));
			lblNewLabel_2.setBounds(10, 36+25*a, 424, 14);
			contentPane.add(lblNewLabel_2);
			a++;
		}
	}
	
	
	public static void updateFinalScores(JPanel contentPane, LinkedList<String> exams) {
		int a=0;
		for(int i=0; i<exams.size(); i++) {
			JLabel lblNewLabel_2 = new JLabel(exams.get(i));
			lblNewLabel_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 15));
			lblNewLabel_2.setBounds(10, 36+25*a, 424, 14);
			contentPane.add(lblNewLabel_2);
			a++;
		}
	}
	
	
}

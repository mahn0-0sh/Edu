package shared;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import client.ConnectionStatus;
import login.PhaseController;
import student.StudentMain;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.awt.event.ActionEvent;

public class ExamSched extends JFrame {

	private JPanel contentPane;
	private PhaseController controller = new PhaseController();
	private LinkedList<String> examsList;



	public ExamSched(LinkedList<String> examsList) {
		this.examsList = examsList;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Exams:");
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 15));
		lblNewLabel.setBounds(10, 11, 154, 14);
		contentPane.add(lblNewLabel);
		
		
		
		//Exit
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 9));
		btnNewButton.setBounds(623, 9, 89, 23);
		contentPane.add(btnNewButton);
		
		
		
		JButton btnHomepage = new JButton("Homepage");
		btnHomepage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnHomepage.setFont(new Font("Traditional Arabic", Font.PLAIN, 9));
		btnHomepage.setBounds(623, 43, 89, 23);
		contentPane.add(btnHomepage);
		
		refresh();
	}



	public void refresh() {
		if(ConnectionStatus.getStatus().isOnline())	examsList = controller.getExamSchd(); 
		if(examsList != null) UpdatePane.updateExamList(contentPane, examsList);
		else controller.visitHome();
	}
}

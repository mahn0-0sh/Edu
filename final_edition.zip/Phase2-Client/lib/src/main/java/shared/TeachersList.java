package shared;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.LogginWindow;
import login.PhaseController;
import teacher.manager.ManagerEditPage;

import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JList;

public class TeachersList extends JFrame {

	private JPanel contentPane = new JPanel();
	private DefaultListModel dListModel = new DefaultListModel();
	private PhaseController controller = new PhaseController();
	private String position;
	private JList list;

	
	private void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}

	private void btns() {
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 9));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton.setBounds(591, 8, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnHomepage = new JButton("Homepage");
		btnHomepage.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		controller.visitHome();
	    	}
	    });
		btnHomepage.setFont(new Font("Traditional Arabic", Font.PLAIN, 9));
		btnHomepage.setBounds(591, 42, 89, 23);
		contentPane.add(btnHomepage);
	}
	
	public TeachersList() {
		position = controller.getPosition();
		initPane();
		btns();
		
		
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 8, 571, 394);
		contentPane.add(scrollPane);
		
		list = new JList();
		list.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		scrollPane.setViewportView(list);
		
		
		
		try {
			if(position.equals("Manager")) {
				JButton btnEdit = new JButton("Edit");
				btnEdit.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						controller.showManagerEditPage();
					}
				});
				btnEdit.setFont(new Font("Traditional Arabic", Font.PLAIN, 9));
				btnEdit.setBounds(591, 76, 89, 23);
				contentPane.add(btnEdit);
			} 
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		refresh();
		
		
	}
	
	
	
	public void refresh() {
		List<String> tList = null;
		tList = controller.getTeacherList();
		
		if(tList != null) {
			dListModel = new DefaultListModel();
			for(int i=0; i<tList.size(); i++) {
				dListModel.addElement(tList.get(i));
			}
			list.setModel(dListModel);
		} else {
			controller.visitHome();
		}
		
	}

}

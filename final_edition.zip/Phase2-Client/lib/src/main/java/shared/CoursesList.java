package shared;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import client.Client;
import login.PhaseController;
import shared.model.*;

import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.JScrollBar;
import java.awt.Font;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.border.LineBorder;

public class CoursesList extends JFrame {

//	static JPanel contentPane = new JPanel();
	private  JTextField courseIDrem;
	private  JPanel contentPane_1;
	Color backColor;
    Color textMainColor;
    Color textColor;

    private DefaultListModel<String> dListModel = new DefaultListModel<String>();
	private static JTextField textField;
	private static JTextField textField_1;
	
	private JList<String> list;
	private JScrollPane scrollPane_1;
	
	private String id;
	private PhaseController controller;
	private String position; 
	
	private String type = "ALL";
	private String degree;
	private String credit;
	private String dep;
	
	public CoursesList() {
		controller = new PhaseController();
		
		try {
			position = controller.getPosition();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
		initPane();
	    updatePage();
	}
	
	void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 868, 452);
		
		backColor = Color.cyan;
		textMainColor = Color.black;
		textColor = Color.green;
			
		contentPane_1 = new JPanel();
		contentPane_1.setBackground(backColor);
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane_1);
		contentPane_1.setLayout(null);
	}
	void resetPane() {
		contentPane_1.removeAll();
		contentPane_1.revalidate();
		contentPane_1.repaint();
	}
	
	void scrollPane() {
		scrollPane_1 = new JScrollPane();
	    scrollPane_1.setBounds(10, 11, 540, 393);
	    contentPane_1.add(scrollPane_1);
	}
	
	void initList() {
		list = new JList();
	    list.setBackground(new Color(255, 250, 240));
	    list.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
	    list.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
	    scrollPane_1.setViewportView(list);
	}
	
	void initConstant() {
		JLabel degJLabel = new JLabel("Degree:");
		degJLabel.setForeground(new Color(138, 43, 226));
		degJLabel.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 11));
		degJLabel.setBounds(570, 61, 69, 14);
	    contentPane_1.add(degJLabel);
	    
		JLabel filLabel = new JLabel("Filter by:");
		filLabel.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 11));
		filLabel.setForeground(new Color(138, 43, 226));
		filLabel.setBounds(570, 11, 69, 14);
	    contentPane_1.add(filLabel);
	    
	    JLabel creLabel = new JLabel("Credits:");
	    creLabel.setForeground(new Color(138, 43, 226));
	    creLabel.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 11));
	    creLabel.setBounds(570, 36, 69, 14);
	    contentPane_1.add(creLabel);
	    
	    JLabel depLabel = new JLabel("Department:");
	    depLabel.setForeground(new Color(138, 43, 226));
	    depLabel.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 11));
	    depLabel.setBounds(570, 90, 69, 14);
	    contentPane_1.add(depLabel);
	}
	
	void comboDegree() {
		String[] degrees = {"BACHELOR","MASTER","DOCTORATE"};
	    JComboBox degCBox = new JComboBox(degrees);
	    degCBox.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
	    degCBox.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		if(e.getSource() == degCBox) {
	    			
	    			type = "DEG";
	    			degree = (String)degCBox.getSelectedItem();
	    			
	    			
	    			
	    			
	    			
	    /*			List<String> filterList = new ArrayList<>();
		    		filterList = controller.filterCourse("degree", degree);
		    		
		    		dListModel = new DefaultListModel<>();
		    		for(int i=0; i<filterList.size(); i++) {
		    			dListModel.addElement(filterList.get(i));
		    		}
		    		list.setModel(dListModel); */
		    		
	    		}
	    	}
	    });
	    degCBox.setBounds(649, 61, 88, 22);
	    contentPane_1.add(degCBox);
	}
	void comboCredit() {
		String[] credits = {"1","2","3","4"};
	    JComboBox comboBox = new JComboBox(credits);
	    comboBox.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
	    
	    comboBox.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		if(e.getSource() == comboBox) {
	    			
	    			type = "CRE";	    			
	    			credit = (String)comboBox.getSelectedItem();
	    			
	    			
	    		/*	List<String> filterList = new ArrayList<>();
		    		filterList = controller.filterCourse("credit", credit);
		    		
		    		dListModel = new DefaultListModel<>();
		    		for(int i=0; i<filterList.size(); i++) {
		    			dListModel.addElement(filterList.get(i));
		    		//	dListModel.addElement(coursesFilter.get(i).getName()+"     -     "+coursesFilter.get(i).getCourseID()+"     -     "+coursesFilter.get(i).getCourseDegree()+"     -     "+coursesFilter.get(i).getCourseCredit());
		    		}
		    		list.setModel(dListModel); */
	    		}
	    	}
	    });
	    
	    comboBox.setBounds(649, 28, 88, 22);
	    contentPane_1.add(comboBox);
	}
	void comboDep() {
		String[] departments = {"Math","CE","EE","Chem","Phys"};
	    JComboBox depCBox = new JComboBox(departments);
	    depCBox.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
	    depCBox.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		if(e.getSource() == depCBox) {
	    			
	    			type = "DEP";
	    			dep = (String)depCBox.getSelectedItem();
	    			
	    			
	    			
	    			
	    			
	    			
	    			
	    			
	    /*			List<String> filterList = new ArrayList<>();
		    		filterList = controller.filterCourse("dep", dep);
		    		
		    		dListModel = new DefaultListModel<>();
		    		for(int i=0; i<filterList.size(); i++) {
		    			dListModel.addElement(filterList.get(i));
		    		//	dListModel.addElement(coursesFilter.get(i).getName()+"     -     "+coursesFilter.get(i).getCourseID()+"     -     "+coursesFilter.get(i).getCourseDegree()+"     -     "+coursesFilter.get(i).getCourseCredit());
		    		}
		    		
		    		list.setModel(dListModel); */
	    		}
	    	}
	    });
	    depCBox.setBounds(649, 94, 88, 22);
	    contentPane_1.add(depCBox);
	}
	
	public void updatePage() {
		
		resetPane();
	    scrollPane();
	    initList();
	    initConstant();
	    
	    comboDegree();
	    comboCredit();
	    comboDep();
	    showAllBtn();
	    

	    exitBtn();
		homeBtn();
		refresh();
	    
	    
	    //Deputy
		if(position.equals("Deputy")) {
			
			courseIDrem = new JTextField();
			courseIDrem.setBounds(570, 161, 167, 20);
			contentPane_1.add(courseIDrem);
			courseIDrem.setColumns(10);
			
			
			
			JButton addButton = new JButton("Add course");
			addButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controller.showAddCourse();
				}
			});
			addButton.setBounds(570, 260, 167, 23);
			addButton.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 11));
			contentPane_1.add(addButton);
			
			
			
			
			JButton btnRemoveCourse = new JButton("Remove course");
			btnRemoveCourse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String iDString = courseIDrem.getText();
					controller.removeCourse(iDString);
					updatePage();
				}
			});
			btnRemoveCourse.setBounds(570, 192, 167, 23);
			btnRemoveCourse.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 11));
			contentPane_1.add(btnRemoveCourse);
			
			
			
			
			JButton btnEditCourse = new JButton("Edit course");
			btnEditCourse.addActionListener(new ActionListener() {  
				public void actionPerformed(ActionEvent e) {
					String iDString = courseIDrem.getText();
					controller.showDepEditCourse(iDString);
				}
			});
			btnEditCourse.setBounds(570, 226, 167, 23);
			btnEditCourse.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 11));
			contentPane_1.add(btnEditCourse);
		}
	    
	    
	}
	void homeBtn() {
	    JButton btnHomepage = new JButton("Homepage");
	    btnHomepage.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		controller.visitHome();
	    	}
	    });
	    btnHomepage.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
	    btnHomepage.setBounds(747, 12, 88, 14);
	    contentPane_1.add(btnHomepage);
	    }

	void exitBtn() {
	    JButton btnNewButton = new JButton("Exit");
	    btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
	    btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		controller.exit();
	    	}
	    });
	    btnNewButton.setBounds(649, 12, 88, 14);
	    contentPane_1.add(btnNewButton);
	    }
	
	void showAllBtn() {
		JButton btnNewButton_1 = new JButton("Show all");
	    btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
	    btnNewButton_1.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		type = "ALL";
	    /*		List<String> filterList = new ArrayList<>();
	    		filterList = controller.filterCourse("ALL", "");

    			dListModel = new DefaultListModel();
	    		for(int i=0; i<filterList.size(); i++) {
	    			dListModel.addElement(filterList.get(i));
	    		}
	    		
	    		list.setModel(dListModel); */
	    		
	    	}
	    });
	    btnNewButton_1.setBounds(570, 127, 89, 23);
	    contentPane_1.add(btnNewButton_1);
	}
	
	
	public void refresh() {
		List<String> filterList = new ArrayList<>();
		
		if(type.equals("ALL")) filterList = controller.filterCourse("ALL", "");
		else if(type.equals("DEG")) filterList = controller.filterCourse("degree", degree);
		else if(type.equals("CRE")) filterList = controller.filterCourse("credit", credit);
		else filterList = controller.filterCourse("dep", dep);
		
		if(filterList != null) {
			dListModel = new DefaultListModel();
			for(int i=0; i<filterList.size(); i++) {
				dListModel.addElement(filterList.get(i));
			}
			
			list.setModel(dListModel);
		} else {
			controller.visitHome();
		}
		
	}

}


package chooseCourse;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import client.Client;
import client.controller.Controller;
import client.network.ServerController;
import shared.model.MiniCourse;
import shared.response.Response;
import shared.response.ResponseStatus;

public class ChooseController extends Controller {
	
	static Client client;
	static ServerController serverController;

	public ArrayList<Integer> getCourseGroups(String courseID) {
		Response response = serverController.getCourseGroups(courseID);
		if(response != null) return (ArrayList<Integer>) response.getData("list");
		return null;
	}

	public boolean changeGroup(String mini_id, String courseID, int group) {
		Response response = serverController.sendChangeGroupReq(mini_id ,courseID, group, client.getId());
		 if(response != null) {
			 return response.getStatus() == ResponseStatus.OK;
		 } else {
			 visitHome();
			 return false;
		 }
	}

	public List<MiniCourse> miniCoursesByDep(String dep, String sortBy) {
		Response response = serverController.miniCoursesByDep(dep, sortBy);
		if(response != null) return (List<MiniCourse>) response.getData("list");
		return null;
	}

	public String askCourseStatus(String mini_id, String id) {
		Response response = serverController.sendCourseStatusReq(mini_id, id);
		if(response != null) return (String) response.getData("choose") + "/" + (String) response.getData("check");
		return null;
	}

	public static void setClient(Client client2, ServerController serverController2) {
		client = client2;
		serverController = serverController2;
	}

	public void changeChecked(String mini_id, String id) {
		serverController.sendChangeCheckedReq(mini_id, id);
	}

	public String chooseCourse(String mini_id, String id) {
		Response response = serverController.sendChooseReq(mini_id, id);
	    if(response != null) {
	    	if(response.getStatus() == ResponseStatus.OK) return "Done!";
		    if(response.getStatus() == ResponseStatus.MAAREF) return "You can't choose more than 1 maaref!";
		    if(response.getStatus() == ResponseStatus.CL_MIX) return "Class mix up!";
		    if(response.getStatus() == ResponseStatus.EX_MIX) return "Exam mix up!";
		    if(response.getStatus() == ResponseStatus.CAPACITY) return "Full!";
		    if(response.getStatus() == ResponseStatus.PRE_ERR) return "You haven't passed pre-courses!";
		    if(response.getStatus() == ResponseStatus.SAME_COURSE) return "You need to change groups!";
	    }
	    return null;
	}

	public void deleteCourse(String mini_id, String id) {
		client.deleteCourse(mini_id, id);
	}

	public LinkedList<String> askCheckMap(String id) {
		Response response = serverController.sendCheckMapReq(id);
		if(response != null) return (LinkedList<String>) response.getData("map");
		return null;
	}

	public LinkedList<String> askSugMap(String id) {
		Response response = serverController.sendSugMapReq(id);
		if(response != null) return (LinkedList<String>) response.getData("map");
		return null;
	}

	public void setChooseTime(int year, String dep, String time) {
		client.setChooseTime(year, dep, time);
	}

	public void showPrefferedPage() {
		client.showPrefferedPage();
	}

	public void showChangeGroup(String mini_id, String courseID) {
		client.showChangeGroup(mini_id, courseID);
	}

	public void reqToTakeCourse(String mini_id) {
		client.reqToTakeCourse(mini_id);
	}

}

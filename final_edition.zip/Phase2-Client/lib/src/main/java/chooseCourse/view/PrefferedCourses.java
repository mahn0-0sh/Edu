package chooseCourse.view;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import shared.util.Config;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import org.checkerframework.checker.units.qual.s;

import chooseCourse.ChooseController;
import client.Client;
import constants.Constants;
import shared.model.Course;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PrefferedCourses extends JFrame {

	private JPanel contentPane;
	private JTable sugTable;
	private JTable checkTable;
    private DefaultTableModel sugModel;
    private DefaultTableModel checkModel;
    private ChooseController controller;
	//List<Course> chekedList;
	LinkedList<String> checkMap;
	LinkedList<String> sugMap;
	private String id;

	/**
	 * Launch the application.
	 */
	void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 985, 425);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);	
	}
	void initScrolls() {
		JScrollPane suggestPane = new JScrollPane(sugTable);
		suggestPane.setBounds(10, 11, 405, 366);
		contentPane.add(suggestPane);
		
		JScrollPane checkedPane = new JScrollPane(checkTable);
		checkedPane.setBounds(471, 11, 405, 366);
		contentPane.add(checkedPane);	
	}
	void exitBtn() {
		JButton btnNewButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "home"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton.setBounds(886, 11, 75, 23);
		contentPane.add(btnNewButton);
	}
	
	public PrefferedCourses(String id) {
		this.id = id;
		controller = new ChooseController();
		checkMap = controller.askCheckMap(id);
		sugMap = controller.askSugMap(id);
		
		initPane();
		initModels();
		
		checkTable = new JTable(checkModel);
		addCheckListener(id);
		updateCheckModel(id);
		sugTable = new JTable(sugModel);
		addSugListener(id);
		updateSugModel(id);
		
		
		initScrolls();
		exitBtn();
	}
	
	
	void initModels() {
		sugModel = new DefaultTableModel(new Object[]{"ID", "Group", "Choose", "Request", "Check"}, 0) {
            @Override
            public Class getColumnClass(int columnIndex) {
            	switch (columnIndex) {
				case 2: {
					return Integer.class;
				}
				case 3: {
					return Integer.class;
				}
				default:
	                return Object.class;
				}
            }
        };
        
        checkModel = new DefaultTableModel(new Object[]{"ID", "Group", "Choose", "Request", "Check"}, 0) {
            @Override
            public Class getColumnClass(int columnIndex) {
            	switch (columnIndex) {
				case 2: {
					return Integer.class;
				}
				case 3: {
					return Integer.class;
				}
				default:
	                return Object.class;
				}
            }
        };
	}

/*	Course getFromList(String id) {
		for(Course course : chekedList) {
			if(course.getCourseID().equals(id)) {
				return course;
			}
		}
		return null;
	} */
	
	void addSugListener(String id) {
		sugTable.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 1) {
					listenerSug(id);
					updateSugModel(id);
					updateCheckModel(id);
				}		
			}
		});
	} 
	
	void listenerCheck(String id) { //TODO
		
		int row = checkTable.getSelectedRow();
		int col = checkTable.getSelectedColumn();
		String command = (String) checkTable.getModel().getValueAt(row, col);
		String courseID = (String) checkTable.getModel().getValueAt(row, 0);
		String gp = (String) checkTable.getModel().getValueAt(row, 1);
		int group = Integer.parseInt(gp); 
		String mini_id = (String) checkTable.getModel().getValueAt(row, 0)+"-"+(String) checkTable.getModel().getValueAt(row, 1);
		
		if(col == 4) controller.changeChecked(mini_id, id);
		
		if(col == 3) {
			if(command.equals("Request")) controller.reqToTakeCourse(mini_id);
			else {
				if(group != 0) {
					controller.showChangeGroup(mini_id ,courseID);
				} else {
					JOptionPane.showMessageDialog(null, "There is no other group.");
				}				
			}
		}
		
		if(col == 2) {
			if(command.equals("Choose")) {
			   String r = controller.chooseCourse(mini_id, id);
			   JOptionPane.showMessageDialog(null, r); // different errors
			}
			else controller.deleteCourse(mini_id, id);
		}
	}
	
	void listenerSug(String id) { //TODO
		
		int row = sugTable.getSelectedRow();
		int col = sugTable.getSelectedColumn();
		String command = (String) sugTable.getModel().getValueAt(row, col);
		String courseID = (String) sugTable.getModel().getValueAt(row, 0);
		String gp = (String) sugTable.getModel().getValueAt(row, 1);
		int group = Integer.parseInt(gp); 
		String mini_id = (String) sugTable.getModel().getValueAt(row, 0)+"-"+(String) sugTable.getModel().getValueAt(row, 1);
		
		if(col == 4) controller.changeChecked(mini_id, id);
		
		if(col == 3) {
			if(command.equals("Request")) controller.reqToTakeCourse(mini_id);
			else {
				if(group != 0) {
					controller.showChangeGroup(mini_id ,courseID);
				} else {
					JOptionPane.showMessageDialog(null, "There is no other group.");
				}				
			}
		}
		
		if(col == 2) {
			if(command.equals("Choose")) {
			   String r = controller.chooseCourse(mini_id, id);
			   JOptionPane.showMessageDialog(null, r); // different errors
			}
			else controller.deleteCourse(mini_id, id);
		}
	}
	
	void addCheckListener(String id) {
		checkTable.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 1) {
					listenerCheck(id);
					updateCheckModel(id);
					updateSugModel(id);
				}		
			}
		});
	} 

	void updateCheckModel(String id) {
		checkMap = controller.askCheckMap(id);
		if(checkMap != null) {
			int num = checkModel.getRowCount();
			for (int i = 0; i < num; i++) {
				checkModel.removeRow(0);
			}
			
			for (String str : checkMap) {
	        	
				
	        	try {
	        		
	        		
	        		String mini_id = str;
	        		String string = controller.askCourseStatus(mini_id, id);
	        		if(string != null) {
	        			
	        			String[] s = string.split("/");
	        			String req;
	        			if(s[0].equals("Choose")) req = "Request";
	        			else {
	        				req = "Change group";
	        			}
	        		String[] st = mini_id.split("-");	
	        			
	        	checkModel.addRow(new Object[]{st[0], st[1], s[0], req, s[1]}); 
	        		} else {
	        			controller.visitHome();
	        		}
	        		

	        	} catch (Exception e) { System.out.println(e); }
	        }
		} else {
			controller.visitHome();
		}
		
	}
	
	void updateSugModel(String id) {
		sugMap = controller.askSugMap(id);
		if(sugMap != null) {
			int num = sugModel.getRowCount();
			for (int i = 0; i < num; i++) {
				sugModel.removeRow(0);
			}
			
			for (String str : sugMap) {
	        	
	        	try {
	        		String mini_id = str;
	        		String string = controller.askCourseStatus(mini_id, id);
	        		if(string != null) {
	        			String[] s = string.split("/");
	        			String req;
	        			if(s[0].equals("Choose")) req = "Request";
	        			else {
	        				req = "Change group";
	        			}
	        		String[] st = mini_id.split("-");	
	        			
	        	    sugModel.addRow(new Object[]{st[0], st[1], s[0], req, s[1]}); 
	        		} else {
						controller.visitHome();
					}

	        	} catch (Exception e) { System.out.println(e); }
	        }
		} else {
			controller.visitHome();
		}
		
	}
	
	public void refresh() {
		updateCheckModel(id);
		updateSugModel(id);
	}
	
	
}


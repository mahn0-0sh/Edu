package chooseCourse.view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import shared.util.Config;
import constants.*;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import chooseCourse.ChooseController;
import client.Client;
import shared.model.Course;
import shared.model.MiniCourse;
import shared.model.Student;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.awt.event.ActionEvent;

public class CourseChoose extends JFrame {

	static Logger logger = LogManager.getLogger();
	
	private JTable table;
    private DefaultTableModel model;
	private JPanel contentPane;
	private List<MiniCourse> list;
	private String dep;
	private String sortBy = "Degree";
	private ChooseController controller = new ChooseController();

	/**
	 * Launch the application.
	 */
	
	void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}
	
	void initModel() {
		model = new DefaultTableModel(new Object[]{"Row","Pre", "Con", "Name", "ID", "Group", "Teacher", 
				"Capacity", "Exam", "Choose", "Request", "Check"}, 0) {
            @Override
            public Class getColumnClass(int columnIndex) {
            	switch (columnIndex) {
				case 5: {
					return Integer.class;
				}
				case 7: {
					return Integer.class;
				}
				default:
	                return Object.class;
				}
            }
        };
	}
	
	private void initComp() {
		list = new ArrayList<>();
	}
	public CourseChoose(String id) {
		initComp();
		initPane();
		initModel();
		

        table = new JTable(model);	    
        setSize();
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 11, 770, 390);
		contentPane.add(scrollPane);
		addListener(id);
		depBox(id);
		
		
		
		
		String[] sort = {"Exam", "Alphabet", "Degree"};
		JComboBox comboBox = new JComboBox(sort);
		comboBox.setBounds(790, 77, 54, 22);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	    		if(e.getSource() == comboBox) {
	    			
	    			sortBy = (String)comboBox.getSelectedItem();
	    			updateModel(id);
	    			table.setModel(model);
	    			
	    		}
			}
		});
		contentPane.add(comboBox);
		
		
		
		
		JButton btnNewButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "btnB"));
		btnNewButton.addActionListener(new ActionListener() { //TODO
			public void actionPerformed(ActionEvent e) {
				controller.showPrefferedPage();
			/*	LinkedList<String> checkMap = controller.askCheckMap(id);
				LinkedList<String> sugMap = controller.askSugMap(id);
				PrefferedCourses courses = new PrefferedCourses(controller, id, checkMap, sugMap);
				dispose();
				courses.setVisible(true); */
			}
		});
		btnNewButton.setBounds(790, 183, 54, 23);
		contentPane.add(btnNewButton); 
		
		JButton btnNewButton_1 = new JButton("Home");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 6));
		btnNewButton_1.setBounds(790, 8, 56, 23);
		contentPane.add(btnNewButton_1);
		
	    
	    
	}

	Course getFromList(String id) {
		for(Course course : list) {
			if(course.getCourseID().equals(id)) {
				logger.info("course found");
				return course;
			}
		}
		logger.info("course not found");
		return null;
	}
	
	void addListener(String id) {
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 1) {
					int row = table.getSelectedRow();
					int col = table.getSelectedColumn();
					
					String courseID = (String) table.getModel().getValueAt(row, 4);
					int group = (int) table.getModel().getValueAt(row, 5);
					
					
					String command = (String) table.getModel().getValueAt(row, col).toString();
					String mini_id = courseID+"-"+group;
							
					
					if(col == 11) {
						controller.changeChecked(mini_id, id);
					}
					
					if(col == 10) {
						if(command.equals("Request")) controller.reqToTakeCourse(mini_id);
						else {
							logger.info("change group opening");
							if(group != 0) {
								controller.showChangeGroup(mini_id ,courseID);
							} else {
								JOptionPane.showMessageDialog(null, "There is no other group.");
							}
						}
					}
					
					if(col == 9) {
						if(command.equals("Choose")) {
						   String r = controller.chooseCourse(mini_id, id);
						   if(r == null) controller.visitHome();
						   else JOptionPane.showMessageDialog(null, r); // different errors
						}
						else controller.deleteCourse(mini_id, id); 
					}
					
					updateModel(id);
				}		
			}
		});
	}
	
	void setSize() {
		table.getColumnModel().getColumn(0).setPreferredWidth(30);
        table.getColumnModel().getColumn(1).setPreferredWidth(30);
        table.getColumnModel().getColumn(2).setPreferredWidth(30);
        table.getColumnModel().getColumn(4).setPreferredWidth(30);
        table.getColumnModel().getColumn(5).setPreferredWidth(30);
        table.getColumnModel().getColumn(7).setPreferredWidth(30);
	}

	void depBox(String id) {
		String[] deps = { "Math", "CE", "EE", "Chem", "Phys" };
		JComboBox<String> depBox = new JComboBox<String>(deps);
		depBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	    		if(e.getSource() == depBox) {
	    			
	    			dep = (String)depBox.getSelectedItem();
	    			logger.info("list achieved");
	    			updateModel(id);
	    			table.setModel(model);
	    			
	    		}
			}
		});
		depBox.setBounds(790, 44, 54, 22);
		contentPane.add(depBox);
	}
	
	
	
	
	public void updateModel(String id) {      
		list = controller.miniCoursesByDep(dep, sortBy);
		
		
		if(list != null) {
			int num = model.getRowCount();
			for (int i = 0; i < num; i++) {
				model.removeRow(0);
			}
			logger.info("rows removed");
			
			for (int i = 0; i < list.size(); i++) {
	        	MiniCourse course = list.get(i);
	        	
	    		
	        	try {
	        			String string = controller.askCourseStatus(course.getMiniCourseID(), id);
	        			if(string != null) {
	        				logger.info("status achieved");
		        			
		        			String[] s = string.split("/");
		        			String req;
		        			if(s[0].equals("Choose")) req = "Request";
		        			else {
		        				req = "Change group";
		        			} 
		        			
		            model.addRow(new Object[]{"-", course.preString(), course.conString(), course.getName(), course.getCourseID(),
		            		course.getGroup(), course.getTeacher(), course.getCapacity(), course.courseExam(), s[0], req, s[1]});
		        		
	        			} else {
	        				controller.visitHome();
	        			}
	        			
	        			
	        	} catch (Exception e) {
	        		logger.error("problem in adding rows" + e);
				}
	        }
		} else {
			controller.visitHome();
		}
		
		
	}
}

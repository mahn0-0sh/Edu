package chooseCourse.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import constants.Constants;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import chooseCourse.ChooseController;
import client.Client;
import shared.model.Course;
import shared.model.MiniCourse;
import shared.util.Config;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChangeGroup extends JDialog {

	private final JPanel contentPanel = new JPanel();
	Logger logger = LogManager.getLogger();
	int group;
	private ChooseController controller = new ChooseController();

	
	void initPane() {
		setBounds(100, 100, 312, 166);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
	}
	
	
	void label() {
		JLabel lblNewLabel = new JLabel(new Config(Constants.LABEL_TEXT).getProperty(String.class, "lblChooseGroup"));
		lblNewLabel.setBounds(10, 38, 184, 14);
		contentPanel.add(lblNewLabel);
	}

	public ChangeGroup(String mini_id, String courseID) {
		initPane();
		label();
		
		
		JComboBox<Integer> comboBox = new JComboBox<Integer>();
		for(int i : controller.getCourseGroups(courseID)) comboBox.addItem(i);
		comboBox.setBounds(204, 34, 82, 22);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
    			group = (int) comboBox.getSelectedItem();
			}
		});
		contentPanel.add(comboBox);
		
		
		
		buttons(mini_id, courseID);
	}
	
	void buttons(String mini_id, String courseID) {
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						boolean b = controller.changeGroup(mini_id ,courseID, group);
						
							if(!b) JOptionPane.showMessageDialog(null, "Group full, req sent.");
							else JOptionPane.showMessageDialog(null, "Group changed.");
							
		    			dispose();
					}
				});
				okButton.setActionCommand(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "okButton"));
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			
			
			
			{
				JButton cancelButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "cancelButton"));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	
	
	public void refresh() {
		// TODO
	}
}

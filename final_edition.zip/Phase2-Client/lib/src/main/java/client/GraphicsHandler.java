package client;

import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import chat.view.ChatMain;
import chat.view.ChatRoomGUI;
import chooseCourse.view.ChangeGroup;
import chooseCourse.view.CourseChoose;
import chooseCourse.view.PrefferedCourses;
import client.controller.OfflineController;
import constants.Constants;
import cw.view.course.shared.CoursePageMain;
import cw.view.main.CWMainFrame;
import extra_roles.admin.view.AdminChat;
import extra_roles.mohseni.view.MainFrame;
import login.LogginWindow;
import login.PassChange;
import message.view.MsgMain;
import message.view.ReqDialog;
import shared.CoursesList;
import shared.ExamSched;
import shared.TeachersList;
import shared.WeekSched;
import shared.util.Config;
import shared.util.extra.Loop;
import student.Certificate;
import student.EducationalStatus;
import student.ProtestFeedbackDialog;
import student.RecomFeedback;
import student.Recommendation;
import student.RequestStu;
import student.StudentMain;
import student.StudentProfile;
import student.TempScores;
import teacher.RegisterScores;
import teacher.TeacherMain;
import teacher.TeacherProfile;
import teacher.TeacherViewProtest;
import teacher.deputy.AddCourse;
import teacher.deputy.AddNewStudent;
import teacher.deputy.AddNewTeacher;
import teacher.deputy.DepEduStatus;
import teacher.deputy.DepTeacherScores;
import teacher.deputy.DeputyTemperoryScores;
import teacher.deputy.EditCourse;
import teacher.deputy.ProtestsAll;
import teacher.deputy.ScoresOfClass;
import teacher.manager.ManagerEditPage;
import teacher.manager.ManagerTeacherEdit;

public class GraphicsHandler {
	
	private Logger logger = LogManager.getLogger(Client.class);
	static GraphicsHandler handler;
	private Client client;
	private final Double fps = new Config(Constants.CONFIG_ADDRESS).getProperty(Double.class, "refreshLoop");
	private Loop loop;
	private JFrame viewFrame = new JFrame();
    private JDialog viewDialog = new JDialog();
    private String position;
    private OfflineController controller = new OfflineController();
	
	public void setClient(Client client) {
		this.client = client;
	}
	
	public static GraphicsHandler getGH() {
		if(handler == null) {
			handler = new GraphicsHandler();
		}
		return handler;
	}
	
	void loginGUI() {
    	LogginWindow window = new LogginWindow(this.client);
		window.frame.setVisible(true);
		viewFrame = window.frame;
    }
	
	private void changePage() {
		if(loop != null) loop.stop();
		viewFrame.dispose();
		viewDialog.dispose();
	}
	
	void mainMenuGUI(String status) {    	
		this.position = client.getPosition();
    	if(ConnectionStatus.getStatus().isOnline()) {
    		changePage();
    		if(position.equals("Student")) {
    			
    			StudentMain studentMain = new StudentMain(status);
        		viewFrame = studentMain;
        		
        		loop = new Loop(fps, () -> studentMain.refresh()); 
        		loop.start();
        		
        	} else if(position.equals("Mohseni")) {
        		
        		MainFrame view = new MainFrame();
        		viewFrame = view;
        		
         		loop = new Loop(fps, () -> view.refresh());
         		loop.start();
         		
        	} else if(position.equals("Admin")) {
        		
        		try {
        			AdminChat view = new AdminChat();
				    viewFrame = view;
				    
				    loop = new Loop(fps, () -> view.refresh());
					loop.start();
        		} catch (Exception e) {
        			e.printStackTrace();
				}
        		
        	} else {
    			TeacherMain view = new TeacherMain(status);
				viewFrame = view;
				
				loop = new Loop(fps, () -> view.refresh());
				loop.start();
    		}   
    		viewFrame.setVisible(true);
    	} else {
    		logger.info("is offline");
    	}
	}
	
	
	public void visitHome() throws SQLException { 
		if(!ConnectionStatus.getStatus().isOnline()) {
			changePage();
			if(position.equals("Student")) {
				StudentMain studentMain = new StudentMain(controller.mainPageStudent(client.getId()));
        		viewFrame = studentMain;
			} else {
				TeacherMain teacherMain = new TeacherMain(controller.mainPageTeacher(client.getId()));
				viewFrame = teacherMain;
			}
			viewFrame.setVisible(true);
		} else {
			mainPage();			
		}
	}
	
	
	public void mainPage() {
        String status = mainPageStatus();
        try {
    		mainMenuGUI(status);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
	
	 public String mainPageStatus() {
		 return client.mainPageStatus();
	 } 
	 
	 private void visible(JFrame view) {
	    	viewFrame = view;
			viewFrame.setVisible(true);
	 }
	 private void offlineErr() {
	    JOptionPane.showMessageDialog(null, "You are in offline mode.");
     }
	 
	 public void showCoursesList() { 
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				CoursesList view = new CoursesList();
				visible(view);
				
				loop = new Loop(fps, () -> view.refresh());
				loop.start();
			} else {
				offlineErr();
			}	 	
	 }
	 
	 public void showTeachersList() {
		 if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				TeachersList teachersList = new TeachersList();
				visible(teachersList);
				
				loop = new Loop(fps, () -> teachersList.refresh());
				loop.start();
		}
	 }
	 
	 public void showWeekSchd() throws SQLException {
		 changePage();
		 if(ConnectionStatus.getStatus().isOnline()) {
	    		WeekSched view = new WeekSched(client.getWeekSchd());
	    		visible(view);
	    		
	    		loop = new Loop(fps, () -> view.refresh());
	    		loop.start();
	    } else {
	    		WeekSched view = new WeekSched(controller.getWeekSchedStu(client.getId()));
	    		visible(view);
	    }	    	
	 }
	 
	 public void showExamSchd() throws SQLException {
		 changePage();
		 if(ConnectionStatus.getStatus().isOnline()) {
			 ExamSched view = new ExamSched(client.getExamSchd());
	    		visible(view);
	    		
	    		loop = new Loop(fps, () -> view.refresh());
	    		loop.start();
	    } else {
	    	ExamSched view = new ExamSched(controller.getExamSchd(client.getId()));
    		visible(view);
	    }
	}
	 
	 public void showTempScores(String id) {
		 if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				TempScores tempScores = new TempScores(id);
				visible(tempScores);
				
				loop = new Loop(fps, () -> tempScores.refresh());
				loop.start();
		}
	}
	 
	 public void showRegScoresPage(String mini_id) {
	    	if(ConnectionStatus.getStatus().isOnline()) {
	    		changePage();
	    		RegisterScores view = new RegisterScores(mini_id);
	    		visible(view);
	    		
	    		loop = new Loop(fps, () -> view.refresh());
	    		loop.start();
	    	} else {
	    		offlineErr();
	    	}
	}
	 
	 
	 public void showEduStatus(String id) {  //For deputy
		if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				EducationalStatus status = new EducationalStatus(id);
				visible(status);
				
				loop = new Loop(fps, () -> status.refresh(id));
				loop.start();
		}
	}
	 
	 public void showEduStatus() {  // for stu
			changePage();
			String id = client.getId();
			
			if(ConnectionStatus.getStatus().isOnline()) {
				EducationalStatus status = new EducationalStatus(id);
				status.setVisible(true);
				viewFrame = status;
				
				loop = new Loop(fps, () -> status.refresh(id));
				loop.start();
			} else {
				EducationalStatus status = new EducationalStatus(id);
				status.setVisible(true);
				viewFrame = status;
			}
	}
	 
	 
	 public void showAddCourse() {	
	    	if(ConnectionStatus.getStatus().isOnline()) {
	    		changePage();
	    		AddCourse view = new AddCourse();
	    		visible(view);
	    		// no need to refresh
	    	} else {
	    		offlineErr();
	    	}
	}
	 
	 
	 public void showReqPage() {
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				RequestStu view = new RequestStu();
				visible(view);
				// no need to refresh
			} else {
				offlineErr();
			}
	}
	 
	 
	 public void showPrefferedPage() {
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				PrefferedCourses view = new PrefferedCourses(client.getId());
				visible(view);
				
				loop = new Loop(fps, () -> view.refresh());
				loop.start();
			} else {
				offlineErr();
			}
	}
	 
	 
	 public void showChangeGroup(String mini_id, String courseID) { //TODO check
		 if(ConnectionStatus.getStatus().isOnline()) {
				ChangeGroup view = new ChangeGroup(mini_id, courseID);
	            visDialog(view);
	            // no need to refresh
			} else {
				offlineErr();
			}	
	 }
	 
	 private void visDialog(JDialog view) {
		viewDialog = view;
		viewDialog.setVisible(true);
	}
	 
	 
	 public void showDepEduStatus() {
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				DepEduStatus view = new DepEduStatus();
				visible(view);
				// no need to refresh
			} else {
				offlineErr();
			}
	}
	 
	 
	 public void showDepTempScores() {
			changePage();
			if(ConnectionStatus.getStatus().isOnline()) {
				DeputyTemperoryScores view = new DeputyTemperoryScores();
				visible(view);
				// no need
			}
	}
	 
	 
	 public void showManagerEditPage() {
		 if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				ManagerEditPage view = new ManagerEditPage();
				visible(view);
				//no need
		}				
	}
	 
	 
	 public void showRecomPage() {
		 if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				Recommendation view = new Recommendation();
				visible(view);
				// no need
		}
	}
	 
	 public void CWgui() {
	    	if(ConnectionStatus.getStatus().isOnline()) {
	    		changePage();
	    		CWMainFrame view = new CWMainFrame();
	    		visible(view);
	    		
	    		loop = new Loop(fps, () -> view.refresh());
	    		loop.start();
	    	} else {
	    		offlineErr();
	    	}
	}
	 
	 public void chatGui() {
		 changePage();
		 if(ConnectionStatus.getStatus().isOnline()) {
	    		ChatMain view = new ChatMain();
	    		visible(view);
	    		
	    		loop = new Loop(fps, () -> view.refresh());
	    		loop.start();
	     } else {
	    		ChatMain view = new ChatMain();
	    		visible(view);
	     }	    	
	}
	 
	 public void chatRoomGUI(int chatId, String id, String other_id) throws IOException { 	
	    	if(ConnectionStatus.getStatus().isOnline()) {
	    		changePage();
	    		ChatRoomGUI view = new ChatRoomGUI(chatId, id, other_id);
	    		visible(view);
	    		
	    		loop = new Loop(fps, () -> view.refresh());
	    		loop.start();
	    	} else {
	    		ChatRoomGUI view = new ChatRoomGUI(chatId, id, other_id);
	    		visible(view);
	    	}
	}
	 
	 public void courseChooseGUI() {
	    	if(ConnectionStatus.getStatus().isOnline()) {
	    		changePage();
	    		CourseChoose view = new CourseChoose(client.getId());
	    		visible(view);
	    		
	    		loop = new Loop(fps, () -> view.updateModel(client.getId()));
	    		loop.start();
	    	} else {
	    		offlineErr();
	    	}
	}
	 
	 
	 public void showManagerTeacherEdit(String teacher_id) {
			changePage();
				
				if(ConnectionStatus.getStatus().isOnline()) {
					ManagerTeacherEdit view = new ManagerTeacherEdit(teacher_id);
					visible(view);
					
			//		loop = new Loop(s_fps, () -> view.refresh());
			//		loop.start();
				} else {
					offlineErr();
				}
		}
	 
	 
	 
	 public void showAddTeacher() {
		 if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				AddNewTeacher view = new AddNewTeacher();
				view.setVisible(true);
				viewFrame = view;
				//no need
		} else {
				offlineErr();
		}
	}
	 
	 
	 public void showProtestFeedbackDialog() { 
		 if(ConnectionStatus.getStatus().isOnline()) {
				ProtestFeedbackDialog view = new ProtestFeedbackDialog();
				visDialog(view);
				
				loop = new Loop(fps, () -> view.refresh());
				loop.start();
		}
	 }
	 
	 
	 public void showProtests(String mini_id) {
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				TeacherViewProtest view = new TeacherViewProtest(mini_id);
				visible(view);
				
				loop = new Loop(fps, () -> view.refresh());
				loop.start();
			}
		}
	 
	 
	 public void showScoresOfClass(String mini_id) {
			changePage();
			if(ConnectionStatus.getStatus().isOnline()) {
				ScoresOfClass view = new ScoresOfClass(mini_id);
				visible(view);
				
				loop = new Loop(fps, () -> view.refresh(mini_id));
				loop.start();
			}
	 }
	 
	 
	 
	/* public void showChatMain() {
		//	if(ConnectionStatus.getStatus().isOnline()) {
	    		changePage();
	    		ChatMain view = new ChatMain();
	    		visible(view);
	    		
//	    		loop = new Loop(fps, () -> view.refresh());
//	    		loop.start();
	    		
	   // 	} else {
	  /*  		WeekSched view = new WeekSched(controller.getWeekSchedStu(id));
	    		viewFrame = view;
	    		viewFrame.setVisible(true); */
	   // 	}
				
//		} 

		public void showMsgMain() {				
				if(ConnectionStatus.getStatus().isOnline()) {
					changePage();
					MsgMain view = new MsgMain();
					visible(view);
					
					loop = new Loop(fps, () -> view.refresh());
					loop.start();
				}
		}

		public void showReqDialog(int req_id) {
			if(ConnectionStatus.getStatus().isOnline()) {
				ReqDialog view = new ReqDialog(req_id);
				visDialog(view);
				// no need
			}
		}
	 
		public void showCoursePageMain(String courseID) { //TODO ex chat, cw
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				CoursePageMain view = new CoursePageMain(courseID);
				visible(view);
				
				loop = new Loop(fps, () -> view.refresh());
				loop.start();
			}			
		}
		
		public void showProfile() throws SQLException {
			changePage();
			if(ConnectionStatus.getStatus().isOnline()) {
				if(position.equals("Student")) {
					StudentProfile profile = new StudentProfile(client.profile()); 
					viewFrame = profile;
					
					loop = new Loop(fps, () -> profile.refresh());
					loop.start();
				} else {
					TeacherProfile profile = new TeacherProfile(client.profile());
					viewFrame = profile;
					
					loop = new Loop(fps, () -> profile.refresh());
					loop.start(); 
				}
			} else {
				if(position.equals("Student")) {
					StudentProfile profile = new StudentProfile(client.profile()); 
					viewFrame = profile;
				} else {
					TeacherProfile profile = new TeacherProfile(client.profile());
					viewFrame = profile;
				}	
			}
			viewFrame.setVisible(true);
		}

		public void showStuRecomFeed() {
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				RecomFeedback view = new RecomFeedback();
				visible(view);
				// no need
			}	
		}

		public void showCertificate() {
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				Certificate view = new Certificate();
				visible(view);
				// no need
			}
		}

		public void showAddStu() {
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				AddNewStudent view = new AddNewStudent(client);
				visible(view);
				// no need
			}
		}

		public void showDepEditCourse(String mini_id) {
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				EditCourse view = new EditCourse(mini_id);
				visible(view);
				//no need
			}
		}

		public void showAllTimeProtests(String mini_id) {
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				ProtestsAll view = new ProtestsAll(mini_id);
				visible(view);
				
				loop = new Loop(fps, () -> view.refresh());
				loop.start();
			}
		}

		public void showDeputyTeacherScores(String teach_id) {
			if(ConnectionStatus.getStatus().isOnline()) {
				changePage();
				DepTeacherScores view = new DepTeacherScores(teach_id);
				visible(view);
				
				loop = new Loop(fps, () -> view.refresh());
				loop.start();
			}
		}

		public void showPassChange() {
			changePage();
			visible(new PassChange());
		}
		

}

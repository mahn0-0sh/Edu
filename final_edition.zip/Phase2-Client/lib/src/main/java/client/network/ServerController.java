package client.network;


import shared.util.Config;
import shared.util.Jackson;
import shared.util.extra.Loop;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.checkerframework.checker.units.qual.degrees;
import org.checkerframework.checker.units.qual.s;
import org.codehaus.jackson.map.ObjectMapper;

import client.Client;
import client.ConnectionStatus;
import constants.Constants;
import enums.ReqType;
import enums.StudentDegree;
import enums.TeacherDegree;
import shared.model.Chat;
import shared.model.Course;
import shared.model.Message;
import shared.model.Student;
import shared.request.Request;
import shared.request.RequestType;
import shared.response.Response;
import java.io.IOException;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class ServerController {
    private PrintStream printStream;
    private Scanner scanner;
    private Scanner messageScanner;
    private String authToken;
	private final int port;
    private final ObjectMapper objectMapper;
    private Socket socket;
    private final Double fps = new Config(Constants.CONFIG_ADDRESS).getProperty(Double.class, "refreshLoop");
    private Logger logger = LogManager.getLogger(ServerController.class);

    public ServerController(int port) {
        this.port = port;
        objectMapper = Jackson.getNetworkObjectMapper();
    }
    
    public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

    public void connectToServer() {
        try {
            Socket socket = new Socket(InetAddress.getLocalHost(), port);
            printStream = new PrintStream(socket.getOutputStream());
            scanner = new Scanner(socket.getInputStream());
            messageScanner = new Scanner(socket.getInputStream());
            
            ConnectionStatus.getStatus().setOnline(true);
            
         /*   Loop pingLoop = new Loop(fps, () -> ping());
            pingLoop.start();  */
            
        } catch (IOException e) {
        	JOptionPane.showMessageDialog(null, "Couldn't make connection.");
        }
    }
    
    
    void ping() {
    	Request request = new Request(RequestType.PING);
    	sendAndGet(request);
	} 

    public synchronized void sendRequest(Request request) {
        try {
        	request.addData("token", authToken);
            String requestString = objectMapper.writeValueAsString(request);
            printStream.println(requestString);
            printStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Response sendLoginRequest(String username, String password) {
        Request request = new Request(RequestType.LOGIN);
        request.addData("username", username);
        request.addData("password", password);
        
        return sendAndGet(request);
    }
    
    public Response sendMainPageReq(String username) {
        Request request = new Request(RequestType.MAIN_STATUS);
        request.addData("username", username);
        return sendAndGet(request);
    }

    public Response sendRegisterRequest(String username, String password) {
        Request request = new Request(RequestType.REGISTER);
        request.addData("username", username);
        request.addData("password", password);
        return sendAndGet(request);
    }

	public void sendExitReq(String username) {
		Request request = new Request(RequestType.EXIT);
		request.addData("username", username);
		sendRequest(request);
		System.out.println("sent");
	}

	public Response sendProfileReq(String username) {
		Request request = new Request(RequestType.PROFILE);
		return sendReqByUsername(username, request);
	}

	public Response sendFilterCourseReq(String filterType, String filterBy) {
		Request request = new Request(RequestType.FULL_COURSE);
		request.addData("type", filterType);
		request.addData("by", filterBy);
        return sendAndGet(request);
	}
	
	Response sendReqByUsername(String username, Request request) {
		request.addData("username", username);
		return sendAndGet(request);
	}


	public Response miniCoursesByDep(String dep, String sort) {
		Request request	= new Request(RequestType.MINI_BY_DEP);
		request.addData("department", dep);
		request.addData("sort", sort);
		return sendAndGet(request);
	}
	
	
	public Response sendChooseReq(String mini_id, String id) {
		Request request = new Request(RequestType.CHOOSE_COURSE);
		request.addData("mini_id", mini_id);
		request.addData("id", id);
		return sendAndGet(request);
	}
	
	public synchronized Response responseGet() {
		Response response = null;
		
		if(ConnectionStatus.getStatus().isOnline()) {
			
		}
		try {
            response = objectMapper.readValue(scanner.nextLine(), Response.class);
        } catch (Exception e) {
        	ConnectionStatus.getStatus().setOnline(false);
        	logger.info("null response recieved");
        }
        
		return response;
	}

	public void sendDeleteReq(String mini_id, String id) {
		Request request = new Request(RequestType.DELETE_COURSE);
		request.addData("mini_id", mini_id);
		request.addData("id", id);
		sendRequest(request);
	}

	public Response sendCourseStatusReq(String mini_id, String id) {
		Request request = null;
		request = new Request(RequestType.COURSE_STATUS);
		request.addData("mini_id", mini_id);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response sendChangeGroupReq(String mini_id, String courseID, int group, String id) {
		Request request = new Request(RequestType.CHANGE_GROUP);
		request.addData("mini_id", mini_id);
		request.addData("course_id", courseID);
		request.addData("id", id);
		request.addData("group", group);
		return sendAndGet(request);
	}

	public void sendChangeCheckedReq(String mini_id, String id) {
		Request request = new Request(RequestType.CHANGE_CHECKED);
		request.addData("mini_id", mini_id);
		request.addData("id", id);
		sendRequest(request);
	}

	public Response sendCheckMapReq(String id) {
		Request request = new Request(RequestType.CHECKED_LIST);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response sendSugMapReq(String id) {
		Request request = new Request(RequestType.SUG_LIST);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public void sendMessage(int chat, String id, String other_id, String message) {
		Request request = new Request(RequestType.SEND_MESSAGE);
		request.addData("chat", chat);
		request.addData("id", id);
		request.addData("other_id", other_id);
		request.addData("message", message);
		sendRequest(request);
	}

	public Response messagesFromChat(int chatID) {
		Request request = new Request(RequestType.GET_MESSAGES);
		request.addData("chatID", chatID);
		return sendAndGet(request);
	}

	public Response chat(int chatID) {
		Request request = new Request(RequestType.CHAT);
		request.addData("chatID", chatID);
		return sendAndGet(request);
	}

	public Response createNewChat(String id, String other_id) {
		Request request = new Request(RequestType.NEW_CHAT);
		request.addData("id", id);
		request.addData("other_id", other_id);
		return sendAndGet(request);
	}

	public void sendFileAsMessage(int chatID, String id, String other_id, String encode, String extension) {
		Request request = new Request(RequestType.SEND_FILE);
		request.addData("chatID", chatID);
		request.addData("id", id);
		request.addData("other_id", other_id);
		request.addData("encode", encode);
		request.addData("extension", extension);
		sendRequest(request);
	}
	
	public Response getFullChats(String id) {
		Request request = new Request(RequestType.GET_FULL_CHATS);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public void sendToMultiple(String id, LinkedList<String> ids, String text) {
		Request request = new Request(RequestType.SEND_TO_MULTIPLE);
		request.addData("id", id);
		request.addData("ids", ids);
		request.addData("text", text);
		sendRequest(request);
	}

	public Response getMyChats(String id) {
		Request request = new Request(RequestType.GET_MY_CHATS);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getMyCourses(String id, String position) {
		Request request = new Request(RequestType.GET_MY_COURSES);
		request.addData("id", id);
		request.addData("position", position);
		sendRequest(request);
		return responseGet();
	}

	public void createExc(String mini_id, String name, String explaination, String open_time, String close_time, String mohlat,
			String allowed_type, String pdf) {
		Request request = new Request(RequestType.CREATE_EXC);
		request.addData("mini_id", mini_id);
		request.addData("name", name);
		request.addData("exp", explaination);
		request.addData("open", open_time);
		request.addData("close", close_time);
		request.addData("mohlat", mohlat);
		request.addData("type", allowed_type);
		request.addData("pdf", pdf);
		sendRequest(request);
	}

	public Response getCourseExcs(String id) {
		Request request = new Request(RequestType.GET_COURSE_EXCS);
		request.addData("id", id);
		sendRequest(request);
		return responseGet();
	}

	public Response getExcStatus(int id) {
		Request request = new Request(RequestType.EXC_STATUS);
		request.addData("id", id);
		sendRequest(request);
		return responseGet();
	}

	public Response getExcPDF(int id) {
		Request request = new Request(RequestType.EXC_PDF);
		request.addData("id", id);
		sendRequest(request);
		return responseGet();
	}

	public void sendTextAns(String id, int mini_id, String text) {
		Request request = new Request(RequestType.TEXT_ANS);
		request.addData("id", id);
		request.addData("mini_id", mini_id);
		request.addData("text", text);
		sendRequest(request);
	}

	public Response getExcSentList(int id2) {
		Request request = new Request(RequestType.EXC_SENT);
		request.addData("id", id2);
		sendRequest(request);
		return responseGet();
	}

	public Response getExcStudentMedia(String id2, int exc_id) {
		Request request = new Request(RequestType.EXC_STU_MEDIA);
		request.addData("id", id2);
		request.addData("exc_id", exc_id);
		sendRequest(request);
		return responseGet();
	}

	public void gradeStudentExc(String id2, int exc_id, double doub) {
		Request request = new Request(RequestType.GRADE_EXC);
		request.addData("id", id2);
		request.addData("exc_id", exc_id);
		request.addData("score", doub);
		sendRequest(request);
	}

	public Response getStuInfos() {
		Request request = new Request(RequestType.GET_INFO);
		sendRequest(request);
		return responseGet();
	}

	public Response getCourseSubjects(String mini_id) {
		Request request = new Request(RequestType.GET_COURSE_SUBJ);
		request.addData("id", mini_id);
		sendRequest(request);
		return responseGet();
	}

	public Response createNewSubject(String mini_id, String name) {
		Request request = new Request(RequestType.NEW_SUBJ);
		request.addData("mini_id", mini_id);
		request.addData("name", name);
		sendRequest(request);
		return responseGet();
	}

	public void createTextItem(int subj_id, String text) {
		Request request = new Request(RequestType.NEW_TEXT_ITEM);
		request.addData("subj_id", subj_id);
		request.addData("text", text);
		sendRequest(request);
	}

	public void createMediaItem(int subj_id, String encode, String ext) {
		Request request = new Request(RequestType.NEW_MEDIA_ITEM);
		request.addData("subj_id", subj_id);
		request.addData("encode", encode);
		request.addData("ext", ext);
		sendRequest(request);
	}

	public Response getItemNum(int subj_id) {
		Request request = new Request(RequestType.ITEM_NUM);
		request.addData("subj_id", subj_id);
		sendRequest(request);
		return responseGet();
	}

	public Response getSubItemsInfo(int subID) {
		Request request = new Request(RequestType.ITEMS_INFO);
		request.addData("subj_id", subID);
		sendRequest(request);
		return responseGet();
	}

	public Response getItemText(int item_id) {
		Request request = new Request(RequestType.ITEM_TEXT);
		request.addData("item_id", item_id);
		sendRequest(request);
		return responseGet();
	}

	public Response getItemBase64(int item_id) {
		Request request = new Request(RequestType.ITEM_BASE64);
		request.addData("item_id", item_id);
		sendRequest(request);
		return responseGet();
	}

	public void editTextItem(int item_id, String text) {
		Request request = new Request(RequestType.EDIT_TEXT);
		request.addData("item_id", item_id);
		request.addData("text", text);
		sendRequest(request);
	}

	public void editMediaItem(int item_id, String encode, String ext) {
		Request request = new Request(RequestType.EDIT_MEDIA);
		request.addData("item_id", item_id);
		request.addData("encode", encode);
		request.addData("ext", ext);
		sendRequest(request);
	}

	public void deleteItem(int item_id) {
		Request request = new Request(RequestType.DELETE_ITEM);
		request.addData("item_id", item_id);
		sendRequest(request);
	}

	public void deleteSubject(int subj_id) {
		Request request = new Request(RequestType.DELETE_SUBJ);
		request.addData("subj_id", subj_id);
		sendRequest(request);
	}

	public Response getCourseGroups(String courseID) {
		Request request = new Request(RequestType.COURSE_GROUPS);
		request.addData("course_id", courseID);
		sendRequest(request);
		return responseGet();
	}

	public Response getAncList(String id) {
		Request request = new Request(RequestType.ANC_LIST);
		request.addData("id", id);
		sendRequest(request);
		return responseGet();
	}

	public Response getReqList(String id) {
		Request request = new Request(RequestType.REQ_LIST);
		request.addData("id", id);
		sendRequest(request);
		return responseGet();
	}

	public Response getRespList(String id) {
		Request request = new Request(RequestType.RESP_LIST);
		request.addData("id", id);
		sendRequest(request);
		return responseGet();
	}

	public Response getAncText(int id) {
		Request request = new Request(RequestType.ANC_TEXT);
		request.addData("id", id);
		sendRequest(request);
		return responseGet();
	}

	public Response getReqInfo(int id) {
		Request request = new Request(RequestType.REQ_INFO);
		request.addData("id", id);
		sendRequest(request);
		return responseGet();
	}

	public Response getChatId(String id, String other_id) {
		Request request = new Request(RequestType.CHAT_ID);
		request.addData("id", id);
		request.addData("other_id", other_id);
		sendRequest(request);
		return responseGet();
	}

	public Response getNameInfo(String other_id) {
		Request request = new Request(RequestType.OTHER_NAME);
		request.addData("other_id", other_id);
		sendRequest(request);
		return responseGet();
	}

	public Response getBase64Info(String other_id) {
		Request request = new Request(RequestType.OTHER_BASE64);
		request.addData("other_id", other_id);
		sendRequest(request);
		return responseGet();
	}

	public Response askForChat(String id, String other_id) {
		Request request = new Request(RequestType.ASK_CHAT);
		request.addData("other_id", other_id);
		request.addData("id", id);
		return sendAndGet(request);
	}

	private synchronized Response sendAndGet(Request request) {
		sendRequest(request);
		return responseGet();
	}

	public Response getMohseniProfileStatus(String id) {
		Request request = new Request(RequestType.MOHSENI_PRO);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response addToCourse(String courseID, String type, String id) {
		Request request = new Request(RequestType.ADD_TO_COURSE);
		request.addData("id", id);
		request.addData("course_id", courseID);
		request.addData("type", type);
		return sendAndGet(request);
	}

	public void sendAddToCourseAnc(String courseID, String type, String id) {
		Request request = new Request(RequestType.ADD_TO_COURSE_ANC);
		request.addData("id", id);
		request.addData("course_id", courseID);
		request.addData("type", type);
		request.addData("course_id", courseID);
		sendRequest(request);
	}

	public Response positionType(String courseID, String id) {
		Request request = new Request(RequestType.GET_POS_TYPE);
		request.addData("id", id);
		request.addData("course_id", courseID);
		return sendAndGet(request);
	}

	public Response getCourseCal(String course_id) {
		Request request = new Request(RequestType.COURSE_CAL);
		request.addData("course_id", course_id);
		return sendAndGet(request);
	}

	public Response getCourseExcs(String mini_id, String sortBy) {
		Request request = new Request(RequestType.EXC_SORT);
		request.addData("mini_id", mini_id);
		request.addData("sort", sortBy);
		return sendAndGet(request);
	}

	public Response getExcScore(String id, int exc_id) {
		Request request = new Request(RequestType.EXC_SCORE);
		request.addData("id", id);
		request.addData("exc_id", exc_id);
		return sendAndGet(request);
	}

	public Response getExcDeliverStatus(String id, int exc_id) {
		Request request = new Request(RequestType.EXC_DEL_STATUS);
		request.addData("id", id);
		request.addData("exc_id", exc_id);
		return sendAndGet(request);
	}

	public Response getStuCal(String id) {
		Request request = new Request(RequestType.STU_CAL);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getTeacherCal(String id) {
		Request request = new Request(RequestType.TEACHER_CAL);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public void sendMohseniTextMsg(String text, String recp) {
		Request request = new Request(RequestType.MOHSENI_TEXT);
		request.addData("text", text);
		request.addData("recp", recp);
		sendRequest(request);
	}

	public Response getTeacherList() {
		Request request = new Request(RequestType.TEACHER_LIST);
		return sendAndGet(request);
	}

	public Response getExamSchd(String id) {
		Request request = new Request(RequestType.EXAM_SCHD);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getWeekSchd(String id) {
		Request request = new Request(RequestType.WEEK_SCHD);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getTempScores(String id) {
		Request request = new Request(RequestType.TEMP_SCORES);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getCredits(String id) {
		Request request = new Request(RequestType.CREDITS);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getGPA(String id) {
		Request request = new Request(RequestType.GPA);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getFullScores(String id) {
		Request request = new Request(RequestType.FULL_SCORES);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getScoreListForCourse(String id) {
		Request request = new Request(RequestType.COURSE_SCORES);
		request.addData("mini_id", id);
		return sendAndGet(request);
	}

	public void tempRegister(HashMap<String, Double> scores, String mini_id) {
		Request request = new Request(RequestType.TEMP_REG);
		request.addData("hashMap", scores);
		request.addData("mini_id", mini_id);
		sendRequest(request);
	}

	public void finalRegister(HashMap<String, Double> scores, String mini_id) {
		Request request = new Request(RequestType.FIN_REG);
		request.addData("hashMap", scores);
		request.addData("mini_id", mini_id);
		sendRequest(request);
	}

	public Response addNewCourse(String id, String name, int groups, String degree, int credit, String dep) {
		Request request = new Request(RequestType.ADD_NEW_COURSE);
		request.addData("id", id);
		request.addData("name", name);
		request.addData("groups", groups);
		request.addData("degree", degree);
		request.addData("credit", credit);
		request.addData("dep", dep);
		return sendAndGet(request);
	}

	public void sendStuReq(ReqType reqType, String recp, String dep, String id) { //TODO get response
		Request request = new Request(RequestType.STU_REQ);
		request.addData("reqType", reqType);
		request.addData("recp", recp);
		request.addData("dep", dep);
		request.addData("id", id);
		sendRequest(request);
	}

	public Response getDegree(String id) {
		Request request = new Request(RequestType.GET_DEGREE);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public void setChooseTime(int year, String dep, String time) {
		Request request = new Request(RequestType.SET_CHOOSE_TIME);
		request.addData("year", year);
		request.addData("dep", dep);
		request.addData("time", time);
		sendRequest(request);
	}

	public Response sendMainData(String id) {
		Request request = new Request(RequestType.PING_MAIN);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public void editTeacher(String id, String room, TeacherDegree degree, String manager_id) {
		Request request = new Request(RequestType.EDIT_TEACHER);
		request.addData("id", id);
		request.addData("room", room);
		request.addData("degree", degree);
		request.addData("m_id", manager_id);
		sendRequest(request);
	}

	public void removeTeacher(String teacher_id, String dep) {
		Request request = new Request(RequestType.REMOVE_TEACHER);
		request.addData("id", teacher_id);
		request.addData("dep", dep);
		sendRequest(request);
	}

	public Response addNewTeacher(String user, String pass, String first, String last, String email, String phone,
			String code, TeacherDegree teacherDegree, String room, String id2, String manager_id) {
		Request request = new Request(RequestType.ADD_TEACHER);
		request.addData("id", id2);
		request.addData("user", user);
		request.addData("pass", pass);
		request.addData("first", first);
		request.addData("last", last);
		request.addData("email", email);
		request.addData("phone", phone);
		request.addData("code", code);
		request.addData("degree", teacherDegree);
		request.addData("room", room);
		request.addData("m_id", manager_id);
		return sendAndGet(request);
	}

	public void changeDeputy(String teacher_id, String dep) {
		Request request = new Request(RequestType.CHANGE_DEPUTY);
		request.addData("t_id", teacher_id);
		request.addData("dep", dep);
		sendRequest(request);
	}

	public void protestToScore(String mini_id, String id) {
		Request request = new Request(RequestType.PROTEST);
		request.addData("id", id);
		request.addData("mini_id", mini_id);
		sendRequest(request);
	}

	public Response getProtestFeedbacks(String id) {
		Request request = new Request(RequestType.PROTEST_FEED);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getCourseProtestedStudents(String mini_id) {
		Request request = new Request(RequestType.PROTEST_STUDENTS);
		request.addData("mini_id", mini_id);
		return sendAndGet(request);
	}

	public void respondProtest(String id, String mini_id, String stat) {
		Request request = new Request(RequestType.PROTEST_RESPOND);
		request.addData("id", id);
		request.addData("mini_id", mini_id);
		request.addData("stat", stat);
		sendRequest(request);
	}

	public Response getIdByName(String name) {
		Request request = new Request(RequestType.ID_BY_NAME);
		request.addData("name", name);
		return sendAndGet(request);
	}

	public Response getCourseEduStatus(String mini_id) {
		Request request = new Request(RequestType.COURSE_EDU_STAT);
		request.addData("mini_id", mini_id);
		return sendAndGet(request);
	}

	public Response getFullScoreListForCourse(String mini_id) {
		Request request = new Request(RequestType.FULL_COURSE_SCORES);
		request.addData("mini_id", mini_id);
		return sendAndGet(request);
	}

	public void reqToTakeCourse(String mini_id, String id) {
		Request request = new Request(RequestType.REQ_TAKE_COURSE);
		request.addData("id", id);
		request.addData("mini_id", mini_id);
		sendRequest(request);
	}

	public void changeReqResponse(int id, String resp) {
		Request request = new Request(RequestType.RES_TO_REQ);
		request.addData("req_id", id);
		request.addData("resp", resp);
		sendRequest(request);
	}

	public void sendAdminMessages(LinkedList<Message> messages, String id) {
		Request request = new Request(RequestType.ADMIN_OFF_MSG);
		request.addData("messages", messages);
		request.addData("id", id);
		sendRequest(request);
	}

	public void correctChoices(String id) {
		Request request = new Request(RequestType.CORRECT);
		request.addData("id", id);
		sendRequest(request);
	}

	public void sendMediaAns(int exc_id, String encode, String ext, String id) {
		Request request = new Request(RequestType.MEDIA_ANS);
		request.addData("id", id);
		request.addData("exc_id", exc_id);
		request.addData("encode", encode);
		request.addData("ext", ext);
		sendRequest(request);
	}

	public Response getRecomList(String id) {
		Request request = new Request(RequestType.RECOM_LIST);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getRecomText(String id, String teacher_id) {
		Request request = new Request(RequestType.RECOM_TEXT);
		request.addData("id", id);
		request.addData("teacher_id", teacher_id);
		return sendAndGet(request);
	}

	public void addNewStudent(String user, String pass, String first, String last, String email, String phone,
			String code, StudentDegree degree, String id, String sup, String year, String dep) {
		Student student = new Student("Student", user, pass, first, last, email, phone, id, code , dep, degree, sup, year);
		Request request = new Request(RequestType.NEW_STU);
		request.addData("stu", student);
		sendRequest(request);
	}

	public void sendMohseniMediaMesg(String encode, String ext, String recp) {
		Request request = new Request(RequestType.MOHSENI_MEDIA);
		request.addData("encode", encode);
		request.addData("ext", ext);
		request.addData("recp", recp);
		sendRequest(request);
	}

	public void removeCourse(String mini_id) {
		// TODO Auto-generated method stub
		
	}

	public Response getCertificate(String id) { //get data
		Request request = new Request(RequestType.CERTIFICATE);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public Response getAllProtests(String mini_id) {
		Request request = new Request(RequestType.ALL_PROTESTS);
		request.addData("mini_id", mini_id);
		return sendAndGet(request);
	}


	public Response getTeacherScores(String teach_id) {
		Request request = new Request(RequestType.TEACH_TEMP);
		request.addData("teach_id", teach_id);
		return sendAndGet(request);
	}

	public void changePass(String pass, String id) {
		Request request = new Request(RequestType.PASS_CHANGE);
		request.addData("id", id);
		request.addData("pass", pass);
		sendRequest(request);
	}

	public Response sendPassDiffRequest(String id) {
		Request request = new Request(RequestType.SHOULD_CHANGE_PASS);
		request.addData("id", id);
		return sendAndGet(request);
	}

	public void changeData(String data, String type, String id) {
		Request request = new Request(RequestType.CHANGE_DATA);
		request.addData("id", id);
		request.addData("data", data);
		request.addData("type", type);
		sendRequest(request);
	}

	public void sendFileToMultiple(LinkedList<String> ids, String encode, String ext, String id) {
		Request request = new Request(RequestType.FILE_TO_MULTIPLE);
		request.addData("id", id);
		request.addData("ids", ids);
		request.addData("encode", encode);
		request.addData("ext", ext);
		sendRequest(request);
	}

	
	

	
	
}

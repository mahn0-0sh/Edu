package client;

import shared.model.Person;

public class ConnectionStatus {
	static ConnectionStatus connectionStatus;
    private boolean online;

    private ConnectionStatus() {
        online = false;
    }

    public static ConnectionStatus getStatus() {
        if (connectionStatus == null) connectionStatus = new ConnectionStatus();
        return connectionStatus;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }
   

    public boolean isOnline() {
        return online;
    }

}

package client;

import client.controller.*;
import client.network.ServerController;
import constants.Constants;
import cw.CWController;
import cw.view.course.shared.CoursePageMain;
import cw.view.main.*;
import database.*;
import enums.*;
import extra_roles.mohseni.*;
import login.*;
import message.*;
import message.view.*;
import shared.*;
import shared.model.*;
import shared.response.*;
import shared.util.*;
import shared.util.extra.*;
import student.*;
import teacher.*;
import teacher.deputy.*;
import teacher.manager.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import chat.ChatController;
import chat.view.*;
import chooseCourse.ChooseController;
import chooseCourse.view.*;


public class Client {
	private Logger logger = LogManager.getLogger(Client.class);
	private final Double fps = new Config(Constants.CONFIG_ADDRESS).getProperty(Double.class, "refreshLoop");
	private Loop loop;
    private ServerController serverController;
    private final int port;
    private String authToken ,id, position, dep;
    private OfflineController controller = new OfflineController();

    public Client(int port) {
        this.port = port;
    }

    public void start() {
        serverController = new ServerController(port);
        serverController.connectToServer();
        initControllers();
        if(ConnectionStatus.getStatus().isOnline()) loginGUI();
    }
    
    
    private void loginGUI() {
    	GraphicsHandler.getGH().setClient(this);
    	GraphicsHandler.getGH().loginGUI();
    }

    private void initDatas(Response response, String username) {
    	authToken = (String) response.getData("token");
    	serverController.setAuthToken(authToken);            	
    	id = username;
    	position = (String) response.getData("position"); 
    	dep = (String) response.getData("dep");
    }

    public void login(String username, String password) {
        Response response = serverController.sendLoginRequest(username, password);
        if(response != null) {
        	if (response.getStatus() == ResponseStatus.OK) {
        		initDatas(response, username);            	
            	startLoops();
            	
        		Response pass_response = serverController.sendPassDiffRequest(username);
        		boolean b = (boolean) pass_response.getData("data");
        		if(b) showPassChange();
        		else {    	
                	mainPage(); 
                	try {
    					sendAdminMessages();
    				} catch (SQLException e) {
    					e.printStackTrace();
    				} 
        		} 
            } else {
                JOptionPane.showMessageDialog(null, response.getErrorMessage());
            }
        } else {
        	logger.info("login resp null.");
        }        
    }
    
    
   

	void startLoops() {
    	Loop mainData  = new Loop(fps, () -> {
    		try {
    			mainDataRefresh();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	});
    	mainData.start();
    }
    
    
    @SuppressWarnings("unchecked")
	void mainDataRefresh() throws SQLException {
    	if(ConnectionStatus.getStatus().isOnline()) {
    		Response response = serverController.sendMainData(id);
        	Refresh.mainDataRefresh(response, position);
    	}
    }
    
     
    public String mainPageStatus() {
    	String status = null;
    	try {
    		if(ConnectionStatus.getStatus().isOnline()) {
    			Response response = serverController.sendMainPageReq(id);
    			if(response != null) status =  Methods.mainStatus(response, position);
    		} else {
    			visitHome();
    		}
    		
            return status;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	} 
    
    private void initControllers() {
    	Controller.setClient(this);
    	PhaseController.setClient(this, serverController);
    	ChooseController.setClient(this, serverController);
    	CWController.setClient(this, serverController);
    	ChatController.setClient(this, serverController);
    	MohseniController.setClient(this, serverController);
    	MsgController.setClient(this, serverController);
    	ReqController.setClient(this, serverController);
    }
    
    public void mainPage() {
    	GraphicsHandler.getGH().mainPage();
    }

    private void mainMenuGUI(String status) {   
    	GraphicsHandler.getGH().mainMenuGUI(status);
	}
    
    
    public void visitHome() throws SQLException {
    	GraphicsHandler.getGH().visitHome();
	}
    
    
    public String getId() {
		return id;
	}

	public String getPosition() {
		return position;
	}
    
    public void exit() {
    //	serverController.sendExitReq(id);
	}

	public String profile() throws SQLException {
        Response response = serverController.sendProfileReq(id);
        String status = "";
        if(response != null) {
        	 if (response.getStatus() == ResponseStatus.STU) { //TODO pos
             	status = Methods.stuProfileStatus(response);
     		} else {
     			status = Methods.teacherProfileStatus(response);
     		}
        } else {
        	if(position.equals("Student")) {
        		status = Methods.stuProfileStatus(LoadDB.getDB().loadStudent(id));
        	} else {
        		status = Methods.teacherProfileStatus(LoadDB.getDB().loadTeacher(id));
        	}
        }
        
        return status;
	}
	
	
	public void deleteCourse(String mini_id, String id) {
		serverController.sendDeleteReq(mini_id, id);
	}
	
	public void changeChecked(String mini_id, String id) {
		serverController.sendChangeCheckedReq(mini_id, id);
	}
	
	public void sendMessage(int chat, String id, String other_id, String message) throws SQLException {
		if(ConnectionStatus.getStatus().isOnline()) {
			serverController.sendMessage(chat, id, other_id, message);
		} else if(other_id.equals("1")) {
				Message message2 = new Message(id+": "+message, "", chat, id);
				SaveDB.getDB().updateAdminChatTable(id, message2);
				JOptionPane.showMessageDialog(null, "Message saved.");
		}
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Message> messagesFromChat(int chatID) throws SQLException {
		Response response = serverController.messagesFromChat(chatID);
		if(response != null) return (ArrayList<Message>) response.getData("list");
		return controller.getMessagesFromChat(chatID);
	}

	public Chat chat(int chatID) {
		Response response = serverController.chat(chatID);
		if(response != null) return (Chat) response.getData("chat");
		return null;
	}

	public void sendFileAsMessage(int chatID, String id, String other_id, String encode, String extension) throws SQLException {
		if(ConnectionStatus.getStatus().isOnline()) {
			serverController.sendFileAsMessage(chatID, id, other_id, encode, extension);
		} else {
			if(other_id.equals("1")) {
				Message message2 = new Message(id+": "+extension, encode, chatID, id);
				SaveDB.getDB().updateAdminChatTable(id, message2);
				JOptionPane.showMessageDialog(null, "Message saved.");
			}
		}
	}
	

	public void sendToMultiple(LinkedList<String> ids, String text) {
		serverController.sendToMultiple(id, ids, text);
	}

	@SuppressWarnings("unchecked")
	public LinkedList<String> getMyChats() throws SQLException {
		Response response = serverController.getMyChats(id);
		if(response != null) return (LinkedList<String>) response.getData("list");
		return controller.getMyChats(id);
	}

	
	public void createExc(String mini_id, String name, String explaination, String open_time, String close_time,
			 String mohlat, String allowed_type, String pdf) {
		serverController.createExc(mini_id, name, explaination, open_time, close_time, mohlat, allowed_type, pdf);
	}


	public void sendTextAns(int mini_id, String text) {
		serverController.sendTextAns(id, mini_id, text);
	}

	public void gradeStudentExc(String id2, int exc_id, double doub) {
		serverController.gradeStudentExc(id2, exc_id, doub);
	}

	public int createNewSubject(String mini_id, String name) {
		Response response = serverController.createNewSubject(mini_id, name);
		return (int) response.getData("subj_id");
	}

	public void createTextItem(int subj_id, String text) {
		serverController.createTextItem(subj_id, text);
	}

	public void createMediaItem(int subj_id, String encode, String ext) {
		serverController.createMediaItem(subj_id, encode, ext);
	}


	public void editTextItem(int item_id, String text) {
		serverController.editTextItem(item_id, text);
	}

	public void editMediaItem(int item_id, String encode, String ext) {
		serverController.editMediaItem(item_id, encode, ext);
	}

	public void deleteItem(int item_id) {
		serverController.deleteItem(item_id);
	}

	public void deleteSubject(int subj_id) {
		serverController.deleteSubject(subj_id);
	}


	public int getChatId(String id2, String other_id) throws SQLException {
		Response response = serverController.getChatId(id2, other_id);
		try {
			return (Integer) response.getData("chat_id");
		} catch (Exception e) {
			return LoadDB.getDB().getChatId(id2, other_id);
		}
	}

	public void sendAddToCourseAnc(String courseID, String type, String id2) {
		serverController.sendAddToCourseAnc(courseID, type, id2);
	}

	
	@SuppressWarnings("unchecked")
	public LinkedList<String> getExamSchd() {
		Response response = serverController.getExamSchd(id);
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}

	@SuppressWarnings("unchecked")
	public LinkedList<String> getWeekSchd() {
		Response response = serverController.getWeekSchd(id);
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}
	
	public int getCredits(String id) throws SQLException {
		int i = -1;
		Response response = serverController.getCredits(id);
		if(response != null) i = (int) response.getData("info");
		else i = LoadDB.getDB().passedCredits(id);
		return i;
	}
	
	public Double getGPA(String id) throws SQLException {
		Response response = serverController.getGPA(id);
		if(response != null) {
			try {
				return (Double) response.getData("info");
			} catch (Exception e) {
				return null;
			}
		} else {
			return LoadDB.getDB().getGPA(id);
		}
	}
	
	@SuppressWarnings("unchecked")
	public LinkedList<String> getFullScores(String id) throws SQLException {
		Response response = serverController.getFullScores(id);
		if(response != null) return (LinkedList<String>) response.getData("list");
		else return LoadDB.getDB().getFullScores(id);
	}

	
	public void CWgui() {
    	GraphicsHandler.getGH().CWgui();
	}

	public String getDep() {
		return dep;
	}

	public void showReqPage() {
		GraphicsHandler.getGH().showReqPage();
	}


	public void setChooseTime(int year, String dep2, String time) {
		serverController.setChooseTime(year, dep, time);
	}


	public void showPrefferedPage() {
		GraphicsHandler.getGH().showPrefferedPage();
	}

	public void showChangeGroup(String mini_id, String courseID) { 
		GraphicsHandler.getGH().showChangeGroup(mini_id, courseID);
	}

	public void reqToTakeCourse(String mini_id) {
		serverController.reqToTakeCourse(mini_id, id);
	}

	public void editTeacher(String room, TeacherDegree degree) {
		serverController.editTeacher(id, room, degree, id);
	}

	public void showManagerTeacherEdit(String teacher_id) {
		GraphicsHandler.getGH().showManagerTeacherEdit(teacher_id);
	}

	public void removeTeacher(String teacher_id) {
		serverController.removeTeacher(teacher_id, dep);
	}

	public void showAddTeacher() {
		GraphicsHandler.getGH().showAddTeacher();
	}

	public void changeDeputy(String teacher_id) { //TODO same time?
		serverController.changeDeputy(teacher_id, dep);
	}

	public void protestToScore(String mini_id) {
		serverController.protestToScore(mini_id, id);
	}

	public void showProtestFeedbackDialog() { //TODO
		GraphicsHandler.getGH().showProtestFeedbackDialog();
	}

	public void showProtests(String mini_id) {
		GraphicsHandler.getGH().showProtests(mini_id);
	}

	public void showDepTempScores() {
		GraphicsHandler.getGH().showDepTempScores();
	}

	public void reconnect() {
		try {
			this.start();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Couldn't make connection.");
		}
	}
	
	public void sendAdminMessages() throws SQLException {
		serverController.sendAdminMessages(LoadDB.getDB().getAdminMessages(id), id);
		SaveDB.getDB().deleteMessages(id);
	}

	public void correctChoices() {
		serverController.correctChoices(id);
	}

	public void sendMediaAns(int exc_id, String encode, String ext) {
		serverController.sendMediaAns(exc_id, encode, ext, id);
	}

	
	public void showCoursePageMain(String courseID) {
		GraphicsHandler.getGH().showCoursePageMain(courseID);	
	}
	
	public void showExamSchd() throws SQLException {
		GraphicsHandler.getGH().showExamSchd();
	}

	public void showCoursesList() { 
		GraphicsHandler.getGH().showCoursesList();	
	}
	
	public void chatGui() {
		GraphicsHandler.getGH().chatGui();
	}
    
    public void chatRoomGUI(int chatId, String id, String other_id) throws IOException { 	
    	GraphicsHandler.getGH().chatRoomGUI(chatId, id, other_id);
	}
    public void courseChooseGUI() {
    	GraphicsHandler.getGH().courseChooseGUI();
	}
	public void showTeachersList() {
		GraphicsHandler.getGH().showTeachersList();
	}

	public void showWeekSchd() throws SQLException {
		GraphicsHandler.getGH().showWeekSchd();
	}
	
	public void showTempScores(String id) {
		GraphicsHandler.getGH().showTempScores(id);
	}
	public void showEduStatus() {  // for stu
		GraphicsHandler.getGH().showEduStatus();
	}
	
	public void showEduStatus(String id) {  //For deputy
		GraphicsHandler.getGH().showEduStatus(id);
	}

	public void showProfile() throws SQLException {
		GraphicsHandler.getGH().showProfile();
	}

	public void showRegScoresPage(String mini_id) {
		GraphicsHandler.getGH().showRegScoresPage(mini_id);
	}
	
	public void showDepEduStatus() {
		GraphicsHandler.getGH().showDepEduStatus();
	}

	public void showAddCourse() {
		GraphicsHandler.getGH().showAddCourse();
	}
	
	public void showAllTimeProtests(String mini_id) {
		GraphicsHandler.getGH().showAllTimeProtests(mini_id);
	}

	public void showScoresOfClass(String mini_id) {
		GraphicsHandler.getGH().showScoresOfClass(mini_id);
	}

	public void showManagerEditPage() {
		GraphicsHandler.getGH().showManagerEditPage();
	}

	public void showRecomPage() {
		GraphicsHandler.getGH().showRecomPage();
	}

	public void showChatMain() {
		GraphicsHandler.getGH().chatGui();			
	}

	public void showMsgMain() {
		GraphicsHandler.getGH().showMsgMain();
	}

	public void showReqDialog(int req_id) {
		GraphicsHandler.getGH().showReqDialog(req_id);
	}

	public void showStuRecomFeed() {
		GraphicsHandler.getGH().showStuRecomFeed();
	}

	public void addNewStudent(String user, String pass, String first, String last, String email, String phone,
			String code, StudentDegree degree, String id, String sup, String year) {
		serverController.addNewStudent(user, pass, first, last, email, phone, code, degree, id, sup, year,dep);
	}


	public void showAddStudent() {
		GraphicsHandler.getGH().showAddStu();
	}

	public void showDepEditCourse(String mini_id) {
		GraphicsHandler.getGH().showDepEditCourse(mini_id);
	}

	public void showCertificate() {
		GraphicsHandler.getGH().showCertificate();
	}

	public void showDeputyTeacherScores(String teach_id) {
		GraphicsHandler.getGH().showDeputyTeacherScores(teach_id);
	}
	
	private void showPassChange() {
		GraphicsHandler.getGH().showPassChange();
	}
	
}
//1497 -> 1369 -> 1353 -> 1281 -> 1233 -> 1129 -> 1030 -> 946 -> 930 -> 901 -> 851 -> 785 -> 756 -> 713 -> 667 -> 539
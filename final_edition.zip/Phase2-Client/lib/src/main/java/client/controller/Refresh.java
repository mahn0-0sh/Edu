package client.controller;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedList;

import client.ConnectionStatus;
import database.SaveDB;
import shared.model.Chat;
import shared.model.MiniCourse;
import shared.model.Student;
import shared.model.Teacher;
import shared.response.Response;
import shared.util.ListUtil;

public class Refresh {

	@SuppressWarnings("unchecked")
	
	public static void mainDataRefresh(Response response, String position) throws SQLException {
		if( response != null ) {
    		
			try {
				if(position.equals("Student")) {
					
					Student student = ListUtil.getStudent((String) response.getData("person"));
					SaveDB.getDB().saveStudent(student);
					
				    HashMap<String, String> course_stat = (HashMap<String, String>) response.getData("course_map");
				    for(String course : course_stat.keySet()) {
						MiniCourse miniCourse = ListUtil.getMiniCourse(course);
						SaveDB.getDB().updateJoiningTable(miniCourse, course_stat.get(course));
					}
				    
				} else if(position.equals("Teacher") || position.equals("Deputy") || position.equals("Manager")) {
					
					
					Teacher teacher = ListUtil.getTeacher((String) response.getData("person"));
					SaveDB.getDB().saveTeacher(teacher);
					
					LinkedList<MiniCourse> courses = (LinkedList<MiniCourse>) response.getData("courses"); 
					SaveDB.getDB().updateTeacherCourseTable(teacher.getID(), courses);
					
					
				}
				
				HashMap<String, String> chats = (HashMap<String, String>) response.getData("chats");
				for(String chat : chats.keySet()) {
					Chat chat2 = ListUtil.getChat(chat);
					SaveDB.getDB().updateChatTable(chat2, chats.get(chat));
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	}
        	
    	
}



package client.controller;

import java.sql.SQLException;
import java.util.LinkedList;

import client.Client;
import database.LoadDB;
import shared.model.Message;
import shared.response.Response;

public class Controller {
	
	static Client client;
	
	public void exit() {
		client.exit();
	}
	
	public void visitHome() {
		try {
			client.visitHome();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	public static void setClient(Client client2) {
		client = client2;
	}
	
	public LinkedList<String> listFromResp(Response response) {
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}
	

	public String getPosition() {
		return client.getPosition();
	}
	
}

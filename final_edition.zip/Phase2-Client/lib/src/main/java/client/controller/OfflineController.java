package client.controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;

import database.LoadDB;
import shared.model.Chat;
import shared.model.Message;
import shared.model.Student;
import shared.model.Teacher;

public class OfflineController {

	public String mainPageStudent(String id) throws SQLException { //name email vaizat sup moj sign last
		Student student = LoadDB.getDB().loadStudent(id);
		String s0 = student.getName();
        String s1 = student.getEmail();
        String s6 = student.getLastVisit();
        String s2 = student.getStatus()+"";
        String s3 = student.getSupervisor(); //TODO name
        String s4 = student.getMojavez();
        String s5 = student.getSignUpTime();
        String s7 = student.getUsername();
        
        String status = s0 +"`"+ s1 +"`"+ s2 +"`"+ s3 +"`"+ s4 +"`"+ s5 +"`"+ s6 +"`"+ s7;
        return status;
	}
	
	
	public String mainPageTeacher(String id) throws SQLException { 
		Teacher student = LoadDB.getDB().loadTeacher(id);
		String s0 = student.getName();
        String s1 = student.getEmail();
        String s6 = student.getLastVisit();
        
        String status = s0 +"`"+ s1 +"`"+ s6;
        return status;
	}

	public LinkedList<String> getWeekSchedStu(String id) throws SQLException {
		return LoadDB.getDB().getWeekSchd(id);
	}

	public LinkedList<String> getMyChats(String id) throws SQLException {
		return LoadDB.getDB().getMyChats(id);
	}

	public ArrayList<Message> getMessagesFromChat(int chat_id) throws SQLException {
		return LoadDB.getDB().getMessages(chat_id);
	}

	public LinkedList<String> getExamSchd(String id) throws SQLException {
		return LoadDB.getDB().getExamSchd(id);
	}
	
	
	
}

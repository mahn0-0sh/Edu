package client;

import java.sql.SQLException;

import constants.Constants;
import database.LoadDB;
import database.SaveDB;
import shared.util.*;

public class ClientMain {
    public static void main(String[] args) {
        Integer port = Config.getConfig().getProperty(Integer.class, "serverPort");
        
        
        String url = new Config(Constants.CONFIG_ADDRESS).getProperty(String.class, "db_url");
        String username = new Config(Constants.CONFIG_ADDRESS).getProperty(String.class, "db_username");
        String password = new Config(Constants.CONFIG_ADDRESS).getProperty(String.class, "db_password");
        
        try
        {
            LoadDB.getDB().connectToDatabase(url, username, password);
        }
        catch (SQLException throwable)
        {
            System.err.println(throwable);
        }
        
        
        Client client = new Client(port);
        client.start(); 
    }
}

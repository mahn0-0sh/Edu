package client;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;

import database.LoadDB;
import shared.model.Course;
import shared.model.Student;
import shared.model.Teacher;
import shared.response.Response;

public class Methods {

	public static String mainStatus(Response response, String pos) {
		String status = null;
		try {
			String s0 = (String) response.getData("name");
	        String s1 = (String) response.getData("email");
	        String s6 = (String) response.getData("lastVisit");
	        
			if(pos.equals("Student")) {
		        String s2 = (String) response.getData("vaziat").toString();
		        String s3 = (String) response.getData("supervisor");
		        String s4 = (String) response.getData("mojavez");
		        String s5 = (String) response.getData("signUpTime");
		        String s7 = (String) response.getData("username");
		        status = s0 +"`"+ s1 +"`"+ s2 +"`"+ s3 +"`"+ s4 +"`"+ s5 +"`"+ s6 +"`"+ s7;
			} else {
				status = s0 +"`"+ s1 +"`"+ s6;
			}
			
		} catch (Exception e) {
			status = null;
		}
		
        return status;
	}
	
	
	
	public static String mohseniProStatus(Response response) {
		String status = "";
		try {
			String s0 = (String) response.getData("name");
	        String s1 = (String) response.getData("code");
	        String s2 = (String) response.getData("id");
	        String s3 = (String) response.getData("phone");
	        String s4 = (String) response.getData("email");
	        String s5 = (String) response.getData("department");
	        String s6 = (String) response.getData("supervisor");
	        String s7 = (String) response.getData("year");
	        String s8 = (String) response.getData("degree").toString();
	        
	        status = s0 +"`"+ s1 +"`"+ s2 +"`"+ s3 +"`"+ s4 +"`"+ s5 +"`"+ s6 +"`"+ s7 +"`"+ s8;
		} catch (Exception e) {
			status = "";
			System.out.println(e);
		}
		
        return status;
	}
	
	

	public static String stuProfileStatus(Response response) {
		String s0 = (String) response.getData("name");
        String s1 = (String) response.getData("code");
        String s2 = (String) response.getData("id");
        String s3 = (String) response.getData("phone");
        String s4 = (String) response.getData("email");
        String s5 = (String) response.getData("department").toString(); 
        String s6 = (String) response.getData("gpa");
        String s7 = (String) response.getData("supervisor");
        String s8 = (String) response.getData("year");
        String s9 = (String) response.getData("degree").toString();
        String s10 = (String) response.getData("status").toString();
        
        String status = s0 +"/"+ s1 +"/"+ s2 +"/"+ s3 +"/"+ s4 +"/"+ s5 +"/"+ s6 +"/"+ s7 +"/"+ s8 +"/"+ s9 +"/"+ s10;
        return status;
	}

	public static String stuProfileStatus(Student student) throws SQLException {
		String s0 = student.getName();
        String s1 = student.getCode();
        String s2 = student.getID();
        String s3 = student.getPhoneNumber();
        String s4 = student.getEmail();
        String s5 = student.getDepartment(); 
        String s6 = LoadDB.getDB().getGPA(student.getID())+"";
        String s7 = student.getSupervisor();;
        String s8 = student.getYearOfArrival();
        String s9 = student.getDegree().toString();;
        String s10 = student.getStatus().toString();
        
        String status = s0 +"/"+ s1 +"/"+ s2 +"/"+ s3 +"/"+ s4 +"/"+ s5 +"/"+ s6 +"/"+ s7 +"/"+ s8 +"/"+ s9 +"/"+ s10;
        return status;
	}
	
	
	public static String teacherProfileStatus(Response response) {
		String s0 = (String) response.getData("name");
        String s1 = (String) response.getData("code");
        String s2 = (String) response.getData("id");
        String s3 = (String) response.getData("phone");
        String s4 = (String) response.getData("email");
        String s5 = (String) response.getData("department").toString(); 
        String s6 = (String) response.getData("room");
        String s7 = (String) response.getData("degree").toString();
        
        String status = s0 +"/"+ s1 +"/"+ s2 +"/"+ s3 +"/"+ s4 +"/"+ s5 +"/"+ s6 +"/"+ s7;
        return status;
	}
	
	public static String teacherProfileStatus(Teacher teacher) {
		String s0 = teacher.getName();
        String s1 = teacher.getCode();
        String s2 = teacher.getID();
        String s3 = teacher.getPhoneNumber();
        String s4 = teacher.getEmail();
        String s5 = teacher.getDepartment(); 
        String s6 = teacher.getRoom();
        String s7 = teacher.getTeacherDegree().toString();
        
        String status = s0 +"/"+ s1 +"/"+ s2 +"/"+ s3 +"/"+ s4 +"/"+ s5 +"/"+ s6 +"/"+ s7;
        return status;
	}
	
	
}

package resources;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class CapchaPics extends JLabel {
	
	
	static ImageIcon cap1 = img(new ImageIcon("CapchaPics/jcaptcha1.jpg")); // 6313
	static ImageIcon cap2 = img(new ImageIcon("CapchaPics/jcaptcha2.jpg")); //7805
	static ImageIcon cap3= img(new ImageIcon("CapchaPics/jcaptcha3.jpg")); //1043
	static ImageIcon cap4 = img(new ImageIcon("CapchaPics/jcaptcha4.jpg")); //2821
	static ImageIcon cap5 = img(new ImageIcon("CapchaPics/jcaptcha5.jpg")); //8248
	
	
	
	public CapchaPics(int n, JLabel jlb) {
		
		switch (n) {
		case 1:
			jlb.setIcon(cap1);
			break;
			
		case 2:
			jlb.setIcon(cap2);
			break;
			
		case 3:
			jlb.setIcon(cap3);
			break;
			
		case 4:
			jlb.setIcon(cap4);
			break;
			
		case 5:
			jlb.setIcon(cap5);
			break;
			
		

		default:
			break;
		}
		
	}
	
	public static boolean isCapchaCorrect(int capchaNumer, String text) {
		switch (capchaNumer) {
		case 1:
			if(text.equals("6313")) return true;
			else return false;
		case 2:
			if(text.equals("7805")) return true;
			else return false;
		case 3:
			if(text.equals("1043")) return true;
			else return false;
		case 4:
			if(text.equals("2821")) return true;
			else return false;
		case 5:
			if(text.equals("8248")) return true;
			else return false;
		default:
			return false;
		}
		
	}
	
	
	static ImageIcon img(ImageIcon imageIcon) {
		  Image image = imageIcon.getImage(); 
		  Image newimg = image.getScaledInstance(90, 90,  java.awt.Image.SCALE_SMOOTH); 
		  imageIcon = new ImageIcon(newimg);
		  return imageIcon;
	}




	public static ImageIcon getCap1() {
		return cap1;
	}


	public static void setCap1(ImageIcon cap1) {
		CapchaPics.cap1 = cap1;
	}


	public static ImageIcon getCap2() {
		return cap2;
	}


	public static void setCap2(ImageIcon cap2) {
		CapchaPics.cap2 = cap2;
	}


	public static ImageIcon getCap3() {
		return cap3;
	}


	public static void setCap3(ImageIcon cap3) {
		CapchaPics.cap3 = cap3;
	}


	public static ImageIcon getCap4() {
		return cap4;
	}


	public static void setCap4(ImageIcon cap4) {
		CapchaPics.cap4 = cap4;
	}


	public static ImageIcon getCap5() {
		return cap5;
	}


	public static void setCap5(ImageIcon cap5) {
		CapchaPics.cap5 = cap5;
	}
	
	
	
	
	
	
	
}

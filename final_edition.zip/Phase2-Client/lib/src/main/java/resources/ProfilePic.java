package resources;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class ProfilePic extends JLabel {
	
	
	public static ImageIcon pic = img(new ImageIcon("Pic/profilePic.jpg"));
	
	
	
	public ProfilePic(JLabel jlb) {
		
		jlb.setIcon(pic);
		
	}
	
	
	
	static ImageIcon img(ImageIcon imageIcon) {
		  Image image = imageIcon.getImage(); 
		  Image newimg = image.getScaledInstance(90, 90,  java.awt.Image.SCALE_SMOOTH); 
		  imageIcon = new ImageIcon(newimg);
		  return imageIcon;
	}


	
	
	
}

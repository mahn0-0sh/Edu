package chat;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import client.Client;
import client.ConnectionStatus;
import client.controller.Controller;
import client.network.ServerController;
import shared.model.Message;
import shared.response.Response;

public class ChatController extends Controller {
	static Client client;
	static ServerController serverController;
	private Logger logger = LogManager.getLogger(ChatController.class);

	public LinkedList<String> getMyCurrentChats() {
		try {
			return client.getMyChats();
		} catch (SQLException e) {
			logger.info(e);
			return null;
		}
	}
	
	public LinkedList<String> getMyFullList() {
		Response response = serverController.getFullChats(client.getId());
		if(response != null) return (LinkedList<String>) response.getData("list");
		LinkedList<String> offExist = new LinkedList<>();
		offExist.add("1 Admin");
		return offExist;
	}
	
	public void sendMessageToMultiple(LinkedList<String> ids, String text) {
		serverController.sendToMultiple(client.getId(), ids, text);
	}

	public ArrayList<Message> messagesFromChat(int chatID) {
		try {
			return client.messagesFromChat(chatID);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public void sendMessage(int chatID, String id, String other_id, String message) throws SQLException {
		client.sendMessage(chatID, id, other_id, message);
	}

	public void sendFileAsMessage(int chatID, String id, String other_id, String encode, String extension) throws SQLException {
		client.sendFileAsMessage(chatID, id, other_id, encode, extension);
	}

	public String getClientId() {
		return client.getId();
	}

	public int getChatId(String id, String other_id) {
		try {
			return client.getChatId(id, other_id);
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}

	public void goToChatRoom(int chatId, String id, String other_id) {
		try {
			client.chatRoomGUI(chatId, id, other_id);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String createNewChat(String other_id) {
		Response response = serverController.createNewChat(client.getId(), other_id);
		if(response != null) return (String) response.getData("msg");
		return null;
	}

	public String getName(String other_id) {
		Response response = serverController.getNameInfo(other_id);
		if(response != null) return (String) response.getData("info");
		return null;
	}

	public String getBase64(String other_id) {
		Response response = serverController.getBase64Info(other_id);
		if(response != null) return (String) response.getData("info");
		return null;
	}

	public String askForChat(String other_id) {
		Response response = serverController.askForChat(client.getId(),  other_id);
		if(response != null) return (String) response.getData("resp");
		if(!ConnectionStatus.getStatus().isOnline()) return "Offline";
		return null;
	}

	public static void setClient(Client client2, ServerController serverController2) {
		client = client2;		
		serverController = serverController2;
	}

	public void sendFileToMultiple(LinkedList<String> ids, String encode, String ext) {
		serverController.sendFileToMultiple(ids, encode, ext, client.getId());
	}
}

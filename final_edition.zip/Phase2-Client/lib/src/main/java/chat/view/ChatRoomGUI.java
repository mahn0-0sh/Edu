package chat.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.EventQueue;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.border.EmptyBorder;

import chat.ChatController;
import client.Client;
import constants.Constants;
import shared.model.Chat;
import shared.model.Message;
import shared.util.Config;
import shared.util.FileStuff;
import shared.util.extra.FileUtil;

import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.JLabel;

public class ChatRoomGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private int chatID;
	private String id;
	private String other_id;
	private JPanel jPanel;
	private ChatComponents chatComponents;
	private ChatController controller;
	private JLabel picLbl;
	private JLabel nameLbl;
	
	
	public ChatRoomGUI(int chatID, String id, String other_id) throws IOException {
		controller = new ChatController();
		this.id = id;
		this.other_id = other_id;
		this.chatID = chatID;
		
		chatComponents = new ChatComponents(this);
		String name = controller.getName(other_id);
		String base64 = controller.getBase64(other_id);
		
		
		initPane();
		initScroll();
		
		ArrayList<Message> messages = controller.messagesFromChat(chatID);
		
		jPanel.removeAll();
		jPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);  
		jPanel.setLayout(new GridBagLayout());
		chatComponents.addComponentsToPane(jPanel, messages, id);
		
		initPanel(name, base64);
		textField();
		sendBtn();
		fileBtn();
		
		homeBtn();
		exitBtn();
	}
	
	void initScroll() {
		jPanel = new JPanel();
		JScrollPane scrollPane = new JScrollPane(jPanel);
		scrollPane.setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSPx"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSPy"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSPw"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSPh")); 
		contentPane.add(scrollPane);
		jPanel.setBorder(BorderFactory.createLineBorder(Color.red));
	}
	
	void sendBtn() {
		JButton sendButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "send"));
		sendButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String message = textField.getText();
				if(!message.equals("")) {
					try {
						controller.sendMessage(chatID, id, other_id, message);
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		sendButton.setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSx"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSy"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSw"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSh")); 
		contentPane.add(sendButton);
	}

	void fileBtn() {
		JButton fileButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "fileButton"));
		fileButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] s = FileStuff.chooseFile();
				if(!s[1].equals("")) {
					try {
						controller.sendFileAsMessage(chatID, id, other_id, s[0], s[1]);
					} catch (SQLException e1) {
						e1.printStackTrace();
					}	
				}
				
			}
		});
		fileButton.setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSx"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatFy"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSw"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatSh")); 
		contentPane.add(fileButton);
	}
	
	void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "x"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "y"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "w"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "h")); 
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}
	
	void initPanel(String name, String base64) throws IOException {
		JPanel panel = new JPanel();
		panel.setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatDPx"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatDPy"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatDPw"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "chatDPh")); 
		contentPane.add(panel);
		panel.setLayout(null);
		
		picLbl = new JLabel();
		picLbl.setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "picX"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "picY"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "picW"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "picH")); 
		panel.add(picLbl);
		
		if(base64 != null && base64 != "") {
			ByteArrayInputStream inputStream = new ByteArrayInputStream(FileUtil.decode(base64));                         
		    BufferedImage bufImage = ImageIO.read(inputStream);
		    ImageIcon icon = new ImageIcon(bufImage);
		    picLbl.setIcon(icon);
		}
	    
		nameLbl = new JLabel(name);
		nameLbl.setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "nameX"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "nameY"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "nameW"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "nameH"));  
		panel.add(nameLbl);
	}
	
	void textField() {
		textField = new JTextField();
		textField.setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "fx"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "fy"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "fw"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "fh"));  	
		contentPane.add(textField);
		textField.setColumns(10);
	}
	
	void exitBtn() {
		JButton exitBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "exit"));
		exitBtn.setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "ex"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "ey"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "ew"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "eh"));  
		contentPane.add(exitBtn);
	}

	void homeBtn() {
		JButton homeBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "home"));
		homeBtn.setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "ex"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "hy"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "ew"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "eh"));  	
		homeBtn.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		controller.visitHome();
	    	}
	    });
		contentPane.add(homeBtn);
	}
	
	public synchronized void refresh() {
		ArrayList<Message> messages = controller.messagesFromChat(chatID);
		chatComponents.addComponentsToPane(jPanel, messages, id);
		jPanel.revalidate();
		jPanel.repaint();
	}
	
}


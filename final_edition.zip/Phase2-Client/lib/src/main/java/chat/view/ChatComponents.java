package chat.view;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;

import shared.model.Message;
import shared.util.FileStuff;
import shared.util.extra.FileUtil;

import javax.imageio.ImageIO;

public class ChatComponents {
	
	private ChatRoomGUI chatRoomGUI;
	private static int size;
	private static List<JLabel> labels = new ArrayList<JLabel>();
	
	public ChatComponents(ChatRoomGUI gui) {
		this.chatRoomGUI = gui;
	}
	
	synchronized void addComponentsToPane(Container pane, ArrayList<Message> messages, String id) {    
		GridBagConstraints c = new GridBagConstraints(); 
		c.gridwidth = 3;
		size = messages.size();
		updateComponents(pane, messages, id, c);	
	}
	
	void updateComponents(Container pane, ArrayList<Message> messages, String id, GridBagConstraints c) {  
		JLabel label;
		Message message;
		
		for (int i = labels.size(); i < messages.size(); i++) {
			message = messages.get(i);
			
			if(message.getBase64() == "" || message.getBase64() == null) {
				
			label = new JLabel();
			label.setText(message.getText() +"                     "+ message.getTimeSent());
			label.setPreferredSize(label.getPreferredSize());
						
			} else {
				
				label = new JLabel();
				String text = messages.get(i).getText() +": "+ messages.get(i).getTimeSent();
				label.setText(text);
				String base64 = messages.get(i).getBase64();
				label.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						String ext = text.split(": ")[1];
						writeFile(base64, ext);
					}
				});
				label.setForeground(Color.blue);
				label.setPreferredSize(label.getPreferredSize());
				
			}	
			
			c.fill = GridBagConstraints.HORIZONTAL;  
			c.ipady = 30;      //make this component tall  
			c.weightx = 0.5;   
			c.gridx = 0;  
			c.gridy = i+3; 
			
			pane.add(label, c); 
			labels.add(label);
		}	
		size = messages.size();
	}

	private void writeFile(String base64, String extension) { 
		FileStuff.writeFile(base64, extension);
	}
	
}

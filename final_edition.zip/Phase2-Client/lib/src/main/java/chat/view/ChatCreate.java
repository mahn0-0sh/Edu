package chat.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import chat.ChatController;
import client.Client;
import constants.Constants;
import shared.util.Config;

import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;

public class ChatCreate extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JList list;
	private DefaultListModel model;
	private ChatController client = new ChatController();

	/**
	 * Create the dialog.
	 */
	private void initPane() {
		setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "x"), 
				new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "y"), 
				new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "w"), 
				new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "h"));
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
	}
	private void initScroll() {
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 171, 239);
		contentPanel.add(scrollPane);
		scrollPane.setViewportView(list);
	}
	private void listListener() {
		MouseListener mouseListener = new MouseAdapter() {
		    public void mouseClicked(MouseEvent e) {
		        if (e.getClickCount() == 2) {


		           String selectedItem = (String) list.getSelectedValue();
		           String[] s = selectedItem.split("-");
		           String msg = client.createNewChat(s[0]);
		           JOptionPane.showMessageDialog(null, msg);
		           

		         }
		    }
		};
		list.addMouseListener(mouseListener);
	}
	
	public ChatCreate() {
		initPane();		
		list = new JList();
		initScroll();
		listListener();
	}

}

package chat.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import chat.ChatController;
import constants.Constants;
import shared.util.Config;
import shared.util.FileStuff;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.List;
import java.awt.event.ActionEvent;

public class MultipleDialog extends JDialog {

	private ChatController controller = new ChatController();
	private final JPanel contentPanel = new JPanel();
	private JTextField textField;

	
	private void initPane() {
		setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "x"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "y"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "w"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "h")); 
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
	}
	
	public MultipleDialog(List<String> selectionList) {
		initPane();
		
		LinkedList<String> ids = new LinkedList<>();
		for(String string : selectionList) {
			ids.add(string.split("\\s+")[0]);
		}
		
		
		{
			textField = new JTextField();
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			JButton btnNewButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "send"));
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controller.sendMessageToMultiple(ids, textField.getText());
				}
			});
			contentPanel.add(btnNewButton);
		}
		{
			JButton btnNewButton_1 = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "sendFile"));
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String s[] = FileStuff.chooseFile();
					controller.sendFileToMultiple(ids, s[0], s[1]);
				}
			});
			contentPanel.add(btnNewButton_1);
		}
	}

}

package chat.view;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import constants.Constants;
import interfaces.Listener;
import shared.util.Config;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class ToolsBar extends JPanel implements ActionListener {

	private Listener listener;
	private JButton chatsBtn;
	private JButton allBtn;
	private JButton homeBtn;
	private JButton exitBtn;
	/**
	 * Create the panel.
	 */
	public ToolsBar() {
		setBorder(new LineBorder(Color.blue));
		
		chatsBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "exChats"));
		chatsBtn.addActionListener(this);
		add(chatsBtn);
		
		allBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "all"));
		allBtn.addActionListener(this);
		add(allBtn);
		
		homeBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "home"));
		homeBtn.addActionListener(this);
		add(homeBtn);
		
		exitBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "exit"));
		exitBtn.addActionListener(this);
		add(exitBtn);

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if((JButton)e.getSource() == chatsBtn) listener.listen("chats");
		if((JButton)e.getSource() == allBtn) listener.listen("all");
		if((JButton)e.getSource() == homeBtn) listener.listen("home");
		if((JButton)e.getSource() == exitBtn) listener.listen("exit");
	}
	
	public Listener getListener() {
		return listener;
	}
	public void setListener(Listener listener) {
		this.listener = listener;
	}

	
}

package chat.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import chat.ChatController;
import constants.Constants;
import shared.util.Config;
import shared.util.extra.FileUtil;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class OfflineDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private ChatController controller = new ChatController();

	

	private void initPane() {
		setBounds(100, 100, 450, 115);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
	}
	
	public OfflineDialog() {
		initPane();
		
		{
			JButton btnNewButton_1 = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "btnSendFile"));
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					JFileChooser fileChooser = new JFileChooser(".");
					int r = fileChooser.showOpenDialog(null);
					String path = "";
					String extension = "";
					if (r == JFileChooser.APPROVE_OPTION) {
						path = fileChooser.getSelectedFile().getAbsolutePath();
						
						if(path.endsWith(".png")) extension = ".png";			
						else if(path.endsWith(".jpg")) extension = ".jpg";
						else if(path.endsWith(".pdf")) extension = ".pdf"; 
						else if(path.endsWith(".mp3")) extension = ".mp3";
						else if(path.endsWith(".mkv")) extension = ".mkv";
						else if(path.endsWith(".mp4")) extension = ".mp4";
					}
					if(path != "") {
						String encode = FileUtil.encode(path);
						try {
							controller.sendFileAsMessage(-1, controller.getClientId(), "1", encode, extension);
						} catch (SQLException e1) {
							e1.printStackTrace();
						}	
					}
					
				}
			});
			contentPanel.add(btnNewButton_1);
		}
		{
			textField = new JTextField();
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			JButton btnNewButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "btnSendText"));
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						controller.sendMessage(-1, controller.getClientId(), "1", textField.getText());
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			contentPanel.add(btnNewButton);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				okButton.setActionCommand(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "okButton"));
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "cancelButton"));
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}

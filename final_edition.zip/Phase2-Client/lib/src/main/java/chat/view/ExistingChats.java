package chat.view;

import javax.swing.JPanel;

import chat.ChatController;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JList;

public class ExistingChats extends JPanel {

	private DefaultListModel<String> dListModel = new DefaultListModel<>();
	private JList<String> list;
	private ChatController controller = new ChatController();
	
	
	public ExistingChats() {
		setLayout(new BorderLayout(0, 0));
		initList();
	}
	
	private void initList() {
		list = new JList();
		list.setModel(dListModel);
		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 2) {
					String id = controller.getClientId();
					String other_id = list.getSelectedValue().split(":")[0];
					int chatId = controller.getChatId(id, other_id);
					controller.goToChatRoom(chatId, id, other_id);
				}				
			}
		});
		add(list, BorderLayout.CENTER);
	}

	public void setListModel(LinkedList<String> list) {
		if(list != null) {
			dListModel = new DefaultListModel<>();
			for(String string : list) {
				dListModel.addElement(string);
			}
			this.list.setModel(dListModel);
			repaint();
			revalidate();
		} else {
		    controller.visitHome();
		}		
	}

	public void refresh() {
		LinkedList<String> myLinkedList = controller.getMyCurrentChats();
		if(myLinkedList != null) setListModel(myLinkedList);
		else controller.visitHome();
	}

}

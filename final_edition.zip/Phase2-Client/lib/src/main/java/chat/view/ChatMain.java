package chat.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import chat.ChatController;
import client.ConnectionStatus;
import constants.Constants;
import interfaces.Listener;
import shared.util.Config;

import javax.swing.JScrollPane;

public class ChatMain extends JFrame {

	private ChatController controller = new ChatController();
	private JPanel contentPane;
	private ToolsBar toolsBar;
	private ExistingChats chats = new ExistingChats();
	private CreateChat createChat;
	private JScrollPane scrollPane;

	
	
	public ChatMain() {
		initPane();
		initToolBar();
		initScroll();
	}
	
	private void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "x"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "y"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "w"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "h")); 
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}

	private void initToolBar() {
		toolsBar = new ToolsBar();
		toolsBar.setListener(new Listener() {
			
			@Override
			public void listen(String string) {
				if(string.equals("chats")) showChatsPanel();	
				if(string.equals("all")) showCreatePanel();				
			}
		});
		getContentPane().add(toolsBar, BorderLayout.NORTH);
	}
	
	private void initScroll() {
		scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
	}
	
	private void showChatsPanel() {
		chats = new ExistingChats();
		LinkedList<String> myLinkedList = controller.getMyCurrentChats();
		
		if(myLinkedList != null) {
			chats.setListModel(myLinkedList);
			scrollPane.setViewportView(chats);		
		}
	}

	private void showCreatePanel() {
		createChat = new CreateChat();
		
		createChat.setListModel(controller.getMyFullList());
		scrollPane.setViewportView(createChat);
	}

	public void refresh() {
		try {
			chats.refresh();			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
 
}

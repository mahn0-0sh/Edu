package chat.view;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.LinkedList;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import chat.ChatController;
import client.ConnectionStatus;
import constants.Constants;
import shared.util.Config;

import javax.swing.BoxLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;

public class CreateChat extends JPanel {
	private DefaultListModel<String> dListModel = new DefaultListModel<>();
	private JList<String> list;
	private JTextField textField;
	private ChatController controller = new ChatController();
	private JScrollPane scrollPane;
	private JPanel ask_panel;
	private JPanel send_panel;
	private JButton toAllBtn;

	
	
	public CreateChat() {
		setLayout(new BorderLayout(0, 0));
		initScroll();
		initList();
		
		initAskPanel();
		initSendPanel();
	}
	
	
	
	
	private void initSendPanel() {
		send_panel = new JPanel();
		add(send_panel, BorderLayout.SOUTH);
		
		JButton sendBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "btnSendMul"));
		sendBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(ConnectionStatus.getStatus().isOnline()) {
				    MultipleDialog dialog = new MultipleDialog(list.getSelectedValuesList());
				    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				}
				
			}
		});
		send_panel.add(sendBtn);
		
		toAllBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "btnSendToAll"));
		toAllBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(ConnectionStatus.getStatus().isOnline()) {
				    MultipleDialog dialog = new MultipleDialog(controller.getMyFullList());
				    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				}
				
			}
		});
		send_panel.add(toAllBtn);
	}
	
	
	
	
	private void initAskPanel() {
		ask_panel = new JPanel();
		add(ask_panel, BorderLayout.EAST);
		
		JLabel lblID = new JLabel(new Config(Constants.LABEL_TEXT).getProperty(String.class, "lblID"));
		ask_panel.add(lblID);
		
		textField = new JTextField();
		ask_panel.add(textField);
		textField.setColumns(10);
		
		JButton askBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "btnAsk"));
		askBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String response = controller.askForChat(textField.getText());
				JOptionPane.showMessageDialog(null, response);
			}
		});
		ask_panel.add(askBtn);
	}
	
	
	
	private void initScroll() {
		scrollPane = new JScrollPane();
		add(scrollPane, BorderLayout.WEST);
	}
	
	
	
	private void createChat(String other_id) {
		
		if(ConnectionStatus.getStatus().isOnline()) {
			String response  = controller.createNewChat(other_id);
			JOptionPane.showMessageDialog(null, response);
		} else {
			OfflineDialog offlineDialog = new OfflineDialog();
			offlineDialog.setVisible(true);
		}
		
	}
	
	
	
	
	private void initList() {
		list = new JList();
		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 2) {
					String other_id = list.getSelectedValue().split("\\s+")[0];
					try {
						createChat(other_id);
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}				
			}
		});
		scrollPane.setViewportView(list);
	}
	
	
	
	
	void setListModel(LinkedList<String> list) {
		for(String string : list) {
			dListModel.addElement(string);
		}
		this.list.setModel(dListModel);
		repaint();
		revalidate();
	}

}

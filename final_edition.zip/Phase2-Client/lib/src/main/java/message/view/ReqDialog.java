package message.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import message.MsgController;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ReqDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private MsgController controller = new MsgController();

	

	/**
	 * Create the dialog.
	 */
	public ReqDialog(int id) {
		String info = controller.getReqInfo(id); // type, from, exp
		
		setBounds(100, 100, 450, 245);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		if(info != null) {
			String[] s = info.split("`");
			
			{
				JLabel typeLbl = new JLabel(s[0]);
				typeLbl.setBounds(69, 11, 80, 14);
				contentPanel.add(typeLbl);
			}
			
			{
				JLabel idLbl = new JLabel(s[1]);
				idLbl.setBounds(69, 36, 80, 14);
				contentPanel.add(idLbl);
			}
			
			{
				JLabel expLbl;
				try {
					expLbl = new JLabel(s[2]);
				} catch (Exception e) {
					expLbl = new JLabel();
				}
				expLbl.setBounds(69, 61, 275, 14);
				contentPanel.add(expLbl);
				
			}
			
			
		} else {
			controller.visitHome();
		}
		
		
		
		{
			JLabel lblNewLabel = new JLabel("Type:");
			lblNewLabel.setBounds(10, 11, 49, 14);
			contentPanel.add(lblNewLabel);
		}
		
		{
			JLabel lblFrom = new JLabel("From:");
			lblFrom.setBounds(10, 36, 49, 14);
			contentPanel.add(lblFrom);
		}
		
		{
			JLabel lblExp = new JLabel("Exp:");
			lblExp.setBounds(10, 61, 49, 14);
			contentPanel.add(lblExp);
		}
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			
			JButton btnNewButton_1 = new JButton("Accept");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controller.changeReqResponse(id, "ACCEPTED");
				}
			});
			buttonPane.add(btnNewButton_1);
			
			JButton btnNewButton = new JButton("Deny");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controller.changeReqResponse(id, "DENIED");
				}
			});
			buttonPane.add(btnNewButton);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
	}


}

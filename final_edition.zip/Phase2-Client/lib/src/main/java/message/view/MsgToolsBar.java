package message.view;

import javax.swing.JPanel;

import interfaces.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import shared.util.Config;
import constants.*;

public class MsgToolsBar extends JPanel implements ActionListener {

	private JButton ancBtn;
	private JButton reqBtn;
	private JButton respBtn;
	private JButton homeBtn;
	private Listener listener;
	/**
	 * Create the panel.
	 */
	public MsgToolsBar(String position) {
		
		if(!position.equals("Student")) {
		    reqBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "reqBtn"));
		    reqBtn.addActionListener(this);
		    add(reqBtn);
		} else {	
			reqBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "reqBtn"));
		    reqBtn.addActionListener(this);
		    add(reqBtn);
		    
			ancBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "ancBtn"));
			ancBtn.addActionListener(this);
			add(ancBtn);
			
		    respBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "respBtn"));
		    respBtn.addActionListener(this);
		    add(respBtn);
		}
		
		homeBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "home"));
		homeBtn.addActionListener(this);
		add(homeBtn);

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if((JButton) e.getSource() == ancBtn) listener.listen("anc");
		if((JButton) e.getSource() == reqBtn) listener.listen("req");
		if((JButton) e.getSource() == respBtn) listener.listen("resp");
		if((JButton) e.getSource() == homeBtn) listener.listen("home");
	}
	public Listener getListener() {
		return listener;
	}
	public void setListener(Listener listener) {
		this.listener = listener;
	}
	
	

}

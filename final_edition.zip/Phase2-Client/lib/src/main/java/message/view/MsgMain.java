package message.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import interfaces.Listener;
import message.MsgController;
import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MsgMain extends JFrame {

	private JPanel contentPane;
	private MsgToolsBar toolsBar;
	private JList list;
	private String position;
	private MsgController controller;
	private DefaultListModel<String> model = new DefaultListModel<>();
	private String mode = "";


	/**
	 * Create the frame.
	 */
	public MsgMain() {
		controller = new MsgController();
		position = controller.getPosition();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		list = new JList();
		
	//	if(mode.equals("anc") || mode.equals("req")) {
			list.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					if( e.getClickCount() == 2 ) {
						String string = (String) list.getSelectedValue();
						int id = Integer.parseInt(string.split("\\s+")[0]);
				//		if(mode.equals("anc")) showAnc(id);
						if(mode.equals("req")) showReq(id);
					}
				}
			});
	//	}		
		scrollPane.setViewportView(list);
		
		toolsBar = new MsgToolsBar(position);
		toolsBar.setListener(new Listener() {
			
			@Override
			public void listen(String string) {
				mode = string;
				if(string.equals("home"));
				else setModelStu();
			}
		});
		add(toolsBar, BorderLayout.NORTH);
	}
	
	
    private void showReq(int id) {
		controller.showReqDialog(id);
	}
	
	private void setModelStu() { 
		LinkedList<String> lists = new LinkedList<>();
		if(mode.equals("anc")) lists = controller.getAncList();
		else if(mode.equals("req")) lists = controller.getReqList();
		else if(mode.equals("resp")) lists = controller.getRespList();
		
		if(lists != null) {
			DefaultListModel<String> newModel = new DefaultListModel<>();
			for(String id : lists) newModel.addElement(id);
			list.setModel(newModel);
		} else {
			controller.visitHome();
		}	
	}


	public void refresh() {
		setModelStu();
	}

}

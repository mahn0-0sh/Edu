package message;

import java.util.LinkedList;

import client.Client;
import client.controller.Controller;
import client.network.ServerController;
import shared.response.Response;

public class MsgController extends Controller {
	static Client client;
	static ServerController serverController;
	
	

	@SuppressWarnings("unchecked")
	public LinkedList<String> getAncList() {
		Response response = serverController.getAncList(client.getId());
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}

	@SuppressWarnings("unchecked")
	public LinkedList<String> getReqList() {
		Response response = serverController.getReqList(client.getId());
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}

	@SuppressWarnings("unchecked")
	public LinkedList<String> getRespList() {
		Response response = serverController.getRespList(client.getId());
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}

	public String getAncText(int id) {
		Response response = serverController.getAncText(id);
		if(response != null) return (String) response.getData("text");
		return null;
	}

	public String getReqInfo(int id) {
		Response response = serverController.getReqInfo(id);
		if(response != null) return (String) response.getData("info");
		return null;
	}

	public static void setClient(Client client2, ServerController serverController2) {
		client = client2;
		serverController = serverController2;
	}

	public void showReqDialog(int id) {
		client.showReqDialog(id);
	}

	public void changeReqResponse(int id, String resp) {
		serverController.changeReqResponse(id, resp);
	}

}

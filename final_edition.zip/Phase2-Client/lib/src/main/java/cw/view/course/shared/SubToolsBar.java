package cw.view.course.shared;

import javax.swing.JPanel;

import interfaces.Listener;
import shared.util.Config;
import constants.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class SubToolsBar extends JPanel implements ActionListener {

	private Listener listener;
	private JButton addBtn;
	private JButton addMBtn;
	private JButton deleteBtn;
	private JButton homeBtn;
	/**
	 * Create the panel.
	 */
	public SubToolsBar(String position) {
		
		if(!position.equals("TA") && !position.equals("Student")) {
			addBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "addBtn"));
			addBtn.addActionListener(this);
			add(addBtn);
			
			addMBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "addMBtn"));
			addMBtn.addActionListener(this);
			add(addMBtn);
			
			deleteBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "deleteBtn"));
			deleteBtn.addActionListener(this);
			add(deleteBtn);
		}
		
		homeBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "home"));
		homeBtn.addActionListener(this);
		add(homeBtn);

	}
	
	
	public Listener getListener() {
		return listener;
	}
	public void setListener(Listener listener) {
		this.listener = listener;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if((JButton) e.getSource() == addBtn) listener.listen("add_text");
		if((JButton) e.getSource() == addMBtn) listener.listen("add_media");
		if((JButton) e.getSource() == deleteBtn) listener.listen("delete");
		if((JButton) e.getSource() == homeBtn) listener.listen("home");
	}
	
	

}

package cw.view.main;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import constants.Constants;
import cw.CWController;
import interfaces.Listener;
import shared.util.Config;

public class CWMainFrame extends JFrame {

	private CWController controller = new CWController();
	private JPanel contentPane;
	private JScrollPane scrollPane;
	private JPanel viewPanel;
	private MyCoursesPanel myCoursesPanel = new MyCoursesPanel();
	private ToolsBar toolsBar;
	private StuCal stuCal = new StuCal();
	private TeacherCal teacherCal = new TeacherCal();

	
	
	public CWMainFrame() {
		initPane();
		initToolbar();
		initScroll();
	}
	
	
	void showCourses() {
		myCoursesPanel = new MyCoursesPanel(controller.getMyCourses());
		scrollPane.setViewportView(myCoursesPanel);
		scrollPane.repaint();
	}
	
	void showCal() {
		String pos = controller.getPosition();
		if(pos.equals("Student")) {
			stuCal = new StuCal();
			scrollPane.setViewportView(stuCal);
		} else {
			teacherCal = new TeacherCal();
			scrollPane.setViewportView(teacherCal);
		}
		scrollPane.repaint();
	}
	
	private void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "x"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "y"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "w"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "h"));
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}
	
	private void initToolbar() {
		toolsBar = new ToolsBar();
		contentPane.add(toolsBar, BorderLayout.NORTH);
		toolsBar.setListener(new Listener() {
			
			@Override
			public void listen(String string) {
				if(string.equals("courses")) showCourses();
				if(string.equals("calendar")) showCal();
			}
		}); 
	}
	
	private void initScroll() {
		scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);		
	}
	
	public void refresh() {
		try {
			myCoursesPanel.refresh();
			stuCal.refresh();
			teacherCal.refresh();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}

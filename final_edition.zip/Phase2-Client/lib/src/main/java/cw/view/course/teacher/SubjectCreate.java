package cw.view.course.teacher;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import cw.CWController;
import shared.util.FileStuff;

import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.awt.event.ActionEvent;

public class SubjectCreate extends JDialog {

	private SubjectCreate pane;
	private final JPanel contentPanel = new JPanel();
	private CWController controller;
	private JPanel panel;
	int number = 0;
	private String name;
	private JLabel nameLbl;
	ArrayList<String> texts = new ArrayList<>();
	private ArrayList<String> encodes = new ArrayList<>();
	private ArrayList<String> exts = new ArrayList<>();
	private int subj_id;

	

	private void initPane() {
		setBounds(100, 100, 450, 120);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
	}
	/**
	 * Create the dialog.
	 */
	public SubjectCreate(String mini_id, String name, int subj_id) {
		
		this.name = name;
		this.subj_id = subj_id;
		
		controller = new CWController();
		initPane();
		
		
			nameLbl = new JLabel(name +"   "+ number);
			contentPanel.add(nameLbl, BorderLayout.NORTH);
		
		
		
			panel = new JPanel();
			contentPanel.add(panel, BorderLayout.SOUTH);
			
			updateButtons(subj_id);
			
			
		
		
		pane = this;
	}
	
	void update() {
		nameLbl.setText(name+"   "+number);
	    updateButtons(subj_id);
	}
	
	private void updateButtons(int subj_id) {
		panel.removeAll();
		if(number<5) {
			JButton btnAddNewMedia = new JButton("Add new media item");
			btnAddNewMedia.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String[] s = FileStuff.chooseFile();
					if(s[0] != null || s[0] != "") {
					//    controller.createMediaItem(subj_id, s[0], s[1]);
					//    number = controller.getItemNum(subj_id);
					    encodes.add(s[0]);
					    exts.add(s[1]);
					    number++;
					    update();
					}
				}
			});
			panel.add(btnAddNewMedia);
			
			
			JButton btnNewButton = new JButton("Add new text item");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					TextItemCreate itemCreate = new TextItemCreate(subj_id, pane);
					itemCreate.setVisible(true); 
				}
			});
			panel.add(btnNewButton);
			
			
			
			JButton saveBtn = new JButton("Save");
			saveBtn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					for(String text : texts) controller.createTextItem(subj_id, text);
					for(int i=0; i<exts.size(); i++) {
						controller.createMediaItem(subj_id, encodes.get(i), exts.get(i));
					}
					dispose();
				}
			});
			panel.add(saveBtn);
		}
	}
	
	
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
	
	

}

package cw.view.course.shared;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JPanel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.border.LineBorder;

import constants.Constants;
import cw.CWController;
import cw.view.course.teacher.ExcCreate;
import interfaces.Listener;
import shared.util.Config;

import java.awt.Color;
import javax.swing.JComboBox;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;

public class CourseExc extends JPanel {

	private DefaultListModel<String> model = new DefaultListModel<>();
	private CWController controller = new CWController();
	private String position;
	private Listener listener;
	private JButton createButton;
	private JList<String> list;
	private String mini_id;
	/**
	 * Create the panel.
	 */
	public CourseExc(String mini_id) {
		this.mini_id = mini_id;
		position = controller.positionType(mini_id);
		String[] boxString = {"Sort by time remaining", "Sort by time released"};

		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0};
		gridBagLayout.columnWeights = new double[]{1.0};
		setLayout(gridBagLayout);
		
		
		createButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "createBtnE"));
		createButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ExcCreate excCreate = new ExcCreate();
				excCreate.setMini_id(mini_id);
				excCreate.setVisible(true);
			}
		});
		
		if(!position.equals("TA") && !position.equals("Student")) {
			
		    GridBagConstraints c = new GridBagConstraints(); 
		    c.insets = new Insets(0, 0, 5, 0);
		    c.fill = GridBagConstraints.CENTER;
		    c.gridx = 0;
		    c.gridy = 0;
		    add(createButton, c);
		}
		
		
		JComboBox<String> comboBox = new JComboBox<String>(boxString);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int sel = comboBox.getSelectedIndex();
				String sortBy;
				if(sel == 0) sortBy = "remain";
				else sortBy = "release";
				setModel(controller.getCourseExcs(mini_id, sortBy));
			}
		});
		
		list = new JList<String>();
		list.setBorder(new LineBorder(new Color(0, 0, 0)));
		refresh();
		
		
		
		MouseListener mouseListener = new MouseAdapter() {
		      public void mouseClicked(MouseEvent mouseEvent) {
		        if (mouseEvent.getClickCount() == 2) {
		        	listener.listen(list.getSelectedValue().split(" -")[0]);
		        }
		      }
		    };
		    list.addMouseListener(mouseListener);
		
		    
		    
		GridBagConstraints c1 = new GridBagConstraints(); 
		c1.fill = GridBagConstraints.BOTH;
		c1.gridx = 0;
		c1.gridy = 3;
		add(list, c1);
		
		GridBagConstraints c2 = new GridBagConstraints(); 
		c2.fill = GridBagConstraints.CENTER;
		c2.gridx = 0;
		c2.gridy = 1;
		add(comboBox, c2); 
		
	}
	
	
	public CourseExc() {
		// TODO Auto-generated constructor stub
	}


	public void setModel(LinkedList<String> excs) {
		DefaultListModel<String> newModel = new DefaultListModel<>();
		for(String string : excs) {
			newModel.addElement(string);
		}
		list.setModel(newModel);
	}
	
	public void refresh() {
		LinkedList<String> subjects = controller.getCourseExcs(mini_id);
		if(subjects != null) setModel(subjects);
		else controller.visitHome();
	}


	public Listener getListener() {
		return listener;
	}


	public void setListener(Listener listener) {
		this.listener = listener;
	}
	
	
	
	
	

}

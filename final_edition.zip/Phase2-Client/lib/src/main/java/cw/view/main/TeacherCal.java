package cw.view.main;

import java.awt.BorderLayout;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import cw.CWController;

public class TeacherCal extends JPanel {

	private CWController controller = new CWController();
	private JList list;
	
	
	public TeacherCal() {
        setLayout(new BorderLayout(0, 0));
		JScrollPane scrollPane = new JScrollPane();
		add(scrollPane, BorderLayout.CENTER);
		
		list = new JList();
		scrollPane.setViewportView(list);
		refresh();
	}
	
	public void refresh() {
		DefaultListModel<String> model = new DefaultListModel<>();
		try {
			LinkedList<String> stuCal = controller.getTeacherCal();
			if(stuCal != null) {
				for(String string : stuCal) model.addElement(string);
				list.setModel(model);
			}
			else controller.visitHome();
		} catch (Exception e) {
			// TODO: handle exception
		}		
	}

}

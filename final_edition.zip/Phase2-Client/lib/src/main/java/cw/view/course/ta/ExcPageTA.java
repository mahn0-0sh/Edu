package cw.view.course.ta;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.LinkedList;

import javax.swing.JLabel;
import javax.swing.JPanel;

import cw.CWController;
import cw.view.course.teacher.ExcScoring;
import shared.model.Message;

public class ExcPageTA extends JPanel {

	private LinkedList<String> sentList;
	private CWController controller;
	private HashMap<String, String> hashIds = new HashMap<>();
	/**
	 * Create the panel.
	 */
	public ExcPageTA(int id) { // exc id
		controller = new CWController();
		sentList = controller.getExcSentList(id);
		
		for(int i = 0; i < sentList.size(); i++) {
			hashIds.put(sentList.get(i), "***");
		}
		
		setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints(); 
		c.gridwidth = 3;
		
		JLabel label;
		int i=0;
		for(String idString : hashIds.keySet()) {
			label = new JLabel();
			String owner_id = idString;
			label.setText(hashIds.get(idString));
			label.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					ExcScoring scoring = new ExcScoring(id, owner_id);
					scoring.setVisible(true);
				}
			});
			label.setPreferredSize(label.getPreferredSize());
			
			c.fill = GridBagConstraints.HORIZONTAL;  
			c.ipady = 40;      //make this component tall  
			c.weightx = 0.5;   
			c.gridx = 0;  
			c.gridy = i+3; 
			i++;
			
			add(label, c);
		}
	}
	public ExcPageTA() {
		// TODO Auto-generated constructor stub
	}
	
	public void refresh() {
		// TODO Auto-generated method stub
		
	}	
	
}

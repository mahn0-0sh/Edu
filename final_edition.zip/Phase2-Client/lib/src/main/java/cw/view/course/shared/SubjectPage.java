package cw.view.course.shared;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import cw.CWController;
import cw.view.course.teacher.TextItemCreate;
import interfaces.Listener;
import shared.util.FileStuff;

public class SubjectPage extends JFrame {

	private JPanel contentPane;
	private SubToolsBar toolsBar;
	private String position;
	private SubPanel panel = new SubPanel();
	private CWController controller;


	/**
	 * Create the frame.
	 */
	public SubjectPage(int subj_id, String position) {
		this.position = position;
		controller = new CWController();
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		toolsBar = new SubToolsBar(position);
		toolsBar.setListener(new Listener() {
			
			@Override
			public void listen(String string) {
				if(string.equals("add_text")) {
					TextItemCreate itemCreate = new TextItemCreate(subj_id);
					itemCreate.setVisible(true);
				}
				
				
				if(string.equals("add_media")) {
					String[] s = FileStuff.chooseFile();
					if(s[0] != null || s[0] != "") {
				        controller.createMediaItem(subj_id, s[0], s[1]);
					}
				}
				
				
				if(string.equals("delete")) {
					controller.deleteSubject(subj_id);
					controller.visitHome();
				}
				
				
				if(string.equals("home"));
			}
		});
		getContentPane().add(toolsBar, BorderLayout.NORTH);

		panel = new SubPanel(subj_id, position);
		JScrollPane scrollPane = new JScrollPane(panel);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
	}


	public SubjectPage() {
		// TODO Auto-generated constructor stub
	}


	public void refresh() {
		try {
			panel.refresh();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}


}

package cw.view.course.shared;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import constants.Constants;
import cw.CWController;
import cw.view.course.ta.TextItemEdit;
import shared.util.Config;
import shared.util.FileStuff;

public class SubPanel extends JPanel {
	
	private CWController controller;
	private LinkedList<String> itemsInfo;
	private String position;
	private LinkedList<JLabel> labels = new LinkedList<>();
	private GridBagConstraints c = new GridBagConstraints();
	private int subID;

	/**
	 * Create the panel.
	 */
	public SubPanel(int subID, String position) {
		this.position = position;
		this.subID = subID;
		
		setBorder(new LineBorder(Color.red));
		setLayout(new GridBagLayout());
		controller = new CWController();
		itemsInfo = controller.getSubItemsInfo(subID);
		refresh();
	}
	
	
	public SubPanel() {
		// TODO Auto-generated constructor stub
	}


	private JButton getChangeBtn(String type, String item_idString) {
		int item_id = Integer.parseInt(item_idString);
		
		JButton changeBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "editBtn"));
		changeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(type.equals("Text")) {
					String text = controller.getItemText(item_idString);
					TextItemEdit itemEdit = new TextItemEdit(item_id, text);
					itemEdit.setVisible(true);
				}
				else {
					String[] s = FileStuff.chooseFile();
					if(s[0] != null || s[0] != "") {
					    controller.editMediaItem(item_id, s[0], s[1]);
					}
				}
			}
		});
		return changeBtn;
	}
	
	private JButton getDeleteBtn(String item_idString) {
		int item_id = Integer.parseInt(item_idString);
		
		JButton deleteBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "deleteItemBtn"));
		deleteBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.deleteItem(item_id);
			}
		});
		return deleteBtn;
	}
	
	private void setTextMouseL(JLabel label, String text) {
		MouseListener mouseListener1 = new MouseAdapter() {
		      public void mouseClicked(MouseEvent mouseEvent) {
		        showTextDialog(text);
		      }
		    };
	    label.addMouseListener(mouseListener1);	
	}
	
	private void setFileMouseL(JLabel label, String base64, String ext) {
		MouseListener mouseListener1 = new MouseAdapter() {
		      public void mouseClicked(MouseEvent mouseEvent) {
		        FileStuff.writeFile(base64, ext); // TODO extension
		      }
		    };
	    label.addMouseListener(mouseListener1);
	}
	
	
	
	private void showTextDialog(String text) {
		TextDialog dialog = new TextDialog(text);
		dialog.setVisible(true);
	}


	public void refresh() {
		itemsInfo = controller.getSubItemsInfo(subID);
        for(int i=labels.size(); i<itemsInfo.size(); i++) {
			String string = itemsInfo.get(i);
			
			String[] s = string.split("/"); // id type
			JLabel label = new JLabel(s[0]);
			label.setFont(new Font("Tahoma", Font.PLAIN, 14));
			
			if(s[1].equals("Text")) {
				label.setForeground(Color.green);
				String text = controller.getItemText(s[0]);
				setTextMouseL(label, text);
			} else {
				label.setForeground(Color.blue);
				String ext = controller.getItemText(s[0]);
				String base64 = controller.getItemBase64(s[0]);
				setFileMouseL(label, base64, ext);					
			}
			
			c.ipady = 7;      //make this component tall  
			c.weightx = 0.5; 
			c.gridx = 0;  
			c.gridy = i+3;
			add(label, c);
			labels.add(label);
			
			if(!position.equals("Student")) {
				c.ipady = 7;      
				c.weightx = 0.5;
				c.gridx = 1;  
				c.gridy = i+3;
				add(getChangeBtn(s[1], s[0]), c);
				
				if(!position.equals("TA")) {
					c.ipady = 7;       
					c.weightx = 0.5;
					c.gridx = 2;  
					c.gridy = i+3;
					add(getDeleteBtn(s[0]), c);
				}
			}
		}
	}
	
	
	

}

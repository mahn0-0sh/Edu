package cw.view.course.teacher;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import cw.CWController;
import shared.util.FileStuff;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ExcScoring extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private CWController controller = new CWController();
	private String type;
	private String[] media;


	public ExcScoring(int exc_id, String id) {
		type = controller.getExcStatus(exc_id).split(" ` ")[4];
		media = controller.getExcStudentMedia(id, exc_id);
		
		setBounds(100, 100, 450, 320);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		
		
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(20, 45, 189, 194);
			contentPanel.add(scrollPane);
			
			JTextArea textArea = new JTextArea();
			scrollPane.setViewportView(textArea);
			textArea.setEditable(false);
		
		
		
			JButton btnNewButton = new JButton("View answer");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(type.equals("Text")) textArea.setText(media[0]);
					else FileStuff.writeFile(media[1], media[0]);
				}
			});
			btnNewButton.setBounds(20, 11, 95, 23);
			contentPanel.add(btnNewButton);
		
		{
			textField = new JTextField();
			textField.setBounds(231, 12, 96, 20);
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			JButton btnNewButton_1 = new JButton("Grade");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					double doub = 0.0;
					try {
						doub = Double.parseDouble(textField.getText());
						controller.gradeStudentExc(id, exc_id, doub);
					} catch (Exception e2) {
						JOptionPane.showMessageDialog(null, "Invalid score.");
					}
				}
			});
			btnNewButton_1.setBounds(337, 11, 89, 23);
			contentPanel.add(btnNewButton_1);
		}
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
	}

}

package cw.view.course.teacher;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import cw.CWController;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private CWController controller = new CWController();

	

	/**
	 * Create the dialog.
	 */
	public AddDialog(String courseID) {
		setBounds(100, 100, 450, 185);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("ID:");
			lblNewLabel.setBounds(10, 11, 49, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("Type:");
			lblNewLabel_1.setBounds(10, 55, 49, 14);
			contentPanel.add(lblNewLabel_1);
		}
		
		String[] strings = {"TA", "Student"};
		JComboBox comboBox = new JComboBox(strings);
		comboBox.setBounds(69, 51, 30, 22);
		contentPanel.add(comboBox);
		
		textField = new JTextField();
		textField.setBounds(69, 8, 96, 20);
		contentPanel.add(textField);
		textField.setColumns(10);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String type = (String) comboBox.getSelectedItem();
						String id = textField.getText();
						String respose = controller.addToCourse(courseID, type, id);
						JOptionPane.showMessageDialog(null, respose);
						if(respose.equals("Ok")) { //TODO check
							controller.sendAddToCourseAnc(courseID, type, id);
							System.out.println("done?");
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}

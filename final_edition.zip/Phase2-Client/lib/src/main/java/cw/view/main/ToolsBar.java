package cw.view.main;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import constants.Constants;
import interfaces.Listener;
import shared.util.Config;

public class ToolsBar extends JPanel implements ActionListener {

	private JButton coursesBtn;
	private JButton calendarBtn;
	private JButton homeBtn;
	private JButton exitBtn;
	private Listener listener;
	/**
	 * Create the panel.
	 */
	public ToolsBar() {
		setBorder(new LineBorder(Color.blue));
		
		coursesBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "coursesBtn"));
		coursesBtn.addActionListener(this);
		add(coursesBtn);
		
		calendarBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "cldBtn"));
		calendarBtn.addActionListener(this);
		add(calendarBtn);
		
		homeBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "home"));
		homeBtn.addActionListener(this);
		add(homeBtn);
		
		exitBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "exit"));
		exitBtn.addActionListener(this);
		add(exitBtn);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if((JButton)e.getSource() == coursesBtn) listener.listen("courses");
		if((JButton)e.getSource() == calendarBtn) listener.listen("calendar");
		if((JButton)e.getSource() == homeBtn) listener.listen("home");
		if((JButton)e.getSource() == exitBtn) listener.listen("exit");
	}
	
	
	public Listener getListener() {
		return listener;
	}
	public void setListener(Listener listener) {
		this.listener = listener;
	}

	
}

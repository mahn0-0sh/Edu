package cw.view.course.teacher;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;

import javax.swing.JLabel;
import javax.swing.JPanel;

import cw.CWController;
import shared.model.Message;

public class ExcPageTeacher extends JPanel {

	private LinkedList<String> sentList;
	private CWController controller;
	private LinkedList<JLabel> labels = new LinkedList<>();
	private GridBagConstraints c = new GridBagConstraints(); 
	private int id;
	/**
	 * Create the panel.
	 */
	public ExcPageTeacher(int id) { // exc id
		this.id = id;
		controller = new CWController();
		sentList = controller.getExcSentList(id);
		
		setLayout(new GridBagLayout());
		c.gridwidth = 3;
		refresh();
	}
	
	public ExcPageTeacher() {
		// TODO Auto-generated constructor stub
	}

	public void refresh() {
		sentList = controller.getExcSentList(id);
		if(sentList != null) {
			for (int i = labels.size(); i < sentList.size(); i++) {
				JLabel label = new JLabel();
				String owner_id = sentList.get(i);
				label.setText(owner_id);
				label.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						ExcScoring scoring = new ExcScoring(id, owner_id);
						scoring.setVisible(true);
					}
				});
				label.setPreferredSize(label.getPreferredSize());
				
				c.fill = GridBagConstraints.HORIZONTAL;  
				c.ipady = 40;      //make this component tall  
				c.weightx = 0.5;   
				c.gridx = 0;  
				c.gridy = i+3; 
				
				add(label, c); 
				labels.add(label);
			}
		} else {
			controller.visitHome();
		}
	}

}

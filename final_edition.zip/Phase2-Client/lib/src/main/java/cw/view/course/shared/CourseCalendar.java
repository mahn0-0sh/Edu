package cw.view.course.shared;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import cw.CWController;

import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CourseCalendar extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private CWController controller = new CWController();
	private DefaultListModel<String> model = new DefaultListModel<>();
	private JList list;
	private String course_id;

	

	/**
	 * Create the dialog.
	 */
	public CourseCalendar(String course_id) {
		this.course_id = course_id;
		
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JScrollPane scrollPane = new JScrollPane();
			contentPanel.add(scrollPane, BorderLayout.CENTER);
			{
				
				list = new JList();
				scrollPane.setViewportView(list);
				refresh();
				
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
	}

	public CourseCalendar() {
		// TODO Auto-generated constructor stub
	}

	public void refresh() {
        LinkedList<String> courseCal = controller.getCourseCal(course_id);
		model = new DefaultListModel<>();
		if(courseCal != null) {
			for(String string : courseCal) {
				model.addElement(string);
			}
			list.setModel(model);
		} else {
			controller.visitHome();
		}
	}



}

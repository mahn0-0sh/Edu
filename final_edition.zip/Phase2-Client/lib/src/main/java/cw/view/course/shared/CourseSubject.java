package cw.view.course.shared;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import constants.Constants;
import cw.CWController;
import cw.view.course.teacher.ExcCreate;
import cw.view.course.teacher.SubjectCreate;
import interfaces.Listener;
import shared.util.Config;

public class CourseSubject extends JPanel {
	
	private DefaultListModel<String> model = new DefaultListModel<>();
	private CWController controller = new CWController();
	private String position;
	private Listener listener;
	private JButton createButton;
	private JList<String> list;
	private SubjectCreate subjectCreate;
	private String mini_id;

	/**
	 * Create the panel.
	 */
	
	public CourseSubject(String mini_id) {
		position = controller.getPosition();
		this.mini_id = mini_id;

		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0};
		gridBagLayout.columnWeights = new double[]{1.0};
		setLayout(gridBagLayout);
		
		addBtn(mini_id);
        
        
		list = new JList<String>();
		list.setBorder(new LineBorder(new Color(0, 0, 0)));
		setModel(controller.getCourseSubjects(mini_id));

		
		
		MouseListener mouseListener = new MouseAdapter() {
		      public void mouseClicked(MouseEvent mouseEvent) {
		        if (mouseEvent.getClickCount() == 2) {
		        	listener.listen(list.getSelectedValue().split(" -")[0]);
		        }
		      }
		    };
		    list.addMouseListener(mouseListener);
		
		GridBagConstraints c1 = new GridBagConstraints(); 
		c1.fill = GridBagConstraints.BOTH;
		c1.gridx = 0;
		c1.gridy = 3;
		add(list, c1);
		
		addComboBox();
	}
	
	
	
	public CourseSubject() {
		// TODO Auto-generated constructor stub
	}



	private void addComboBox() {
		String[] boxString = {"Sort by time remaining", "Sort by time released"};
		JComboBox<String> comboBox = new JComboBox<String>(boxString);
		GridBagConstraints c2 = new GridBagConstraints(); 
		c2.fill = GridBagConstraints.CENTER;
		c2.gridx = 0;
		c2.gridy = 1;
		add(comboBox, c2); 
	}
	
	
	
	private void addBtn(String mini_id) {
		createButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "createBtnS"));
		createButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = JOptionPane.showInputDialog("Name your new subject.");
				int subj_id = controller.createNewSubject(mini_id, name);
				subjectCreate = new SubjectCreate(mini_id, name, subj_id);
				subjectCreate.setVisible(true);
			}
		});
		
		if(position.equals("Teacher") || position.equals("Deputy") || position.equals("Manager")) {
			
		    GridBagConstraints c = new GridBagConstraints(); 
		    c.insets = new Insets(0, 0, 5, 0);
		    c.fill = GridBagConstraints.CENTER;
		    c.gridx = 0;
		    c.gridy = 0;
		    add(createButton, c);
		}
	}
	
	public void setModel(LinkedList<String> subj) {
		model = new DefaultListModel<>();
		for(String string : subj) {
			model.addElement(string);
		}
		list.setModel(model);
	}
	
	

	public Listener getListener() {
		return listener;
	}

	public void setListener(Listener listener) {
		this.listener = listener;
	}
	
	
	public void refresh() {
		LinkedList<String> subjects = controller.getCourseSubjects(mini_id);
		if(subjects != null) setModel(subjects);
		else controller.visitHome();
	}

}

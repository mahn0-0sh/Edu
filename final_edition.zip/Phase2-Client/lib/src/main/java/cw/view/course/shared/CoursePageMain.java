package cw.view.course.shared;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import constants.Constants;
import cw.CWController;
import cw.view.course.student.ExcPageStu;
import cw.view.course.ta.ExcPageTA;
import cw.view.course.teacher.AddDialog;
import cw.view.course.teacher.ExcCreate;
import cw.view.course.teacher.ExcPageTeacher;
import interfaces.Listener;
import shared.util.Config;

import javax.swing.JScrollPane;
import javax.swing.JButton;

public class CoursePageMain extends JFrame {
	
	Logger logger = LogManager.getLogger(CoursePageMain.class);

	private CWController controller;
	private String courseID;
	private CourseToolsBar toolsBar;
	private JPanel contentPane;
	private JScrollPane scrollPane;
	private CourseCalendar courseCalendar = new CourseCalendar();
	private CourseExc courseExc = new CourseExc();
	private CourseSubject courseSubject = new CourseSubject();
	private ExcPageStu excPageStu = new ExcPageStu();
	private ExcPageTeacher excPageTeacher = new ExcPageTeacher();
	private ExcPageTA excPageTA = new ExcPageTA();
	private SubjectPage sPage = new SubjectPage();
	private String position;
	private AddDialog dialog;

	

	public CoursePageMain(String courseID) {
		this.courseID = courseID;
		initPanles();
		controller = new CWController();
		position = controller.getPosition();
		
		if(position.equals("Student")) {
			position = controller.positionType(courseID);
		}
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "x"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "y"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "w"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "h"));
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		toolsBar = new CourseToolsBar(position);
		toolsBar.setListener(new Listener() {
			
			@Override
			public void listen(String string) {
				if(string.equals("excersise")) showCourseExc();
				if(string.equals("subject")) showCourseSubj();
				if(string.equals("add")) showAddPanel();
				if(string.equals("calendar")) showCalPanel();
				if(string.equals("main")) controller.visitHome();
			}
		});
		getContentPane().add(toolsBar, BorderLayout.NORTH);
		
		scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
	}

	private void initPanles() {
		courseExc = new CourseExc(courseID);
		courseSubject = new CourseSubject(courseID);
		courseCalendar = new CourseCalendar(courseID);
	}
	
	private void showCourseExc() {
		courseExc.setListener(new Listener() {
			
			@Override
			public void listen(String excID) {
				int id = Integer.parseInt(excID);
				if(position.equals("Student")) {
					excPageStu = new ExcPageStu(id);
					rebuildScroll(excPageStu);
				} else if(position.equals("TA")) {
					excPageTA = new ExcPageTA(id);
					rebuildScroll(excPageTA);
				} else {
					excPageTeacher = new ExcPageTeacher(id);
					rebuildScroll(excPageTeacher);
				}
			}
		});
		rebuildScroll(courseExc);
	}
	
	
	private void showCourseSubj() {
		courseSubject.setListener(new Listener() {
			
			@Override
			public void listen(String subjID) {
				int id = Integer.parseInt(subjID);
				sPage = new SubjectPage(id, position);
				sPage.setVisible(true);
			}
		});
		rebuildScroll(courseSubject);
	}
	
	
	private void showAddPanel() {
		dialog = new AddDialog(courseID);
		dialog.setVisible(true);
	}
	
	private void showCalPanel() {
		courseCalendar.setVisible(true);
	}
	
	
	
	void rebuildScroll(JPanel panel) {
		scrollPane.setViewportView(panel);
		scrollPane.repaint();
		scrollPane.revalidate();
	}

	public String getCourseID() {
		return courseID;
	}

	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
	
	public void refresh() {
		try {
			courseCalendar.refresh();
			courseExc.refresh();
			courseSubject.refresh();
			excPageStu.refresh();
			excPageTeacher.refresh();
			excPageTA.refresh();
			sPage.refresh();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	

}

package cw.view.course.teacher;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import cw.CWController;
import shared.util.extra.FileUtil;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;

public class ExcCreate extends JDialog {
	
	//Logger logger = LogManager.getLogger(ExcCreate.class);
	Logger logger = LogManager.getLogger(ExcCreate.class);

	private final JPanel contentPanel = new JPanel();
	private JTextField nameField;
	private JTextField expField;
	private JTextField openField;
	private JTextField closeField;
	private String mini_id;
	private CWController controller;
	private String encode;
	private JTextField mohlatField;

	

	/**
	 * Create the dialog.
	 */
	public ExcCreate() {
		controller = new CWController();
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Name:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel.setBounds(10, 11, 49, 14);
		contentPanel.add(lblNewLabel);
		
		nameField = new JTextField();
		nameField.setBounds(69, 8, 96, 20);
		contentPanel.add(nameField);
		nameField.setColumns(10);
		
		expField = new JTextField();
		expField.setColumns(10);
		expField.setBounds(69, 36, 96, 20);
		contentPanel.add(expField);
		
		JLabel lblExp = new JLabel("Exp:");
		lblExp.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblExp.setBounds(10, 39, 49, 14);
		contentPanel.add(lblExp);
		
		openField = new JTextField();
		openField.setColumns(10);
		openField.setBounds(69, 67, 96, 20);
		contentPanel.add(openField);
		
		JLabel lblOpenAt = new JLabel("Open at:");
		lblOpenAt.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblOpenAt.setBounds(10, 70, 49, 14);
		contentPanel.add(lblOpenAt);
		
		closeField = new JTextField();
		closeField.setColumns(10);
		closeField.setBounds(69, 98, 96, 20);
		contentPanel.add(closeField);
		
		JLabel lblCloseAt = new JLabel("Close at:");
		lblCloseAt.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblCloseAt.setBounds(10, 101, 49, 14);
		contentPanel.add(lblCloseAt);
		
		JLabel lblType = new JLabel("Type:");
		lblType.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblType.setBounds(10, 164, 49, 14);
		contentPanel.add(lblType);
		
		JButton attachBtn = new JButton("Attach pdf file");
		attachBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFileChooser fileChooser = new JFileChooser(".");
				fileChooser.setAcceptAllFileFilterUsed(false);
		        FileNameExtensionFilter filter = new FileNameExtensionFilter("PDF files", "pdf");
				fileChooser.setFileFilter(filter);
				int r = fileChooser.showOpenDialog(null);
				String path = "";
				
				if (r == JFileChooser.APPROVE_OPTION) {
					path = fileChooser.getSelectedFile().getAbsolutePath();
					logger.info("file chooser opened.");
				}
				if(path != "" && path != null) {
				    encode = FileUtil.encode(path);
				    JOptionPane.showMessageDialog(null, "File attached");
				    logger.info("file chose.");
				    System.out.println(path);
				}
				
			}
		});
		attachBtn.setBounds(10, 196, 155, 23);
		contentPanel.add(attachBtn);
		
		
		String[] options = {"Text", "Media", "Both"};
		JComboBox comboBox = new JComboBox(options);
		comboBox.setBounds(69, 160, 96, 22);
		contentPanel.add(comboBox);
		
		mohlatField = new JTextField();
		mohlatField.setColumns(10);
		mohlatField.setBounds(69, 129, 96, 20);
		contentPanel.add(mohlatField);
		
		JLabel lblMohlat = new JLabel("Mohlat:");
		lblMohlat.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblMohlat.setBounds(10, 132, 49, 14);
		contentPanel.add(lblMohlat);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						logger.info("button pressed.");
						
						
						Date open = null; 
						Date close = null; 
						try {
							open = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(openField.getText());
							close = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(closeField.getText());
							
							controller.createExc(mini_id, nameField.getText(), expField.getText(), openField.getText(), 
									closeField.getText(), mohlatField.getText(), options[comboBox.getSelectedIndex()], encode); 
							dispose(); 
						} catch (ParseException e1) {
							JOptionPane.showMessageDialog(null, "Please enter valid times.");
						}
						
						
					//	writeFile(encode);
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		
		
	}
	
	
	private void writeFile(String base64) { 
		byte[] decoded = FileUtil.decode(base64);
		System.out.println(decoded);
		System.out.println(base64);
		JFileChooser fileChooser = new JFileChooser();

		System.out.println("File chooser.");
		
		if(fileChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			
			try {
				FileOutputStream fos = new FileOutputStream(file+".pdf");
				fos.write(decoded);
				fos.flush();
				fos.close();
				System.out.println("File saved!");
			} catch (Exception e) {
				System.out.println("Failed to save file.");
			}
		}
	}
		
		
		

	public String getMini_id() {
		return mini_id;
	}

	public void setMini_id(String mini_id) {
		this.mini_id = mini_id;
	}
}

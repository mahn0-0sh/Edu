package cw.view.main;

import javax.swing.JPanel;

import cw.CWController;
import java.awt.BorderLayout;
import java.util.LinkedList;

import javax.swing.JScrollPane;
import javax.swing.DefaultListModel;
import javax.swing.JList;

public class StuCal extends JPanel {

	private CWController controller = new CWController();
	private JList<String> list;
	/**
	 * Create the panel.
	 */
	@SuppressWarnings("unchecked")
	public StuCal() {
		setLayout(new BorderLayout(0, 0));
		JScrollPane scrollPane = new JScrollPane();
		add(scrollPane, BorderLayout.CENTER);
		
		list = new JList<String>();
		scrollPane.setViewportView(list);
		refresh();
	}

	public void refresh() {
		DefaultListModel<String> model = new DefaultListModel<>();
		try {
			LinkedList<String> stuCal = controller.getStuCal();
			if(stuCal != null) {
				for(String string : stuCal) model.addElement(string);
				list.setModel(model);
			}
			else controller.visitHome();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}

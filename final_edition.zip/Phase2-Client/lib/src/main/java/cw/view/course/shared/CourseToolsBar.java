package cw.view.course.shared;

import javax.swing.JPanel;

import constants.Constants;
import interfaces.Listener;
import shared.util.Config;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class CourseToolsBar extends JPanel implements ActionListener {

	private JButton cldBtn;
	private JButton excBtn;
	private JButton sbjBtn;
	private JButton exmBtn;
	private JButton mainBtn;
	private Listener listener;
	private JButton addBtn;
	/**
	 * Create the panel.
	 */
	public CourseToolsBar(String position) {
		
		cldBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "cldBtn"));
		cldBtn.addActionListener(this);
		add(cldBtn);
		
		if(!position.equals("Student") && !position.equals("TA")) {
			addBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "addBtn"));
			addBtn.addActionListener(this);
			add(addBtn);
		}
		
		
		excBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "excBtn"));
		excBtn.addActionListener(this);
		add(excBtn);
		
		sbjBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "sbjBtn"));
		sbjBtn.addActionListener(this);
		add(sbjBtn);
		
		exmBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "exmBtn"));
		exmBtn.addActionListener(this);
		add(exmBtn);
		
		mainBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "home"));
		mainBtn.addActionListener(this);
		add(mainBtn);

	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if((JButton)e.getSource() == cldBtn) listener.listen("calendar");		
		if((JButton)e.getSource() == excBtn) listener.listen("excersise");
		if((JButton)e.getSource() == sbjBtn) listener.listen("subject");
		if((JButton)e.getSource() == exmBtn) listener.listen("exam");
		if((JButton)e.getSource() == addBtn) listener.listen("add");
		if((JButton)e.getSource() == mainBtn) listener.listen("main");
	}
	
	
	public Listener getListener() {
		return listener;
	}
	public void setListener(Listener listener) {
		this.listener = listener;
	}
	
	

}

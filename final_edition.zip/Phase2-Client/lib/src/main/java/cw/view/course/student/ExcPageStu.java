package cw.view.course.student;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import constants.Constants;
import cw.CWController;
import shared.util.Config;
import shared.util.FileStuff;
import shared.util.extra.FileUtil;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;

public class ExcPageStu extends JPanel {

	private String type;
	private String pdf;
	private String status;
	private CWController controller;
	private int id;
	private JLabel statusLbl = new JLabel();
	private JLabel scoreLbl = new JLabel();
	/**
	 * Create the panel.
	 */
	public ExcPageStu(int id) {
		this.id = id;
		controller = new CWController();
		status = controller.getExcStatus(id); // name exp op-cl type mohlat
		String[] s = status.split(" ` ");
		pdf = controller.getPDF(id);
		
		setLayout(null);
		setPreferredSize(new Dimension(400, 300));
		
		JLabel lblName = new JLabel(s[0]);
		lblName.setBounds(10, 11, 80, 14);
		add(lblName);
		
		JLabel lblExp = new JLabel(s[1]);
		lblExp.setBounds(10, 36, 80, 14);
		add(lblExp);
		
		JLabel lblTime = new JLabel(s[2]+" - "+s[3]);
		lblTime.setBounds(10, 61, 130, 14);
		add(lblTime);
		
		type = s[4];
		JLabel lblType = new JLabel(s[4]);
		lblType.setBounds(10, 86, 49, 14);
		add(lblType);
		
		JLabel lblMohlat = new JLabel(s[5]);
		lblMohlat.setForeground(Color.PINK);
		lblMohlat.setBounds(10, 111, 49, 14);
		add(lblMohlat);
		
		
		
		JLabel lblNewLabel = new JLabel(new Config(Constants.LABEL_TEXT).getProperty(String.class, "lblScore"));
		lblNewLabel.setBounds(233, 11, 49, 14);
		add(lblNewLabel);
		
		scoreLbl = new JLabel();
		scoreLbl.setText(controller.getExcScore(id));
		scoreLbl.setBounds(292, 11, 75, 14);
		add(scoreLbl);
		
		statusLbl = new JLabel();
		statusLbl.setText(controller.getExcDeliverStatus(id));
		statusLbl.setBounds(233, 36, 75, 14);
		add(statusLbl);
		
		JLabel lblFile = new JLabel(new Config(Constants.LABEL_TEXT).getProperty(String.class, "lblFile"));
		lblFile.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FileStuff.writeFile(pdf);
			}
		});
		lblFile.setForeground(Color.BLUE);
		lblFile.setBounds(10, 132, 49, 14);
		add(lblFile); 
		
		if(type.equals("Text")) text();
		
		if(type.equals("Media")) file();
	}
	
	
	public ExcPageStu() {
		// TODO Auto-generated constructor stub
	}


	private void file() {
		JButton btnNewButton = new JButton("Send file");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to send this?\n this will replace your last answer.", "SEND FILE", JOptionPane.YES_NO_OPTION);

			    if (JOptionPane.YES_OPTION == result) {
			    	String s[] = FileStuff.chooseFile();
			    	if(!s[1].equals("")) controller.sendMediaAns(id, s[0], s[1]);
			    } 
			}
		});
		btnNewButton.setBounds(318, 158, 89, 23);
		add(btnNewButton);
	}

	private void text() {
		JTextArea textArea = new JTextArea();
		textArea.setBounds(10, 157, 298, 132);
		add(textArea);
		
		JButton btnSendText = new JButton("Send text");
		btnSendText.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to send this?\n this will replace your last answer.", "SEND TEXT", JOptionPane.YES_NO_OPTION);

			    if (JOptionPane.YES_OPTION == result) {
			           controller.sendTextAns(id, textArea.getText());
			    } 
			    
			}
		});
		btnSendText.setBounds(318, 266, 89, 23);
		add(btnSendText);
	}
	
	
	public void refresh() {
		String score = controller.getExcScore(id);
		String status = controller.getExcDeliverStatus(id);
		if(score != null && status != null) {
			scoreLbl.setText(score);
			statusLbl.setText(status);
		} else {
			controller.visitHome();
		}		
	}
	
	
	
}

package cw.view.main;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;

import javax.swing.JLabel;
import javax.swing.JPanel;

import client.ConnectionStatus;
import cw.CWController;
import cw.view.course.shared.CoursePageMain;

public class MyCoursesPanel extends JPanel implements MouseListener {

	private LinkedList<String> courses;
	private LinkedList<JLabel> labels = new LinkedList<>();
	private CWController controller = new CWController();
	/**
	 * Create the panel.
	 */
	public MyCoursesPanel(LinkedList<String> courses) { //TODO error handle
		this.courses = courses;
		
		if(courses != null) {
			for(String string : courses) {
				JLabel label = new JLabel(string);
				setLbl(label);
			}
		}
		
		repaint();
		revalidate();
	}
	
	public MyCoursesPanel() {
		// TODO Auto-generated constructor stub
	}

	void refresh() {
		try {
			courses = controller.getMyCourses();
			if(courses != null) {
				for(int i=labels.size(); i<courses.size(); i++) {
					JLabel label = new JLabel(courses.get(i));
					setLbl(label);
				}
			} else {
				controller.visitHome();
			}
		} catch (Exception e) {
			
		}
	}
	
	private void setLbl(JLabel label) {
		label.addMouseListener(this);
		add(label);
		labels.add(label);
	}
	
	
	public LinkedList<String> getCourses() {
		return courses;
	}
	public void setCourses(LinkedList<String> courses) {
		this.courses = courses;
	}

	
	

	@Override
	public void mouseClicked(MouseEvent e) {
		JLabel label = (JLabel)e.getSource();
		String courseID = label.getText().split(" -")[0];
		controller.showCoursePageMain(courseID);
	}


	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	

}

package cw;

import java.util.LinkedList;

import javax.swing.JPanel;

import client.Client;
import client.controller.Controller;
import client.network.ServerController;
import cw.view.main.CWMainFrame;
import cw.view.main.MyCoursesPanel;
import shared.response.Response;

public class CWController extends Controller {
	
	static Client client;
	static ServerController serverController;

	
	public LinkedList<String> getMyCourses() {
		Response response = serverController.getMyCourses(client.getId(), client.getPosition());
		return listFromResp(response);
	}
	
	public static void setClient(Client clt, ServerController scontroller) {
		client = clt;
		serverController = scontroller;
	}

	public String getPosition() {
		return client.getPosition();
	}

	public void createExc(String mini_id, String name, String explaination, String open_time, 
			String close_time, String mohlat, String allowed_type, String pdf) {
		client.createExc(mini_id, name, explaination, open_time, 
				close_time, mohlat, allowed_type, pdf);
	}

	public LinkedList<String> getCourseExcs(String mini_id) {
		Response response = serverController.getCourseExcs(mini_id);
		return listFromResp(response);
	}

	public String getExcStatus(int id) {
		Response response = serverController.getExcStatus(id);
		if(response != null) return (String) response.getData("status");
		return null;
	}

	public String getPDF(int id) {
		Response response = serverController.getExcPDF(id);
		if(response != null) return (String) response.getData("pdf");
		return null;
	}

	public void sendTextAns(int id, String text) {
		client.sendTextAns(id, text);	
	}

	public LinkedList<String> getExcSentList(int id) {
		Response response = serverController.getExcSentList(id);
		return listFromResp(response);
	}

	public String[] getExcStudentMedia(String id, int exc_id) {
		Response response = serverController.getExcStudentMedia(id, exc_id);
		if(response != null) return (String[]) response.getData("media");
		return null;
	}

	public void gradeStudentExc(String id, int exc_id, double doub) {
		client.gradeStudentExc(id, exc_id, doub);
	}

	public LinkedList<String> getCourseSubjects(String mini_id) {
		Response response = serverController.getCourseSubjects(mini_id);
		return listFromResp(response);
	}

	public int createNewSubject(String mini_id, String name) {
		return client.createNewSubject(mini_id, name);
	}

	public void createTextItem(int subj_id, String text) {
		client.createTextItem(subj_id, text);
	}

	public void createMediaItem(int subj_id, String encode, String ext) {
		client.createMediaItem(subj_id, encode, ext);
	}

	public int getItemNum(int subj_id) {
		Response response = serverController.getItemNum(subj_id);
		try {
			return (int) response.getData("num");
		} catch (Exception e) {
			visitHome();
			return -1;
		}
	}

	public LinkedList<String> getSubItemsInfo(int subID) {
		Response response = serverController.getSubItemsInfo(subID);
		return listFromResp(response);
	}

	public String getItemText(String string) {
		int item_id = Integer.parseInt(string);
		Response response = serverController.getItemText(item_id);
		if(response != null) return (String) response.getData("text");
		return null;
	}

	public String getItemBase64(String string) {
		int item_id = Integer.parseInt(string);
		Response response = serverController.getItemBase64(item_id);
		if(response != null) return (String) response.getData("base64");
		return null;
	}

	public void editTextItem(int item_id, String text) {
		client.editTextItem(item_id, text);
	}

	public void editMediaItem(int item_id, String encode, String ext) {
		client.editMediaItem(item_id, encode, ext);
	}

	public void deleteItem(int item_id) {
		client.deleteItem(item_id);
	}

	public void deleteSubject(int subj_id) {
		client.deleteSubject(subj_id);
	}

	public String addToCourse(String courseID, String type, String id) {
		Response response = serverController.addToCourse(courseID, type, id);
		if(response != null) return (String) response.getData("resp");
		return null;
	}

	public void sendAddToCourseAnc(String courseID, String type, String id) {
		client.sendAddToCourseAnc(courseID, type, id);
	}

	public String positionType(String courseID) {
		Response response = serverController.positionType(courseID, client.getId());
		if(response != null) return (String) response.getData("type");
		return null;
	}

	public LinkedList<String> getCourseCal(String course_id) {
		Response response = serverController.getCourseCal(course_id);
		return listFromResp(response);
	}

	public LinkedList<String> getCourseExcs(String mini_id, String sortBy) {
		Response response = serverController.getCourseExcs(mini_id, sortBy);
		return listFromResp(response);
	}

	public String getExcScore(int exc_id) {
		Response response = serverController.getExcScore(client.getId(), exc_id);
		if(response != null) return (String) response.getData("score");
		return null;
	}

	public String getExcDeliverStatus(int exc_id) {
		Response response = serverController.getExcDeliverStatus(client.getId(), exc_id);
		if(response != null) return (String) response.getData("status");
		return null;
	}

	public LinkedList<String> getStuCal() {
		Response response = serverController.getStuCal(client.getId());
		return listFromResp(response);
	}

	public LinkedList<String> getTeacherCal() {
		Response response = serverController.getTeacherCal(client.getId());
		return listFromResp(response);
	}

	public void showCoursePageMain(String courseID) {
		client.showCoursePageMain(courseID);
	}

	public void sendMediaAns(int id, String encode, String ext) {
		client.sendMediaAns(id, encode, ext);
	}
	
}

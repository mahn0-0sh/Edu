package login;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import student.StudentMain;
import teacher.TeacherMain;

public class PassChange extends JFrame {

	private JPanel contentPane;
	private JTextField currPassField;
	private JTextField newPassField;
	private JTextField ReNewPassField;
	private PhaseController controller = new PhaseController();

	

	public PassChange() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(224, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRepeatNewPassword = new JLabel("Repeat new password:");
		lblRepeatNewPassword.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblRepeatNewPassword.setBounds(10, 105, 142, 36);
		contentPane.add(lblRepeatNewPassword);
		
		JLabel lblNewPassword_1 = new JLabel("New password:");
		lblNewPassword_1.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblNewPassword_1.setBounds(10, 58, 142, 36);
		contentPane.add(lblNewPassword_1);
		
		JLabel lblCurrentPassword = new JLabel("Current password:");
		lblCurrentPassword.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblCurrentPassword.setBounds(10, 11, 142, 36);
		contentPane.add(lblCurrentPassword);
		
		currPassField = new JTextField();
		currPassField.setBackground(new Color(255, 240, 245));
		currPassField.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		currPassField.setBounds(162, 20, 150, 20);
		contentPane.add(currPassField);
		currPassField.setColumns(10);
		
		newPassField = new JTextField();
		newPassField.setBackground(new Color(255, 240, 245));
		newPassField.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		newPassField.setColumns(10);
		newPassField.setBounds(162, 67, 150, 20);
		contentPane.add(newPassField);
		
		ReNewPassField = new JTextField();
		ReNewPassField.setBackground(new Color(255, 240, 245));
		ReNewPassField.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		ReNewPassField.setColumns(10);
		ReNewPassField.setBounds(162, 114, 150, 20);
		contentPane.add(ReNewPassField);
		
		JButton btnNewButton = new JButton("Apply changes and Enter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(isNewPassValid()) {
					controller.changePass(newPassField.getText());
					JOptionPane.showMessageDialog(null, "Password changed successfully.");
					controller.visitHome();
				} else {
					JOptionPane.showMessageDialog(null, "Please try again!");
				}
				
			}
		});
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton.setBackground(new Color(255, 240, 245));
		btnNewButton.setBounds(354, 66, 258, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton_1.setBackground(new Color(255, 240, 245));
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton_1.setBounds(523, 19, 89, 23);
		contentPane.add(btnNewButton_1);
	}
	
	public boolean isNewPassValid() {
		if(newPassField.getText().equals(ReNewPassField.getText())) {
			if(newPassField.getText().equals(currPassField.getText())) {
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}
	}
	
	
	
}

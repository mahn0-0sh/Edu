package login;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.checkerframework.checker.units.qual.g;
import org.checkerframework.checker.units.qual.m;

import client.Client;
import client.controller.Controller;
import client.network.ServerController;
import constants.Constants;
import enums.ReqType;
import enums.StudentDegree;
import enums.TeacherDegree;
import shared.response.Response;
import shared.response.ResponseStatus;
import shared.util.Config;

public class PhaseController extends Controller {

	static Client client;
	static ServerController serverController;
	
	public static void setClient(Client client2, ServerController serverController2) {
		client = client2;
		serverController = serverController2;
	}
	
	
	
	public List<String> filterCourse(String type, String by) {
		Response response = serverController.sendFilterCourseReq(type, by);
		List<String> list = null;
		if(response != null) {
			if(response.getStatus() == ResponseStatus.FIL_FULL) list = (List<String>) response.getData("full");
			if(response.getStatus() == ResponseStatus.FIL_DEP) list = (List<String>) response.getData("dep");
			if(response.getStatus() == ResponseStatus.FIL_DEG) list = (List<String>) response.getData("degree");
			if(response.getStatus() == ResponseStatus.FIL_CRE) list = (List<String>) response.getData("credit");
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<String> getTeacherList() {
		Response response = serverController.getTeacherList();
		if(response != null) return (ArrayList<String>) response.getData("list");
		return null;
	}

	public void showCoursesList() {
		client.showCoursesList();
	}

	public void showTeachersList() {
		client.showTeachersList();
	}

	public void showWeekSchd() {
		try {
			client.showWeekSchd();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void showExamSchd() {
		try {
			client.showExamSchd();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void showTempScores() {
		client.showTempScores(client.getId());
	}

	public void showEduStatus() {
		client.showEduStatus();
	}

	public void showProfile() {
		try {
			client.showProfile();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public LinkedList<String> getScoreListForCourse(String mini_id) {
		Response response = serverController.getScoreListForCourse(mini_id);
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}

	public void tempRegister(HashMap<String, Double> scores, String mini_id) {
		serverController.tempRegister(scores, mini_id);
	}

	public void finalRegister(HashMap<String, Double> scores, String mini_id) {
		serverController.finalRegister(scores, mini_id);
	}

	@SuppressWarnings("unchecked")
	public LinkedList<String> getTeacherCourses() {
		Response response = serverController.getMyCourses(client.getId(), client.getPosition());
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}

	public void showRegScoresPage(String mini_id) {
		client.showRegScoresPage(mini_id);
	}

	public String getPosition() {
		return client.getPosition();
	}

	public void showEduStatus(String id) {
		client.showEduStatus(id);
	}

	public void showDepEduStatus() {
		client.showDepEduStatus();
	}

	public void showDepTempScores() {
		client.showDepTempScores();
	} 

	public void showManagerEditPage() {
		client.showManagerEditPage();
	}

	public void showAddCourse() {
		client.showAddCourse();
	}

	public void removeCourse(String mini_id) {
		serverController.removeCourse(mini_id);
	}

	public void showDepEditCourse(String iDString) {
		client.showDepEditCourse(iDString);
	}

	public String addNewCourse(String id, String name, int groups, String degree, int credit) {
		Response response = serverController.addNewCourse(id, name, groups, degree, credit, client.getDep());
		if(response != null) return (String) response.getData("resp");
		return null;
	}

	public void visitHome() {
		try {
			client.visitHome();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public StudentDegree getDegree() {
		StudentDegree degree = null;
		Response response = serverController.getDegree(client.getId());
		if(response != null) degree = (StudentDegree) response.getData("degree");
		return degree;
	}

	public void sendReq(ReqType reqType, String recp, String dep) {
		serverController.sendStuReq(reqType, recp, dep, client.getId());
	}

	public void showReqPage() {
		client.showReqPage();
	}

	public void editCourse(String string, String course_id, String text) {
		// TODO Auto-generated method stub
		
	}

	public void editCourse(String string, String course_id, String text, Integer selectedItem) {
		// TODO Auto-generated method stub
		
	}

	public ArrayList<Integer> getGroups(String course_id) {
		Response response = serverController.getCourseGroups(course_id);
		if(response != null) return (ArrayList<Integer>) response.getData("list");
		return null;
	}

	public String getMainStatus() {
		return client.mainPageStatus();
	}

	public LinkedList<String> getTempScores(String id) {
		Response response = serverController.getTempScores(id);
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}

	public void courseChooseGUI() {
		client.courseChooseGUI();
	}
	

	public void editTeacher(String room, TeacherDegree degree) { 
		client.editTeacher(room, degree);
	}

	public void showManagerTeacherEdit(String teacher_id) {
		client.showManagerTeacherEdit(teacher_id);
	}

	public void removeTeacher(String teacher_id) {
		client.removeTeacher(teacher_id); //dep
	}

	public String addNewTeacher(String user, String pass, String first, String last, String email, String phone,
			String code, TeacherDegree teacherDegree, String room, String id) { 
		Response response = serverController.addNewTeacher(user, pass, first, last, email, phone, code, teacherDegree, room, id, client.getId());
		if(response != null) return (String) response.getData("resp");
		else return null;
	}

	public void showAddTeacher() {
		client.showAddTeacher();
	}

	public void changeDeputy(String teacher_id) {
		client.changeDeputy(teacher_id);
	}

	public void protestToScore(String mini_id) {
		client.protestToScore(mini_id);
	}

	public void showProtestFeedbackDialog() {
		client.showProtestFeedbackDialog();
	}

	public LinkedList<String> getProtestFeedbacks() {
		Response response = serverController.getProtestFeedbacks(client.getId());
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}

	public LinkedList<String> getCourseProtestedStudents(String mini_id) {
		Response response = serverController.getCourseProtestedStudents(mini_id);
		if(response != null) return (LinkedList<String>) response.getData("list");
		return null;
	}

	public void respondProtest(String id, String mini_id, String stat) {
		serverController.respondProtest(id, mini_id, stat);
	}

	public void showProtests(String mini_id) {
		client.showProtests(mini_id);
	}

	public String getIdByName(String name) {
		Response response = serverController.getIdByName(name);
		if(response != null) {
			if(response.getStatus() == ResponseStatus.OK) return (String) response.getData("id");
			else return (String) response.getData("err");
		}
		return null;
	}

	public LinkedList<String> getFullScores(String id) {
		try {
			return client.getFullScores(id);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public Double getGPA(String id) {
		if(id == null) id = client.getId();
		try {
			return client.getGPA(id);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public int getCredits(String id) {
		try {
			return client.getCredits(id);
		} catch (SQLException e) {
			e.printStackTrace();
			return -1;
		}
	}

	public void showDepScoreOfStu(String id) {
		client.showTempScores(id);
	}

	public void showScoresOfClass(String mini_id) {
		client.showScoresOfClass(mini_id);
	}

	public void showDeputyTeacherScores(String teach_id) {
		client.showDeputyTeacherScores(teach_id);
	}

	public String getCourseEduStatus(String mini_id) {
		Response response = serverController.getCourseEduStatus(mini_id);
		if(response != null) return (String) response.getData("edu_stat");
		return null;
	}

	public LinkedList<String> getFullScoreListForCourse(String mini_id) {
		Response response = serverController.getFullScoreListForCourse(mini_id);
		return listFromResp(response);
	}

	public void showAllTimeProtests(String mini_id) {
		client.showAllTimeProtests(mini_id);
	}

	public void showRecomPage() {
		client.showRecomPage();
	}

	public String getCertificate() {
		Response response = serverController.getCertificate(client.getId());
		if(response != null) return (String) response.getData("data");
		else return null;
	}
	
	public void showCertificate() {
		client.showCertificate();
	}

	public void showStuRecomFeed() {
		client.showStuRecomFeed();
	}

	public void showChatMain() {
		client.showChatMain();
	}

	public void showMsgMain() {
		client.showMsgMain();
	}

	public void reconnect() {
		client.reconnect();
	}

	public void correctChoices() {
		client.correctChoices();
	}

	public String mainPageStatus() {
		return client.mainPageStatus();
	}

	public void showCWMain() {
		client.CWgui();
	}

	public void showAddStudent() {
		client.showAddStudent();		
	}



	public LinkedList<String> getTeacherScores(String teach_id) {
		Response response = serverController.getTeacherScores(teach_id);
		return listFromResp(response);
	}



	public LinkedList<String> getAllProtests(String mini_id) {
		Response response = serverController.getAllProtests(mini_id);
		return listFromResp(response);
	}



	public void changePass(String pass) {
		serverController.changePass(pass, client.getId());
	}



	public void changeData(String data, String type) {
		serverController.changeData(data, type, client.getId());
	}



	public LinkedList<String> getWeekSchd() {
		return client.getWeekSchd();
	}



	public LinkedList<String> getExamSchd() {
		return client.getExamSchd();
	}



	public String getProfileStatus() {
		try {
			return client.profile();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
}

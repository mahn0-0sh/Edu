package login;

import java.util.LinkedList;

import client.Client;
import client.controller.Controller;
import client.network.ServerController;
import shared.response.Response;

public class ReqController extends Controller {
	static Client client;
	static ServerController serverController;
	
	public static void setClient(Client client2, ServerController serverController2) {
		client = client2;
		serverController = serverController2;
	}

	public LinkedList<String> getRecomList() {
		Response response = serverController.getRecomList(client.getId());
		return listFromResp(response);
	}

	public String getRecomText(String teacher_id) {
		Response response = serverController.getRecomText(client.getId(), teacher_id);
		if(response != null) return (String) response.getData("text");
		return null;
	}

}

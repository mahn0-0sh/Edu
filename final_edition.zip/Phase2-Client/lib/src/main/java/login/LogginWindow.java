package login;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JTextField;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import shared.model.*;
import student.StudentMain;
import client.Client;
import phase2.shared.Visit;
import resources.CapchaPics;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class LogginWindow {
	
	private Logger logger = LogManager.getLogger(LogginWindow.class);
	private Client client;
	public JFrame frame;
	private JTextField usernameTextBox;
	private JTextField passwordTextBox;
	private JTextField textField;
	private JLabel capchaLbl;
	private int capchaNumber=1;


	public LogginWindow(Client client) {
		this.client = client;
	//	Person.editStuCourseList();
		initialize();
	}

	private void initialize() {
		//frame
		frame = new JFrame();
		frame.setBounds(100, 100, 870, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		//
		JLabel lblNewLabel = new JLabel("Username:");
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(108, 16, 110, 46);
		frame.getContentPane().add(lblNewLabel);
		
		
		
		//
		JButton enterButton = new JButton("Enter");
		enterButton.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 15));
		enterButton.setBackground(new Color(245, 255, 250));
		enterButton.setForeground(Color.BLUE);
		enterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { //TODO pass change
				
				String username = usernameTextBox.getText();
				String password = passwordTextBox.getText();
				
				
				if( CapchaPics.isCapchaCorrect(capchaNumber, textField.getText()) ) { 
				
						client.login(username, password);
						
			    } else {
			    	JOptionPane.showMessageDialog(null, "Wrong capcha");
			    	capchaNumber++;
					if(capchaNumber>5) capchaNumber=capchaNumber-5;
					new CapchaPics(capchaNumber,capchaLbl);
			    }  
				
				
			//	client.login(username, password);
				
				
				
				
				
				
				
				//Teacher login
		/*	else if( Person.validLoginT( usernameTextBox.getText() , passwordTextBox.getText() ) && CapchaPics.isCapchaCorrect(capchaNumber, textField.getText())  ) {
					frame.dispose();
					
					Teacher t = Person.wichTeacher(usernameTextBox.getText());	
					 if(Visit.isVisitDiffMoreThan3(t)) {
							PassChange passChange = new PassChange(usernameTextBox.getText(), "Teacher");
							passChange.setVisible(true);
					} else {
		//Teacher and Manager
					if(t.getPosition().equals("Teacher")) {
						role = "T";
					} else if( t.getPosition().equals("Manager")) {
						role = "M";
					}
					else {
						role="D";
					}
					
					logger.info("Teacher "+t.getID()+" logged in");
					
					TeacherMain.themeNumber = 0;
					TeacherMain.teachM=(Teacher) t;
					TeacherMain.frameStatic = new TeacherMain();
					TeacherMain.frameStatic.nameLabel.setText(t.getFirstName()+" "+t.getLastName());
					TeacherMain.frameStatic.emailLabel.setText(t.getEmail());
					TeacherMain.frameStatic.setVisible(true); 
				//	System.out.println(t.getEmail());
					}
					}
				
				else {
					JOptionPane.showMessageDialog(null, "Login unsuccessful!");
					capchaNumber++;
					if(capchaNumber>5) capchaNumber=capchaNumber-5;
					new CapchaPics(capchaNumber,capchaLbl);
					
					logger.error("unsuccessful login");
				} */
				
			} 
		});
		enterButton.setBounds(287, 312, 224, 46);
		frame.getContentPane().add(enterButton);
		
		
		
		//
		usernameTextBox = new JTextField();
		usernameTextBox.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		usernameTextBox.setBackground(new Color(230, 230, 250));
		usernameTextBox.setBounds(287, 16, 224, 46);
		frame.getContentPane().add(usernameTextBox);
		usernameTextBox.setColumns(10);
		
		
		//
		passwordTextBox = new JTextField();
		passwordTextBox.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		passwordTextBox.setBackground(new Color(230, 230, 250));
		passwordTextBox.setBounds(287, 90, 224, 46);
		frame.getContentPane().add(passwordTextBox);
		passwordTextBox.setColumns(10);
		
		
		//
		JButton btnNewButton = new JButton("Close");
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnNewButton.setBackground(new Color(255, 240, 245));
		btnNewButton.setForeground(new Color(0, 0, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton.setBounds(588, 29, 77, 23);
		frame.getContentPane().add(btnNewButton);
		
		
		//
		capchaLbl = new JLabel("");
		capchaLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		capchaLbl.setBackground(Color.GRAY);
		capchaLbl.setBounds(287, 147, 224, 97);
		frame.getContentPane().add(capchaLbl);
		new CapchaPics(capchaNumber,capchaLbl); 
	
		
		//
		textField = new JTextField();
		textField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		textField.setBackground(new Color(240, 255, 240));
		textField.setBounds(287, 255, 224, 46);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		
		//
		JButton btnNewButton_1 = new JButton("Change");
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				capchaNumber++;
				if(capchaNumber>5) capchaNumber=capchaNumber-5;
				new CapchaPics(capchaNumber,capchaLbl);
			}
		});
		btnNewButton_1.setBackground(new Color(245, 255, 250));
		btnNewButton_1.setForeground(Color.BLUE);
		btnNewButton_1.setBounds(206, 267, 69, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblPassword_1 = new JLabel("Password:");
		lblPassword_1.setForeground(Color.BLUE);
		lblPassword_1.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 15));
		lblPassword_1.setBounds(108, 90, 110, 46);
		frame.getContentPane().add(lblPassword_1);
	}
	
/*	public void loginAsStudent() {
		frame.dispose();
		Student stu = Person.wichStudent(usernameTextBox.getText());
		StudentMain.stdM = stu;
		
	/*	if(Visit.isVisitDiffMoreThan3(stu)) {
			PassChange passChange = new PassChange(usernameTextBox.getText(),"Student");
			passChange.setVisible(true);
		} else { */					
/*			logger.info("Student "+stu.getID()+" logged in");					
			role = "S";
		StudentMain.themeNumber = 0;
		StudentMain.frameStatic = new StudentMain();
		student.frameStatic.nameLabel.setText(stu.getFirstName()+" "+stu.getLastName());
		student.frameStatic.emailLabel.setText(stu.getEmail());
		student.frameStatic.supervL.setText(StudentMain.stdM.getSupervisor().getFirstName()+" "+StudentMain.stdM.getSupervisor().getLastName());
		
		StudentMain.frameStatic.setVisible(true);
	} */
} 

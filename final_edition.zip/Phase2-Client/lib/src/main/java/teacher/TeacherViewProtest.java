package teacher;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.LogginWindow;
import login.PhaseController;

import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.awt.event.ActionEvent;

public class TeacherViewProtest extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private DefaultListModel<String> dListModel = new DefaultListModel<>();
	private PhaseController controller = new PhaseController();
	private JList list = new JList();
	private String mini_id;

	
	public TeacherViewProtest(String mini_id) {
		this.mini_id = mini_id;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 449);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnNewButton.setBounds(653, 11, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnHomepage = new JButton("Homepage");
		btnHomepage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnHomepage.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnHomepage.setBounds(653, 45, 89, 23);
		contentPane.add(btnHomepage);
		
		initialize(mini_id);
		
	}
	
	void initialize(String mini_id) {
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 265, 390);
		contentPane.add(scrollPane);
		
		
		list = new JList();
		scrollPane.setViewportView(list);
		list.setModel(dListModel);
		refresh();
		
		
		textField = new JTextField();
		textField.setBounds(339, 10, 124, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		
		
		//Accept
		JButton btnNewButton_1 = new JButton("Accept");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				controller.respondProtest(textField.getText(), mini_id, "VALID");
				
			}
		});
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.ITALIC, 11));
		btnNewButton_1.setBounds(339, 44, 124, 23);
		contentPane.add(btnNewButton_1);
		
		
		
		
		//Deny
		JButton btnNewButton_1_1 = new JButton("Deny");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				controller.respondProtest(textField.getText(), mini_id, "INVALID");
			}
		});
		btnNewButton_1_1.setFont(new Font("Traditional Arabic", Font.ITALIC, 11));
		btnNewButton_1_1.setBounds(339, 78, 124, 23);
		contentPane.add(btnNewButton_1_1);
		}

	public void refresh() {
		LinkedList<String> protestedStudents = controller.getCourseProtestedStudents(mini_id); //name + id
		if(protestedStudents != null) {
			dListModel = new DefaultListModel<>();
			try {
				for(int i=0; i<protestedStudents.size(); i++) {
					dListModel.addElement(protestedStudents.get(i));
				}		
			} catch (Exception e) {
				// TODO: handle exception
				dListModel.addElement("");
			}
		}
	}
		
	
}

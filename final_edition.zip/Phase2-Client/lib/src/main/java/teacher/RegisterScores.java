package teacher;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.PhaseController;

import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class RegisterScores extends JFrame {

	private JPanel contentPane;
	private DefaultListModel dListModel = new DefaultListModel();
	private PhaseController controller = new PhaseController();
	private HashMap<String, Double> scores = new HashMap<>();
	private LinkedList<String> students = new LinkedList<>();
	private JTextField idField;
	private JTextField scoreField;
	private JList list;
	private JButton btnNewButton_2;

	private void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 770, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}
	
	
	private void initHashMap() {
		for(String string : students) {
			Double input = null;
			try {
				input = Double.parseDouble(string.split("\\s+")[2]);
			} catch (Exception e) {
				// TODO: handle exception
			}
			scores.put(string.split("\\s+")[0], input);
		}
		setModel();
	}
	
	public RegisterScores(String mini_id) {
		students = controller.getScoreListForCourse(mini_id);
		initPane();
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 230, 341);
		contentPane.add(scrollPane);
		
		list = new JList();
		scrollPane.setViewportView(list);
		
		initHashMap();
		
		
		JButton btnNewButton = new JButton("Set score");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					String id = idField.getText();
					Double score = Double.parseDouble(scoreField.getText());
					scores.put(id, score);
					setModel();
				} catch (Exception e2) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "Wrong type");
				}
				
			}
		});
		btnNewButton.setBounds(250, 72, 96, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Temperory register");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					if(scores.containsValue(-1.0)) {
						JOptionPane.showMessageDialog(null, "Try again");
					} else {
						controller.tempRegister(scores, mini_id);
						initHashMap();
						setModel();
					}
				} catch (Exception e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
				
			}
		});
		btnNewButton_1.setBounds(250, 106, 155, 35);
		contentPane.add(btnNewButton_1);
		
		idField = new JTextField();
		idField.setBounds(250, 10, 96, 20);
		contentPane.add(idField);
		idField.setColumns(10);
		
		scoreField = new JTextField();
		scoreField.setBounds(250, 41, 96, 20);
		contentPane.add(scoreField);
		scoreField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setBounds(356, 13, 49, 14);
		contentPane.add(lblNewLabel);
		
		btnNewButton_2 = new JButton("Final register");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(scores.containsValue(-1.0)) {
						JOptionPane.showMessageDialog(null, "Try again");
					} else {
						controller.finalRegister(scores, mini_id);
					}
				} catch (Exception e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
		});
		btnNewButton_2.setBounds(250, 152, 155, 35);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("View protests");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showProtests(mini_id);
			}
		});
		btnNewButton_3.setBounds(250, 198, 155, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Home");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton_4.setBounds(657, 11, 89, 23);
		contentPane.add(btnNewButton_4);
	}
	
	
	private void setModel() {
		DefaultListModel<String> model = new DefaultListModel<>();
		for(String string : scores.keySet()) {
			model.addElement(string+"   score: "+scores.get(string));
		}
		list.setModel(model);
	}


	public void refresh() {
		// no need to refresh
	}
}

package teacher.deputy;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import client.Client;
import enums.Departments;
import enums.StudentDegree;
import enums.TeacherDegree;
import enums.getEnums;
import login.PhaseController;
import shared.model.*;
import teacher.TeacherMain;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class AddNewTeacher extends JFrame {

	private JPanel contentPane;
	private JTextField firstNameField, lastNameField, codeField, idField, degreeField, phoneField, emailField, userField, passField, roomField;
	private JLabel lblCode_1_1_1_1_1_2;
	private JButton btnNewButton_1;
	static Teacher admin;
	private JButton btnNewButton_2;
	static Logger logger = LogManager.getLogger(AddNewTeacher.class);
	private PhaseController controller = new PhaseController();

	

	public AddNewTeacher() {
		initPane();
		initConstant();
		textFields();
		
		registerBtn();
		
		homeBtn();
		exitBtn();
	}



	private void exitBtn() {
		// TODO Auto-generated method stub
		btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton_1.setBounds(332, 7, 89, 23);
		contentPane.add(btnNewButton_1);
	}



	private void homeBtn() {
		// TODO Auto-generated method stub
		btnNewButton_2 = new JButton("Homepage");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnNewButton_2.setBounds(332, 36, 89, 23);
		contentPane.add(btnNewButton_2);
	}



	private void registerBtn() {
		// TODO Auto-generated method stub
		JButton btnNewButton = new JButton("Register");
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String resp = controller.addNewTeacher(
						userField.getText(), passField.getText(), 
						firstNameField.getText(), lastNameField.getText(), 
						emailField.getText(), phoneField.getText(), 
						codeField.getText(), getEnums.getTeacherDegree(degreeField.getText()), 
						roomField.getText(), idField.getText());
				
				JOptionPane.showMessageDialog(null, resp);
			}
		});
		btnNewButton.setBounds(10, 261, 176, 23);
		contentPane.add(btnNewButton);
	}



	private void textFields() {
		// TODO Auto-generated method stub
		lastNameField = new JTextField();
		lastNameField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lastNameField.setColumns(10);
		lastNameField.setBounds(90, 33, 96, 20);
		contentPane.add(lastNameField);
		
		codeField = new JTextField();
		codeField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		codeField.setColumns(10);
		codeField.setBounds(90, 58, 96, 20);
		contentPane.add(codeField);
		
		idField = new JTextField();
		idField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		idField.setColumns(10);
		idField.setBounds(90, 83, 96, 20);
		contentPane.add(idField);
		
		degreeField = new JTextField();
		degreeField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		degreeField.setColumns(10);
		degreeField.setBounds(90, 108, 96, 20);
		contentPane.add(degreeField);
		
		phoneField = new JTextField();
		phoneField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		phoneField.setColumns(10);
		phoneField.setBounds(90, 133, 96, 20);
		contentPane.add(phoneField);
		
		emailField = new JTextField();
		emailField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		emailField.setColumns(10);
		emailField.setBounds(90, 158, 96, 20);
		contentPane.add(emailField);
		
		userField = new JTextField();
		userField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		userField.setColumns(10);
		userField.setBounds(90, 183, 96, 20);
		contentPane.add(userField);
		
		passField = new JTextField();
		passField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		passField.setColumns(10);
		passField.setBounds(90, 208, 96, 20);
		contentPane.add(passField);
		
		
		
		
		roomField = new JTextField();
		roomField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		roomField.setColumns(10);
		roomField.setBounds(90, 233, 96, 20);
		contentPane.add(roomField);
	}



	private void initConstant() {
		// TODO Auto-generated method stub
		JLabel lblNewLabel = new JLabel("First name:");
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblNewLabel.setBounds(10, 11, 70, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblLastName = new JLabel("Last name:");
		lblLastName.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblLastName.setBounds(10, 36, 70, 14);
		contentPane.add(lblLastName);
		
		JLabel lblCode = new JLabel("Code:");
		lblCode.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblCode.setBounds(10, 61, 70, 14);
		contentPane.add(lblCode);
		
		JLabel lblId = new JLabel("ID:");
		lblId.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblId.setBounds(10, 86, 70, 14);
		contentPane.add(lblId);
		
		JLabel lblCode_1_1 = new JLabel("Degree:");
		lblCode_1_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblCode_1_1.setBounds(10, 111, 70, 14);
		contentPane.add(lblCode_1_1);
		
		JLabel lblCode_1_1_1 = new JLabel("Phone:");
		lblCode_1_1_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblCode_1_1_1.setBounds(10, 136, 70, 14);
		contentPane.add(lblCode_1_1_1);
		
		JLabel lblCode_1_1_1_1 = new JLabel("Email:");
		lblCode_1_1_1_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblCode_1_1_1_1.setBounds(10, 161, 70, 14);
		contentPane.add(lblCode_1_1_1_1);
		
		JLabel lblCode_1_1_1_1_1 = new JLabel("Username:");
		lblCode_1_1_1_1_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblCode_1_1_1_1_1.setBounds(10, 186, 70, 14);
		contentPane.add(lblCode_1_1_1_1_1);
		
		JLabel lblCode_1_1_1_1_1_1 = new JLabel("Password:");
		lblCode_1_1_1_1_1_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblCode_1_1_1_1_1_1.setBounds(10, 211, 70, 14);
		contentPane.add(lblCode_1_1_1_1_1_1);
		
		firstNameField = new JTextField();
		firstNameField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		firstNameField.setBounds(90, 8, 96, 20);
		contentPane.add(firstNameField);
		firstNameField.setColumns(10);
		
		lblCode_1_1_1_1_1_2 = new JLabel("Room:");
		lblCode_1_1_1_1_1_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblCode_1_1_1_1_1_2.setBounds(10, 236, 70, 14);
		contentPane.add(lblCode_1_1_1_1_1_2);
	}



	private void initPane() {
		// TODO Auto-generated method stub
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 883, 458);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}

}

package teacher.deputy;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.LogginWindow;
import login.PhaseController;
import student.EducationalStatus;
import teacher.TeacherMain;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DepEduStatus extends JFrame {

	private JPanel contentPane;
	private JTextField IDField;
	private JTextField nameField;
	private PhaseController controller = new PhaseController();


	public DepEduStatus() {
	//	super();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		//Student
		JLabel lblSTuId = new JLabel("Student ID:");
		lblSTuId.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblSTuId.setBounds(10, 51, 89, 40);
		getContentPane().add(lblSTuId);
		
		IDField = new JTextField();
		IDField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		IDField.setColumns(10);
		IDField.setBounds(153, 51, 153, 40);
		getContentPane().add(IDField);
		
		JButton IDSearch = new JButton("Search");
		IDSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					controller.showEduStatus(IDField.getText());
				} catch (Exception e1) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "Error.");
				}
			}
		});
		IDSearch.setFont(new Font("Traditional Arabic", Font.BOLD, 14));
		IDSearch.setBounds(316, 51, 149, 40);
		getContentPane().add(IDSearch);
		
		
		
		
		
		
		
		
		
		
		
		
		//Exit
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnNewButton.setBounds(617, 11, 89, 23);
		getContentPane().add(btnNewButton);
		
		JButton btnHomepage = new JButton("Homepage");
		btnHomepage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnHomepage.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnHomepage.setBounds(617, 51, 89, 23);
		getContentPane().add(btnHomepage);
		
		JLabel lblStudentName = new JLabel("Student Name:");
		lblStudentName.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblStudentName.setBounds(10, 102, 133, 40);
		contentPane.add(lblStudentName);
		
		nameField = new JTextField();
		nameField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		nameField.setColumns(10);
		nameField.setBounds(153, 102, 153, 40);
		contentPane.add(nameField);
		
		JButton NameSearch = new JButton("Search");
		NameSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String resp = controller.getIdByName(nameField.getText()); // give back ID if exists
				if(resp.equals("err")) JOptionPane.showMessageDialog(null, "More than one students with this name");
				else controller.showEduStatus(resp);
			}
		});
		NameSearch.setFont(new Font("Traditional Arabic", Font.BOLD, 14));
		NameSearch.setBounds(316, 102, 149, 40);
		contentPane.add(NameSearch);
	}
}

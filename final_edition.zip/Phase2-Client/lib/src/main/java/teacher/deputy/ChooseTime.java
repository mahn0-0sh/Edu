package teacher.deputy;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import chooseCourse.ChooseController;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class ChooseTime extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private ChooseController controller = new ChooseController();
	private JTextField textField;
	private JTextField textField_1;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ChooseTime() {
		setBounds(100, 100, 450, 215);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
			JComboBox yearBox = new JComboBox();
			yearBox.setModel(new DefaultComboBoxModel(new String[] {"1400", "1399", "1398", "1397"}));
			yearBox.setBounds(10, 11, 70, 22);
			contentPanel.add(yearBox);
			
			JComboBox comboBox = new JComboBox();
			comboBox.setModel(new DefaultComboBoxModel(new String[] {"BACHELOR", "MASTER", "DOCTORATE"}));
			comboBox.setBounds(10, 44, 101, 22);
			contentPanel.add(comboBox);
			{
				textField = new JTextField();
				textField.setBounds(10, 79, 96, 20);
				contentPanel.add(textField);
				textField.setColumns(10);
			}
			
			textField_1 = new JTextField();
			textField_1.setColumns(10);
			textField_1.setBounds(10, 110, 96, 20);
			contentPanel.add(textField_1);
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						int year = Integer.parseInt((String)yearBox.getSelectedItem());
						String dep = (String) comboBox.getSelectedItem();
						String start = textField.getText();
						String end = textField_1.getText();
						
						try {
							new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(start);
							new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(end);
							String time = start+" + "+end;
							controller.setChooseTime(year, dep, time);
							JOptionPane.showMessageDialog(null, "Done!");
							dispose();
						} catch (Exception e2) {
							JOptionPane.showMessageDialog(null, "wrong time format");
						}
						
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}

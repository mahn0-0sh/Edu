package teacher.deputy;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.LinkedList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import constants.Constants;
import login.PhaseController;
import shared.util.Config;

import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ProtestsAll extends JFrame {

	private JPanel contentPane;
	private JList list;
	private PhaseController controller = new PhaseController();
	private String mini_id;

	

	/**
	 * Create the frame.
	 */
	public ProtestsAll(String mini_id) {
		this.mini_id = mini_id;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		JButton btnNewButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "home"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		panel.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		list = new JList();
		scrollPane.setViewportView(list);
		refresh();
	}

	public void refresh() {
		DefaultListModel<String> model = new DefaultListModel<>();
		LinkedList<String> allProtests = controller.getAllProtests(mini_id);
		if(allProtests != null) {
			for(String string : allProtests) model.addElement(string);
			list.setModel(model);
		} else {
			controller.visitHome();
		}
	}
	
}

package teacher.deputy;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.PhaseController;

import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.LinkedList;
import java.awt.event.ActionEvent;

public class ScoresOfClass extends JFrame {

	private JPanel contentPane;
	private PhaseController controller = new PhaseController();
	private JList list;
	private JLabel gpaLbl;
	private JLabel passLbl;
	private JLabel failLbl;
	private JLabel passGpaLbl;
	private HashMap<String, Double> scores = new HashMap<>();
	private LinkedList<String> students = new LinkedList<>();

	
	
	private void initHashMap() {
		//students todo
		for(String string : students) {
			Double input = null;
			try {
				input = Double.parseDouble(string.split("\\s+")[2]);
			} catch (Exception e) {
				// TODO: handle exception
			}
			scores.put(string.split("\\s+")[0], input);
		}
		setModel();
	}

	
	private void setModel() {
		DefaultListModel<String> model = new DefaultListModel<>();
		for(String string : scores.keySet()) {
			model.addElement(string+"   score: "+scores.get(string));
		}
		list.setModel(model);
	}
	
	/**
	 * Create the frame.
	 */
	public ScoresOfClass(String mini_id) {
		students = controller.getFullScoreListForCourse(mini_id); //TODO full scores
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 580, 405);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 211, 346);
		contentPane.add(scrollPane);
		
		list = new JList();
		scrollPane.setViewportView(list);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(231, 11, 250, 120);
		contentPane.add(panel);
		
		JLabel lblGpa = new JLabel("GPA:");
		lblGpa.setBounds(10, 11, 60, 14);
		panel.add(lblGpa);
		
		JLabel lblPass = new JLabel("Passed:");
		lblPass.setBounds(10, 36, 60, 14);
		panel.add(lblPass);
		
		JLabel lblFail = new JLabel("Failed:");
		lblFail.setBounds(10, 61, 60, 14);
		panel.add(lblFail);
		
		JLabel lblPassGpa = new JLabel("Pass gpa:");
		lblPassGpa.setBounds(10, 86, 60, 14);
		panel.add(lblPassGpa);
		
		gpaLbl = new JLabel();
		gpaLbl.setBounds(80, 11, 49, 14);
		panel.add(gpaLbl);
		
		passLbl = new JLabel();
		passLbl.setBounds(80, 36, 49, 14);
		panel.add(passLbl);
		
		failLbl = new JLabel();
		failLbl.setBounds(80, 61, 49, 14);
		panel.add(failLbl);
		
		passGpaLbl = new JLabel();
		passGpaLbl.setBounds(80, 86, 49, 14);
		panel.add(passGpaLbl);
		
		refresh(mini_id);
		
		JButton btnNewButton_5 = new JButton("Protests");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showAllTimeProtests(mini_id);
			}
		});
		btnNewButton_5.setBounds(151, 82, 89, 23);
		panel.add(btnNewButton_5);
	}
	
	public void refresh(String mini_id) {
		String status = controller.getCourseEduStatus(mini_id);
		if(status != null) {
			String s[] = status.split("`");
			gpaLbl.setText(s[0]);
			passLbl.setText(s[1]);
			failLbl.setText(s[2]);
			passGpaLbl.setText(s[3]);
			
			students = controller.getFullScoreListForCourse(mini_id);
			initHashMap();
			setModel();
		} else {
			controller.visitHome();
		}
	}


	
}

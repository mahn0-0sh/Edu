package teacher.deputy;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.LogginWindow;
import login.PhaseController;
import teacher.TeacherMain;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DeputyTemperoryScores extends JFrame {

	private JPanel contentPane;
	private JTextField studentField;
	private JTextField courseField;
	private JTextField teacherField;
	private PhaseController controller = new PhaseController();


	public DeputyTemperoryScores() {
	//	super();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		//Student
		JLabel lblSTuId = new JLabel("Student ID:");
		lblSTuId.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblSTuId.setBounds(10, 102, 89, 40);
		getContentPane().add(lblSTuId);
		
		studentField = new JTextField();
		studentField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		studentField.setColumns(10);
		studentField.setBounds(109, 102, 153, 40);
		getContentPane().add(studentField);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showDepScoreOfStu(studentField.getText());
			}
		});
		btnSearch.setFont(new Font("Traditional Arabic", Font.BOLD, 14));
		btnSearch.setBounds(272, 102, 149, 40);
		getContentPane().add(btnSearch);
		
		
		
		
		
		
		
		
		//Course
		JLabel lblCourseId = new JLabel("Course ID:");
		lblCourseId.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblCourseId.setBounds(10, 51, 89, 40);
		getContentPane().add(lblCourseId);
		
		courseField = new JTextField();
		courseField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		courseField.setColumns(10);
		courseField.setBounds(109, 51, 153, 40);
		getContentPane().add(courseField);
		
		JButton btnSearch_2 = new JButton("Search");
		btnSearch_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showScoresOfClass(courseField.getText());
			}
		});
		btnSearch_2.setFont(new Font("Traditional Arabic", Font.BOLD, 14));
		btnSearch_2.setBounds(272, 51, 149, 40);
		getContentPane().add(btnSearch_2);
		
		
		
		
		
		
		
		//Teacher
		JLabel lblTeacherId_2 = new JLabel("Teacher ID:");
		lblTeacherId_2.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblTeacherId_2.setBounds(10, 153, 89, 40);
		getContentPane().add(lblTeacherId_2);
		
		teacherField = new JTextField();
		teacherField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		teacherField.setColumns(10);
		teacherField.setBounds(109, 153, 153, 40);
		getContentPane().add(teacherField);
		
		JButton btnSearch_1 = new JButton("Search");
		btnSearch_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showDeputyTeacherScores(teacherField.getText());
			}
		});
		btnSearch_1.setFont(new Font("Traditional Arabic", Font.BOLD, 14));
		btnSearch_1.setBounds(272, 153, 149, 40);
		getContentPane().add(btnSearch_1);
		
		
		
		
		
		
		
		
		
		
		
		
		//Exit
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnNewButton.setBounds(617, 11, 89, 23);
		getContentPane().add(btnNewButton);
		
		JButton btnHomepage = new JButton("Homepage");
		btnHomepage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnHomepage.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnHomepage.setBounds(617, 51, 89, 23);
		getContentPane().add(btnHomepage);
		// TODO Auto-generated constructor stub
	}
	
	
	//TODO refresh ping
}

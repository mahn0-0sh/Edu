package teacher.deputy;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.PhaseController;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.awt.event.ActionEvent;

public class EditCourse extends JFrame {

	private JPanel contentPane;
	private JTextField pre;
	private JTextField con;
	private JTextField eDate;
	private JTextField eTime;
	private JTextField capacity;
	private JTextField cDay;
	private JTextField cTime;
	private PhaseController controller = new PhaseController();


	/**
	 * Create the frame.
	 */
	public EditCourse(String course_id) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 680, 380);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ArrayList<Integer> groups = controller.getGroups(course_id);
		
		JComboBox<Integer> comboBox = new JComboBox();
		for(int i : groups) {
			comboBox.addItem(i);
		}
		comboBox.setBounds(386, 42, 45, 22);
		contentPane.add(comboBox);
		
		pre = new JTextField();
		pre.setColumns(10);
		pre.setBounds(10, 43, 96, 20);
		contentPane.add(pre);
		
		JButton btnAddPre = new JButton("Add pre");
		btnAddPre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.editCourse("add_pre", course_id, pre.getText());
				
			}
		});
		btnAddPre.setBounds(116, 42, 89, 23);
		contentPane.add(btnAddPre);
		
		con = new JTextField();
		con.setColumns(10);
		con.setBounds(10, 75, 96, 20);
		contentPane.add(con);
		
		JButton btnAddCon = new JButton("Add con");
		btnAddCon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.editCourse("add_con", course_id, con.getText());
				
			}
		});
		btnAddCon.setBounds(116, 74, 89, 23);
		contentPane.add(btnAddCon);
		
		eDate = new JTextField();
		eDate.setColumns(10);
		eDate.setBounds(10, 107, 96, 20);
		contentPane.add(eDate);
		
		JButton btnExamDate = new JButton("Exam date");
		btnExamDate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.editCourse("e_date", course_id, eDate.getText());
				
			}
		});
		btnExamDate.setBounds(116, 106, 89, 23);
		contentPane.add(btnExamDate);
		
		eTime = new JTextField();
		eTime.setColumns(10);
		eTime.setBounds(10, 139, 96, 20);
		contentPane.add(eTime);
		
		JButton btnExamTime = new JButton("Exam time");
		btnExamTime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.editCourse("e_time", course_id, eTime.getText());
				
			}
		});
		btnExamTime.setBounds(116, 138, 89, 23);
		contentPane.add(btnExamTime);
		
		JLabel lblNewLabel = new JLabel("Group to change:");
		lblNewLabel.setBounds(280, 46, 96, 14);
		contentPane.add(lblNewLabel);
		
		
		capacity = new JTextField();
		capacity.setColumns(10);
		capacity.setBounds(280, 76, 96, 20);
		contentPane.add(capacity);
		
		JButton btnExamTime_1 = new JButton("Capacity");
		btnExamTime_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.editCourse("capacity", course_id, capacity.getText(), (Integer) comboBox.getSelectedItem());
				
			}
		});
		btnExamTime_1.setBounds(386, 75, 89, 23);
		contentPane.add(btnExamTime_1);
		
		cDay = new JTextField();
		cDay.setColumns(10);
		cDay.setBounds(280, 108, 96, 20);
		contentPane.add(cDay);
		
		JButton btnClassDay = new JButton("Class day");
		btnClassDay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.editCourse("c_day", course_id, cDay.getText(), (Integer) comboBox.getSelectedItem());
				
			}
		});
		btnClassDay.setBounds(386, 107, 89, 23);
		contentPane.add(btnClassDay);
		
		cTime = new JTextField();
		cTime.setColumns(10);
		cTime.setBounds(280, 140, 96, 20);
		contentPane.add(cTime);
		
		JButton btnClassTime = new JButton("Class time");
		btnClassTime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.editCourse("c_time", course_id, cTime.getText(), (Integer) comboBox.getSelectedItem());
				
			}
		});
		btnClassTime.setBounds(386, 139, 89, 23);
		contentPane.add(btnClassTime);
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.setBounds(567, 11, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnHome = new JButton("Home");
		btnHome.setBounds(468, 11, 89, 23);
		contentPane.add(btnHome);
	}

}

package teacher.deputy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import client.Client;
import enums.Departments;
import enums.getEnums;
import login.PhaseController;
import shared.model.*;
import teacher.TeacherMain;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JComboBox;

public class AddCourse extends JFrame {
	
	static Logger logger = LogManager.getLogger(AddCourse.class);
	
	private Color backColor, textMainColor, textColor;
	private JPanel contentPane;
	private JTextField credit, groups, id, name;
	private PhaseController controller = new PhaseController();
	private JComboBox comboBox;

	
	public AddCourse() {
		initPane();
		initConstants();
		textFields();
		registerBtn();		
		homeBtn();
		exitBtn();
	}
	
	public void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(backColor);
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}
	
	public void initConstants() {
		JLabel lblNewLabel = new JLabel("Name:");
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblNewLabel.setForeground(textMainColor);
		lblNewLabel.setBounds(10, 11, 49, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblId = new JLabel("ID:");
		lblId.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblId.setForeground(textMainColor);
		lblId.setBounds(10, 36, 49, 14);
		contentPane.add(lblId);
		
		JLabel lblTeacher = new JLabel("Groups:");
		lblTeacher.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblTeacher.setForeground(textMainColor);
		lblTeacher.setBounds(10, 61, 60, 14);
		contentPane.add(lblTeacher);
		
		JLabel lblDegree = new JLabel("Degree:");
		lblDegree.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblDegree.setForeground(textMainColor);
		lblDegree.setBounds(10, 86, 49, 14);
		contentPane.add(lblDegree);
		
		JLabel lblCredit = new JLabel("Credit:");
		lblCredit.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblCredit.setForeground(textMainColor);
		lblCredit.setBounds(10, 111, 49, 14);
		contentPane.add(lblCredit);
	}

	public void textFields() {
		credit = new JTextField();
		credit.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		credit.setColumns(10);
		credit.setBounds(105, 108, 96, 20);
		contentPane.add(credit);
		
		groups = new JTextField();
		groups.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		groups.setColumns(10);
		groups.setBounds(105, 58, 96, 20);
		contentPane.add(groups);
		
		id = new JTextField();
		id.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		id.setColumns(10);
		id.setBounds(105, 32, 96, 20);
		contentPane.add(id);
		
		String[] strings = {"BACHELOR", "MASTER", "DOCTORATE"};
		comboBox = new JComboBox(strings);
		comboBox.setBounds(105, 81, 96, 22);
		contentPane.add(comboBox);
		
		name = new JTextField();
		name.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		name.setColumns(10);
		name.setBounds(105, 8, 96, 20);
		contentPane.add(name);
	}

	public void registerBtn() {
		JButton btnNewButton = new JButton("Register course");
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					int groupp = Integer.parseInt(groups.getText());
					int creditt = Integer.parseInt(credit.getText());
					
					String response = controller.addNewCourse(id.getText(),
							name.getText(), groupp,
							(String) comboBox.getSelectedItem(), 
							creditt);
					JOptionPane.showMessageDialog(null, response);
					
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Invalid inputs");
				}
			}
		});
		btnNewButton.setBounds(10, 203, 191, 23);
		contentPane.add(btnNewButton);
		
	}

	public void exitBtn() {
		JButton btnNewButton_1_1 = new JButton("Exit");
		btnNewButton_1_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton_1_1.setBounds(412, 36, 89, 23);
		contentPane.add(btnNewButton_1_1);		
	}
	
	public void homeBtn() {
		JButton btnNewButton_1 = new JButton("Home page");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton_1.setBounds(412, 7, 89, 23);
		contentPane.add(btnNewButton_1);
	}

	public void refresh() {
		// no need
	}
}

package teacher;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;

import client.ConnectionStatus;
import constants.Constants;
import login.LogginWindow;
import login.PhaseController;
import resources.ProfilePic;
import shared.CoursesList;
import shared.TeachersList;
import shared.util.Config;
import teacher.deputy.AddNewStudent;
import teacher.deputy.AddNewTeacher;
import teacher.deputy.ChooseTime;
import teacher.deputy.DepEduStatus;
import teacher.deputy.DeputyTemperoryScores;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JButton;

public class TeacherMain extends JFrame {
	
	private JPanel contentPane;
	private JLabel nameLabel;
	private JLabel emailLabel;
	
	private JMenuBar menuBar;
	private PhaseController controller = new PhaseController();
	private String position;
	private JButton recBtn;
	private JLabel offLbl;
	
	
	public TeacherMain(String status) {
		position = controller.getPosition();
		
		initPane();
		String[] s = status.split("`");
		
		menuBar = new JMenuBar();
		menuBar.setBackground(new Color(230, 230, 250));
		setJMenuBar(menuBar);
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		
		initRegMenu();
		initSerMenu();
		initRecordMenu();
		initExtraMenu();
		initProMenu();
		initOfflineBtn();
		initExitBtn();
		
		
		
		//Labels
		JLabel currentTimeLbl = new JLabel();
		currentTimeLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		currentTimeLbl.setBounds(155, 15, 117, 14);
		contentPane.add(currentTimeLbl);
		Thread clock = new Thread()
		{
			public void run() {
				try {
					while(true) {
					LocalDateTime now2 = LocalDateTime.now(); 
					currentTimeLbl.setText(dtf.format(now2));
					sleep(1000);
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				};
		clock.start();		
		
		
		
		//Last visit
		JLabel lastVisitLbl = new JLabel(s[2]); //TODO
		lastVisitLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lastVisitLbl.setBounds(362, 15, 148, 14);
		contentPane.add(lastVisitLbl);
		
	/*	try {
			lastVisitLbl.setText(teachM.lastVisit);
		} catch (Exception e) {
			lastVisitLbl.setText("");
		} */
		
		nameLabel = new JLabel(s[0]);
		nameLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		nameLabel.setBounds(32, 164, 204, 14);
		contentPane.add(nameLabel);
		
		emailLabel = new JLabel(s[1]);
		emailLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		emailLabel.setBounds(32, 189, 204, 14);
		contentPane.add(emailLabel);
		
		JLabel picLbl = new JLabel(); //TODO
		picLbl.setBounds(10, 43, 100, 110);
		contentPane.add(picLbl);
		picLbl.setIcon(ProfilePic.pic);
	}
	
	
	//pane
	private void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}
	
	
	
	//btn
	private void initExitBtn() {
		JButton exitButton = new JButton("Exit");
		exitButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		exitButton.setBounds(10, 11, 89, 23);
		contentPane.add(exitButton); 
	}
	
	private void initOfflineBtn() {
		recBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "reconnect"));
		recBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.reconnect();
				
			}
		});
		recBtn.setBounds(721, 15, 125, 23);
		getContentPane().add(recBtn);
		recBtn.setVisible(false);
		
		offLbl = new JLabel(new Config(Constants.LABEL_TEXT).getProperty(String.class, "offline"));
		offLbl.setBounds(299, 352, 180, 14);
		getContentPane().add(offLbl);
		offLbl.setVisible(false);
		
		if(!ConnectionStatus.getStatus().isOnline()) {
			recBtn.setVisible(true);
			offLbl.setVisible(true);
		}
	}
	
	
	
	
	
	
	
	//menu
	private void initProMenu() {
		JMenu proMenu = new JMenu("Profile");
		proMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		menuBar.add(proMenu);
		
		JMenuItem proItem = new JMenuItem("Profile details");
		proItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		proItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showProfile();
			}
		});
		proMenu.add(proItem);
	}
	
	private void initRegMenu() {		
		JMenu regMenu = new JMenu("Registeration affairs");
		regMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		menuBar.add(regMenu);
		
		JMenuItem coursesItem = new JMenuItem("Courses List");
		coursesItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		coursesItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showCoursesList();
			}
		});
		regMenu.add(coursesItem);
		
		
		JMenuItem teachersItem = new JMenuItem("Teachers List");
		teachersItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		teachersItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showTeachersList();
			}
		});
		regMenu.add(teachersItem);
	}
	
	
	
	private void initSerMenu() {
		JMenu serMenu = new JMenu("Services");
		serMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		menuBar.add(serMenu);
		
		JMenuItem weekItem = new JMenuItem("Weekly schd");
		weekItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		weekItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showWeekSchd();
			}
		});
		serMenu.add(weekItem);
		
		JMenuItem examItem = new JMenuItem("Exam schd");
		examItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		examItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showExamSchd();
			}
		});
		serMenu.add(examItem);
		
		
		
		JMenuItem reqItem = new JMenuItem("Requests");
		reqItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		reqItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//TODO
			}
		});
		serMenu.add(reqItem);
	}
	
	
	
	private void initExtraMenu() {
		JMenu extraMenu = new JMenu("Extra");
		extraMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		menuBar.add(extraMenu);
		
		JMenuItem cwItem = new JMenuItem("CW");
		cwItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.showCWMain();
				
			}
		});
		cwItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		extraMenu.add(cwItem);
		
		JMenuItem chatItem = new JMenuItem("Chat");
		chatItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.showChatMain();
				
			}
		});
		chatItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		extraMenu.add(chatItem);
		
		JMenuItem msgItem = new JMenuItem("Messages");
		msgItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.showMsgMain();
				
			}
		});
		msgItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		extraMenu.add(msgItem);
	}
	
	
	
	private void initRecordMenu() {
		JMenu recMenu = new JMenu("Record affairs");
		recMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		menuBar.add(recMenu);
		
		JMenu menu2 = new JMenu("Register Scores");
		menu2.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		recMenu.add(menu2);
		
		
		
		try {
			LinkedList<String> courses = controller.getTeacherCourses();
			for(int i=0; i<courses.size(); i++) {
				String string = courses.get(i);
				JMenuItem item = new JMenuItem(courses.get(i));
				menu2.add(item);
				item.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
				item.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						controller.showRegScoresPage(string.split("\\s+")[0]);
					}
				});
			}
		} catch (Exception e) {
			// TODO: handle exception
			
		}
		
		if(position.equals("Deputy")) {
			JMenuItem eduItem = new JMenuItem("Educational status");
			eduItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controller.showDepEduStatus();
				}
			});
			eduItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
			recMenu.add(eduItem);
			
			
			JMenuItem tempItem = new JMenuItem("Temperory scores");
			tempItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controller.showDepTempScores();
				}
			});
			tempItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
			recMenu.add(tempItem);
			
			
			JMenu addMenu = new JMenu("Add/Edit");
			addMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
			menuBar.add(addMenu);
			
			JMenuItem stuItem = new JMenuItem("Student");
			stuItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
			stuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controller.showAddStudent();
				}
			});
			addMenu.add(stuItem);
			
			JMenuItem memberItem = new JMenuItem("Teacher");
			memberItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
			memberItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controller.showAddTeacher();
				}
			});
			addMenu.add(memberItem);
			
			JMenuItem chooseItem = new JMenuItem("Course choose time");
			chooseItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
			chooseItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					ChooseTime time = new ChooseTime();
					time.setVisible(true);
				}
			});
			addMenu.add(chooseItem);
		}
		
	}
	
	
	


	public void refresh() {
		String status = controller.mainPageStatus();
		if(status != null) {
			String[] s = status.split("`");
			nameLabel.setText(s[0]);
			emailLabel.setText(s[1]);	
		} else {
			System.out.println("going home");
			controller.visitHome();
		}
	}
		
		
}

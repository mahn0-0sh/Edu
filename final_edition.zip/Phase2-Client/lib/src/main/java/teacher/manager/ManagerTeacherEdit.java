package teacher.manager;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import enums.TeacherDegree;
import login.LogginWindow;
import login.PhaseController;
import teacher.TeacherMain;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

public class ManagerTeacherEdit extends JFrame {

	private JPanel contentPane;
	private JTextField roomField;
	TeacherDegree degree;
	private PhaseController controller = new PhaseController();

	public ManagerTeacherEdit(String teacher) {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
/*		JLabel lblNewLabel = new JLabel("Name:");
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		lblNewLabel.setBounds(10, 11, 97, 22);
		contentPane.add(lblNewLabel);
		
		JLabel nameLbl = new JLabel("");
		nameLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		nameLbl.setBounds(117, 11, 168, 22);
		contentPane.add(nameLbl); */
		
		JLabel lblRoom = new JLabel("Room:");
		lblRoom.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		lblRoom.setBounds(10, 44, 97, 22);
		contentPane.add(lblRoom);
		
		roomField = new JTextField();
		roomField.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		roomField.setBounds(117, 44, 168, 22);
		contentPane.add(roomField);
		roomField.setColumns(10);
		
		JLabel lblDegree = new JLabel("Degree:");
		lblDegree.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		lblDegree.setBounds(10, 77, 97, 22);
		contentPane.add(lblDegree);
		
/*		idField = new JTextField();
		idField.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		idField.setColumns(10);
		idField.setBounds(117, 110, 168, 22);
		contentPane.add(idField);
		
		JLabel lblRoom_2 = new JLabel("ID:");
		lblRoom_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		lblRoom_2.setBounds(10, 110, 97, 22);
		contentPane.add(lblRoom_2); */
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnNewButton.setBounds(538, 10, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnHomepage = new JButton("Homepage");
		btnHomepage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnHomepage.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnHomepage.setBounds(538, 43, 89, 23);
		contentPane.add(btnHomepage);
		
		
		//String[] degrees = {"OT","TA","OT"};
		TeacherDegree[] degrees = {TeacherDegree.OT,TeacherDegree.TA,TeacherDegree.DY};
		JComboBox comboBox = new JComboBox(degrees);
		comboBox.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == comboBox) {
					degree = (TeacherDegree) comboBox.getSelectedItem();
				}
			}
		});
		comboBox.setBounds(117, 77, 168, 22);
		contentPane.add(comboBox);
		
		
		
		JButton btnNewButton_1 = new JButton("Apply changes");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			/*	if(!roomField.getText().equals("")) {
					teacher.room = roomField.getText();
				}
                
				try {
				teacher.teacherDegree = degree;
				} catch (Exception e1) {
					// TODO: handle exception
				}
				
                if(!idField.getText().equals("")) {
					teacher.setID(idField.getText());
				} */
				controller.editTeacher(roomField.getText(), degree);
			}
		});
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton_1.setBounds(10, 166, 168, 23);
		contentPane.add(btnNewButton_1);
		
		
	}
}

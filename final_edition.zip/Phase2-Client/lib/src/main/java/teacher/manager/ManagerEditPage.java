package teacher.manager;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.LogginWindow;
import login.PhaseController;
import teacher.TeacherMain;
import teacher.deputy.AddNewTeacher;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ManagerEditPage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private PhaseController controller;

	
	public ManagerEditPage() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		//remove teacher
		textField = new JTextField();
		textField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		textField.setBounds(10, 11, 101, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Remove Teacher");
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.removeTeacher(textField.getText());
			}
		});
		btnNewButton.setBounds(121, 10, 147, 23);
		contentPane.add(btnNewButton);
		
		JButton btnEditTeacher = new JButton("Edit Teacher");
		btnEditTeacher.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnEditTeacher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showManagerTeacherEdit(textField.getText());
			}
		});
		btnEditTeacher.setBounds(121, 41, 147, 23);
		contentPane.add(btnEditTeacher);
		
		
		
		
		//add teacher
		JButton btnNewButton_1 = new JButton("Add new Teacher");
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showAddTeacher();
			}
		});
		btnNewButton_1.setBounds(121, 143, 147, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnSetAsDeputy = new JButton("Set as deputy");
		btnSetAsDeputy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.changeDeputy(textField.getText()); 
			}
		});
		btnSetAsDeputy.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnSetAsDeputy.setBounds(121, 75, 147, 23);
		contentPane.add(btnSetAsDeputy);
		
		
		
		
		
		//Exit
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton_2.setBounds(590, 10, 89, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("Homepage");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton_2_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton_2_1.setBounds(590, 42, 89, 23);
		contentPane.add(btnNewButton_2_1);
	}
}

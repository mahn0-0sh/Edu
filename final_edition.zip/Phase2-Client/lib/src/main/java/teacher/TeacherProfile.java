package teacher;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import client.ConnectionStatus;
import login.LogginWindow;
import login.PhaseController;
import resources.ProfilePic;

import javax.swing.JTextField;

public class TeacherProfile extends JFrame {

	private JPanel contentPane;
	private JTextField phoneField;
	private JTextField emailField;	
	private Logger logger = LogManager.getLogger(TeacherProfile.class);
	private PhaseController controller = new PhaseController();
	private JLabel nameLbl, codeLbl, idLbl, phoneLbl, emailLbl, depLbl, roomLbl, degreeLbl;


	public TeacherProfile(String status) {	
		String[] s = status.split("/");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton exitButton = new JButton("Exit");
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		exitButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		exitButton.setBounds(10, 11, 89, 23);
		contentPane.add(exitButton);
		
		JLabel lblNewLabel = new JLabel("Full Name:");
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel.setBounds(10, 69, 81, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblCode = new JLabel("Code:");
		lblCode.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblCode.setBounds(10, 94, 81, 14);
		contentPane.add(lblCode);
		
		JLabel lblNewLabel_1_1 = new JLabel("ID:");
		lblNewLabel_1_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1_1.setBounds(10, 119, 81, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("Phone number:");
		lblNewLabel_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(368, 69, 105, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Email:");
		lblNewLabel_1_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1_2.setBounds(368, 94, 105, 14);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Department:");
		lblNewLabel_1_2_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1_2_1.setBounds(368, 121, 105, 14);
		contentPane.add(lblNewLabel_1_2_1);
		
		nameLbl = new JLabel(s[0]);
		nameLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		nameLbl.setBounds(101, 69, 192, 14);
		contentPane.add(nameLbl);
		
		codeLbl = new JLabel(s[1]);
		codeLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		codeLbl.setBounds(101, 94, 192, 14);
		contentPane.add(codeLbl);
		
		idLbl = new JLabel(s[2]);
		idLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		idLbl.setBounds(101, 119, 192, 14);
		contentPane.add(idLbl);
		
		phoneLbl = new JLabel(s[3]);
		phoneLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		phoneLbl.setBounds(472, 69, 192, 14);
		contentPane.add(phoneLbl);
		
		emailLbl = new JLabel(s[4]);
		emailLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		emailLbl.setBounds(472, 95, 192, 14);
		contentPane.add(emailLbl);
		
		depLbl = new JLabel(s[5]);
		depLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		depLbl.setBounds(472, 122, 192, 14);
		contentPane.add(depLbl);
		
		JButton homepageButton = new JButton("Home page");
		homepageButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		homepageButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		homepageButton.setBounds(529, 11, 145, 23);
		contentPane.add(homepageButton);
		
		JLabel rLabel = new JLabel("Room:");
		rLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		rLabel.setBounds(10, 144, 81, 14);
		contentPane.add(rLabel);
		
		JLabel dLabel = new JLabel("Degree:");
		dLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		dLabel.setBounds(368, 147, 105, 14);
		contentPane.add(dLabel);
		
		
		roomLbl = new JLabel(s[6]);
		roomLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		roomLbl.setBounds(101, 144, 192, 14);
		contentPane.add(roomLbl);
		
		degreeLbl = new JLabel(s[7]);
		degreeLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		degreeLbl.setBounds(472, 147, 192, 14);
		contentPane.add(degreeLbl);
		
		
		JLabel picLbl = new JLabel();
		picLbl.setBounds(229, 11, 105, 124);
		contentPane.add(picLbl);
		picLbl.setIcon(ProfilePic.pic);
		
		
		
		
		if(ConnectionStatus.getStatus().isOnline()) {
			JButton btnNewButton = new JButton("Change phone number");
			btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controller.changeData(phoneField.getText(), "phone");
				}
			});
			btnNewButton.setBounds(205, 197, 185, 23);
			contentPane.add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("Change email address");
			btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					controller.changeData(emailField.getText(), "email");
				}
			});
			btnNewButton_1.setBounds(205, 231, 185, 23);
			contentPane.add(btnNewButton_1);
			
			phoneField = new JTextField();
			phoneField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
			phoneField.setBounds(10, 198, 185, 20);
			contentPane.add(phoneField);
			phoneField.setColumns(10);
			
			emailField = new JTextField();
			emailField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
			emailField.setColumns(10);
			emailField.setBounds(10, 232, 185, 20);
			contentPane.add(emailField);
		}
		
	}


	public void refresh() {
		String status = controller.getProfileStatus();
		if(status != null) {
			String[] s = status.split("/");
			nameLbl.setText(s[0]);
			codeLbl.setText(s[1]);
			idLbl.setText(s[2]);
			phoneLbl.setText(s[3]);
			emailLbl.setText(s[4]);
			depLbl.setText(s[5]);
			roomLbl.setText(s[6]);
			degreeLbl.setText(s[7]);
		} else {
			controller.visitHome();
		}
	}

}

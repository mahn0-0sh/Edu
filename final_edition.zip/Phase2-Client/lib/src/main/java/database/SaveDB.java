package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;

import com.google.gson.Gson;

import enums.StudentDegree;
import shared.model.Chat;
import shared.model.Message;
import shared.model.MiniCourse;
import shared.model.Person;
import shared.model.Student;
import shared.model.Teacher;
import shared.util.EnumUtil;
import shared.util.ListUtil;

public class SaveDB {
	
	private static Connection connection;
	static SaveDB db;
	
	public static SaveDB getDB()
    {
        if (db == null)
        {
            db = new SaveDB();
        }
        return db;
    }

	public static void setConnection(Connection connection) {
		SaveDB.connection = connection;
	}
	
	
	
	
	 public boolean rowIsMissing(String table, String id) throws SQLException
	    {
	        String query = "";
	        switch (table)
	        {
	            case "persons":
	                query = "SELECT 1 FROM `persons` WHERE `id` = ?";
	                break;
	            case "students":
	                query = "SELECT 1 FROM `students` WHERE `id` = ?";
	                break;
	            case "teachers":
	                query = "SELECT 1 FROM `teachers` WHERE `id` = ?";
	                break;
	            case "courses":
	                query = "SELECT 1 FROM `courses` WHERE `id` = ?";
	                break;
	            case "minicourses":
	                query = "SELECT 1 FROM `minicourses` WHERE `mini_id` = ?";
	                break;
	        /*    case "messages":
	                query = "SELECT 1 FROM `messages` WHERE `id` = ?";
	                break;
	            case "notifications":
	                query = "SELECT 1 FROM `notifications` WHERE `id` = ?";
	                break; */
	        }
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setString(1, id);
	        ResultSet res = statement.executeQuery();
	        boolean ans = !res.next();
	        statement.close();
	        res.close();
	        return ans;
	    }
	 
	 
	 public boolean rowIsMissing(String table, String mini_id, String id) throws SQLException
	    {
	        String query = "";
	        switch (table)
	        {
	            case "stu_course":
	                query = "SELECT 1 FROM `stu_course` WHERE `student_id` = ? AND `course_id` = ?";
	                break;
	            case "teacher_course":
	                query = "SELECT 1 FROM `teacher_course` WHERE `teacher` = ?";
	                break;
	        }
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setString(1, id);
	        if(!mini_id.equals("")) statement.setString(2, mini_id);
	        ResultSet res = statement.executeQuery();
	        boolean ans = !res.next();
	        statement.close();
	        res.close();
	        return ans;
	    }
	    
	    public boolean rowExists(String table, int id) throws SQLException
	    {
	        String query = "";
	        switch (table)
	        {
	            case "chats":
	                query = "SELECT 1 FROM `chats` WHERE `id` = ?";
	                break;
	            case "messages":
	                query = "SELECT 1 FROM `messages` WHERE `id` = ?";
	                break;
	            case "exercises":
	                query = "SELECT 1 FROM `exercises` WHERE `id` = ?";
	                break;
	            case "medias":
	                query = "SELECT 1 FROM `medias` WHERE `id` = ?";
	                break;
	            case "subjects":
	                query = "SELECT 1 FROM `subjects` WHERE `id` = ?";
	                break;
	            case "items":
	                query = "SELECT 1 FROM `items` WHERE `id` = ?";
	                break;
	            case "requests":
	                query = "SELECT 1 FROM `requests` WHERE `id` = ?";
	                break;
	            case "ancs":
	                query = "SELECT 1 FROM `ancs` WHERE `id` = ?";
	                break;
	        }
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setInt(1, id);
	        ResultSet res = statement.executeQuery();
	        boolean ans = res.next();
	        statement.close();
	        res.close();
	        return ans;
	    }
	    
	    
	  /*  public ArrayList<Course> getDepCourseWithGroup(String dep) throws SQLException {
	    	String query = "";
	    	query = "SELECT `name`, `id`, `degree`, `credit` FROM `courses` WHERE `department` = ?";
	                
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setString(1, dep);
	        ResultSet res = statement.executeQuery();
	        
	        ArrayList<Course> courseList = new ArrayList<>();
	        while(res.next()) {
	        	courseList.add(loadCourse(res.getString("id")));
	        }
	        statement.close();
	        res.close();
	        return courseList;
		} */
	    
	    
	    public boolean userExists(String table, String username) throws SQLException
	    {
	        String query = "";
	        switch (table)
	        {
	            case "persons":
	                query = "SELECT 1 FROM `persons` WHERE `username` = ?";
	                break;
	            case "students":
	                query = "SELECT 1 FROM `students` WHERE `username` = ?";
	                break;
	            case "teachers":
	                query = "SELECT 1 FROM `teachers` WHERE `username` = ?";
	                break;
	        }
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setString(1, username);
	        ResultSet res = statement.executeQuery();
	        boolean ans = !res.next();
	        statement.close();
	        res.close();
	        return ans;
	    }
	    
	    
	    
	    
	    
	    
	    public Person savePerson(Person user) throws SQLException
	    {
	        boolean exists = ! rowIsMissing("persons", user.getID());

	        PreparedStatement statement;
	        if (exists)
	        {
	            statement = connection.prepareStatement(
	                    "UPDATE `persons` SET `username` = ?, `password` = ?, `position` = ?, `first_name` = ?, `last_name` = ?,"
	                    + " `email` = ?, `code` = ?, `phone_number` = ?, `last_exit` = ?, "
	                    + "`last_visit` = ?, `last_pass` = ?, `base64` = ? WHERE `id` = ?");
	        }
	        else
	        {
	            statement = connection.prepareStatement(
	                    "INSERT INTO `persons` (`username`, `password`, `position`, `first_name`, `last_name`, `email`, "
	                    + "`code`, `phone_number`, `last_exit`, `last_visit`, "
	                    + "`last_pass`, `base64`, `id`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	        }
	        statement.setString(1, user.getUsername());
	        statement.setString(2, user.getPassword());
	        statement.setString(3, user.getPosition());
	        statement.setString(4, user.getFirstName());
	        statement.setString(5, user.getLastName());
	        statement.setString(6, user.getEmail());
	        statement.setString(7, user.getCode());
	        statement.setString(8, user.getPhoneNumber());
	        statement.setString(9, user.getLastExit());
	        statement.setString(10, user.getLastVisit());
	        statement.setString(11, user.getLastPassChange());
	        statement.setString(12, user.getBase64());
	        
	        statement.setString(13, user.getID());
	        statement.executeUpdate();
	        statement.close();
	        
	        PreparedStatement statement1 = connection.prepareStatement("SELECT * FROM `persons` WHERE `id` = ?");
	        statement1.setString(1, user.getID());
	        ResultSet res1 = statement1.executeQuery();
	        return LoadDB.getDB().extractPerson(res1);
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	   
	    
	    public Student saveStudent(Student student) throws SQLException
	    {
	    	Person person = savePerson(student);
	        boolean exists = ! rowIsMissing("students", student.getID());

	        PreparedStatement statement;
	        if (exists)
	        {
	            statement = connection.prepareStatement(
	                    "UPDATE `students` SET `stu_degree` = ?, "
	                    + "`status` = ?, `department` = ?, `year` = ?, `mojavez` = ?, `sign_up` = ?, "
	                    + "`supervisor` = ?"
	                    + " WHERE `id` = ?");
	        }
	        else
	        {
	            statement = connection.prepareStatement(
	                    "INSERT INTO `students` (`stu_degree`, `status`, `department`, `year`, `mojavez`, "
	                    + "`sign_up`, `supervisor`, `id`) "
	            		+"VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
	        }
	        statement.setString(1, new Gson().toJson(student.getDegree()));
	        statement.setString(2, new Gson().toJson(student.getStatus()));
	        statement.setString(3, student.getDepartment());
	        statement.setString(4, student.getYearOfArrival());
	        statement.setString(5, student.getMojavez());
	        statement.setString(6, student.getSignUpTime());
	        statement.setString(7, student.getSupervisor());
	        
	        statement.setString(8, student.getID());
	        statement.executeUpdate();
	        statement.close();
	        return LoadDB.getDB().loadStudent(student.getID());
	    }
	    
	    
	    
	    
	    public Teacher saveTeacher(Teacher teacher) throws SQLException
	    {
	    	Person person = savePerson(teacher);
	        boolean exists = ! rowIsMissing("teachers", teacher.getID());

	        PreparedStatement statement;
	        if (exists)
	        {
	            statement = connection.prepareStatement(
	                    "UPDATE `teachers` SET `teach_degree` = ?, `room` = ?, `department` = ?"
	                    + " WHERE `id` = ?");
	        }
	        else
	        {
	            statement = connection.prepareStatement(
	                    "INSERT INTO `teachers` (`teach_degree`, `room`, `department`, `id`) VALUES (?, ?, ?, ?)");
	        }
	        statement.setString(1, new Gson().toJson(teacher.getTeacherDegree()));
	        statement.setString(2, teacher.getRoom());
	        statement.setString(3, teacher.getDepartment());
	        
	        statement.setString(4, teacher.getID());
	        statement.executeUpdate();
	        statement.close();
	        return LoadDB.getDB().loadTeacher(teacher.getID());
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    public void updateJoiningTable(MiniCourse course, String stu_stat) throws SQLException
	    {
	    
	    	String[] s = stu_stat.split("`");
	        boolean exists = ! rowIsMissing("stu_course", course.getMiniCourseID(), s[0]); //stu_id

	        PreparedStatement statement;
	        if (exists)
	        {
	            statement = connection.prepareStatement(
	                    "UPDATE `stu_course` SET `taken` = ?, `score` = ?, "
	            		+"`passed` = ?, `score_stat` = ?, `e_date` = ?, `e_time` = ?, "
	                    + "`c_day` = ?, `c_time` = ?, `name` = ?, `credit` = ?  "
	                    + "WHERE `student_id` = ? AND `course_id` = ?");
	        }
	        else
	        {
	        	statement = connection.prepareStatement(
	                    "INSERT INTO `stu_course` (`taken`, `score`, `passed`, `score_stat`, "
	        			+"`e_date`, `e_time`, `c_day`, `c_time`, "
	            		+"`name`, `credit`, `student_id`, `course_id`)"
	            		+"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	        }
	        boolean taken = false; if(s[1].equals("true")) taken = true;
	        statement.setBoolean(1, taken); //taken
	        
	        Double db = Double.parseDouble(s[2]); //scr
	        statement.setDouble(2, db);
	        
	        boolean passed = false; if(s[3].equals("true")) passed = true; //passed
	        statement.setBoolean(3, passed);
	        
	        statement.setString(4, s[4]); //stat
	        statement.setString(5, course.getExamDate());
	        statement.setString(6, course.getExamTime()); 
	        statement.setString(7, course.getClassDay());
	        statement.setString(8, course.getClassTime()); 
	        statement.setString(9, course.getName()); 
	        statement.setInt(10, course.getCourseCredit());
	        
	        statement.setString(11, s[0]);	       
	        statement.setString(12, course.getMiniCourseID());
	        statement.executeUpdate();
	        statement.close();
	    }
	    
	    
	    
	    public void updateChatTable(Chat chat, String json) throws SQLException
	    {
	    
	        boolean exists = rowExists("chats", chat.getId()); //stu_id

	        PreparedStatement statement;
	        if (exists)
	        {
	            statement = connection.prepareStatement(
	                    "UPDATE `chats` SET `messages` = ?, `name` = ?, `user_one` = ?, `user_two` = ?, `time` = ? WHERE `id` = ?");
	        }
	        else
	        {
	        	statement = connection.prepareStatement(
	                    "INSERT INTO `chats` (`messages`, `name`, `user_one`, `user_two`, `time`, `id`) " 
	            		+"VALUES (?, ?, ?, ?, ?, ?)");
	        }
	        
	        statement.setString(1, json); //stat
	        statement.setString(2, chat.getName());
	        statement.setString(3, chat.getUser_one()); 
	        statement.setString(4, chat.getUser_two());
	        statement.setString(5, chat.getLastTime()); 
	        statement.setInt(6, chat.getId()); 
	        
	        
	        statement.executeUpdate();
	        statement.close();
	    }
	    
	    
	    public void updateAdminChatTable(String sender_id, Message message) throws SQLException
	    {
	        PreparedStatement statement;
	        statement = connection.prepareStatement(
	                    "INSERT INTO `admin_chats` (`sender_id`, `message`) " 
	            		+"VALUES (?, ?)");
	        
	        statement.setString(1, sender_id); 
	        statement.setString(2, new Gson().toJson(message));
	        
	        statement.executeUpdate();
	        statement.close();
	    }

		public void updateTeacherCourseTable(String id, LinkedList<MiniCourse> courses) throws SQLException {
			boolean exists = ! rowIsMissing("teacher_course", "", id); //stu_id

	        PreparedStatement statement;
	        if (exists)
	        {
	            statement = connection.prepareStatement(
	                    "UPDATE `teacher_course` SET `courses` = ? "
	                    + "WHERE `teacher` = ?");
	        }
	        else
	        {
	        	statement = connection.prepareStatement(
	                    "INSERT INTO `teacher_course` (`courses`, `teacher`) "
	            		+"VALUES (?, ?)");
	        }
	        statement.setString(1, new Gson().toJson(courses));
	        statement.setString(2, id);
	        
	        statement.executeUpdate();
	        statement.close();
		}

		public void deleteMessages(String id) throws SQLException {
			PreparedStatement statement;
	        statement = connection.prepareStatement(
	                    "DELETE FROM `admin_chats` WHERE `sender_id` = ?");
	        statement.setString(1, id);
	        
	        statement.executeUpdate();
	        statement.close();
		}

	    
	    
	    
	    

}

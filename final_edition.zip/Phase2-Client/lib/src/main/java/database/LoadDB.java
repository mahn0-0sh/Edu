package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

import com.google.gson.Gson;

import enums.StudentDegree;
import shared.model.Chat;
import shared.model.Message;
import shared.model.MiniCourse;
import shared.model.Person;
import shared.model.Student;
import shared.model.Teacher;
import shared.util.EnumUtil;
import shared.util.ListUtil;

public class LoadDB {
	
	private static Connection connection;

    // Singleton class stuff
	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

    static LoadDB db;

    private LoadDB() {}
    
    public static LoadDB getDB()
    {
        if (db == null)
        {
            db = new LoadDB();
        }
        return db;
    }

 // Establish connection to the database
    public void connectToDatabase(String url, String username, String password) throws SQLException
    {
        connection = DriverManager.getConnection(url, username, password);
        Statement statement = connection.createStatement();
        statement.setQueryTimeout(30);
        statement.close();
        
        SaveDB.setConnection(connection);
    }
    
 // Find out if there exists a row with given id in a table
    public boolean rowIsMissing(String table, String id) throws SQLException
    {
        if (id.equals("-"))
        {
            return true;
        }

        String query = "";
        switch (table)
        {
            case "persons":
                query = "SELECT 1 FROM `persons` WHERE `id` = ?";
                break;
            case "students":
                query = "SELECT 1 FROM `students` WHERE `id` = ?";
                break;
            case "teachers":
                query = "SELECT 1 FROM `teachers` WHERE `id` = ?";
                break;
            case "courses":
                query = "SELECT 1 FROM `courses` WHERE `id` = ?";
                break;
            case "minicourses":
                query = "SELECT 1 FROM `minicourses` WHERE `mini_id` = ?";
                break;
        }
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        boolean ans = !res.next();
        statement.close();
        res.close();
        return ans;
    }
    
    public boolean rowExists(String table, int id) throws SQLException
    {
        String query = "";
        switch (table)
        {
            case "chats":
                query = "SELECT 1 FROM `chats` WHERE `id` = ?";
                break;
            case "messages":
                query = "SELECT 1 FROM `messages` WHERE `id` = ?";
                break;
        }
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        boolean ans = res.next();
        statement.close();
        res.close();
        return ans;
    }
    

    
   
    public String getPosition(String username) throws SQLException {
    	String query = "";
        query = "SELECT `position` FROM `persons` WHERE `username` = ?";
                
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, username);
        ResultSet res = statement.executeQuery();
        
        res.next();
        String position = res.getString("position");
        statement.close();
        res.close();
        return position;
	}
    
    
    public String getSupervisorName(Student student) throws SQLException {
    	String query = "";
        query = "SELECT `first_name`, `last_name` FROM `students` INNER JOIN `persons` WHERE `username` = ?";
                
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, student.getSupervisor());
        ResultSet res = statement.executeQuery();
        
        res.next();
        String name = res.getString("first_name")+" "+res.getString("last_name");
        statement.close();
        res.close();
        return name;
	}
    
    
    
    
    
    public boolean userExists(String table, String username) throws SQLException
    {
        String query = "";
        switch (table)
        {
            case "persons":
                query = "SELECT 1 FROM `persons` WHERE `username` = ?";
                break;
            case "students":
                query = "SELECT 1 FROM `students` WHERE `username` = ?";
                break;
            case "teachers":
                query = "SELECT 1 FROM `teachers` WHERE `username` = ?";
                break;
        }
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, username);
        ResultSet res = statement.executeQuery();
        boolean ans = !res.next();
        statement.close();
        res.close();
        return ans;
    }
    
    
    public Person extractPerson(ResultSet res) throws SQLException {
    	Person user = new Person();
        while (res.next())
        {
            user.setID(res.getString("id"));
            user.setUsername(res.getString("username"));
            user.setPassword(res.getString("password"));
            user.setPosition(res.getString("position"));
            user.setFirstName(res.getString("first_name"));
            user.setLastName(res.getString("last_name"));
            user.setEmail(res.getString("email"));
            user.setCode(res.getString("code"));
            user.setPhoneNumber(res.getString("phone_number"));
            user.setLastExit(res.getString("last_exit"));
            user.setLastVisit(res.getString("last_visit"));
            user.setLastPassChange(res.getString("last_pass"));
            user.setBase64(res.getString("base64"));
        }
        if(user.getPosition().equals("Student")) {
        	user = new Student(user.getPosition(), user.getUsername(), user.getPassword(), user.getFirstName(), user.getLastName(),
        			user.getEmail(), user.getCode(), user.getID(), user.getCode(), user.getLastVisit(), user.getLastExit(), user.getLastPassChange());
        }
        else {
        	user = new Teacher(user.getPosition(), user.getUsername(), user.getPassword(), user.getFirstName(), user.getLastName(),
        			user.getEmail(), user.getCode(), user.getID(), user.getCode(), user.getLastVisit(), user.getLastExit(), user.getLastPassChange());
        }
        
        return user;
    }
    
   
    
    
    
    
    
    
    
    public Student extractStudent(ResultSet res, String id) throws SQLException
    {
    	 PreparedStatement statement = connection.prepareStatement("SELECT * FROM `persons` WHERE `id` = ?");
         statement.setString(1, id);
         ResultSet res1 = statement.executeQuery();
         
        Student user = (Student) extractPerson(res1);
        while (res.next())
        {
            
            user.setDegree(EnumUtil.JsonToStuDegree(res.getString("stu_degree")));
            user.setStatus(EnumUtil.JsonToStatus(res.getString("status")));
            user.setDepartment(res.getString("department"));            
            
            user.setYearOfArrival(res.getString("year"));
            user.setMojavez(res.getString("mojavez"));
            user.setSignUpTime(res.getString("sign_up"));
            
            user.setSupervisor(res.getString("supervisor"));
        }
        return user;
    }

    public Student loadStudent(String id) throws SQLException
    {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `students` WHERE `id` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        Student student = extractStudent(res, id);
        statement.close();
        res.close();
        return student;
    }
    
    
    
    
    
    public Teacher extractTeacher(ResultSet res, String id) throws SQLException {
    	PreparedStatement statement = connection.prepareStatement("SELECT * FROM `persons` WHERE `id` = ?");
        statement.setString(1, id);
        ResultSet res1 = statement.executeQuery();
        
       Teacher user = (Teacher) extractPerson(res1); //TODO error?
       while (res.next())
       {
           user.setTeacherDegree(EnumUtil.JsonToTeachDegree(res.getString("teach_degree")));
           user.setDepartment(res.getString("department"));  
           user.setRoom(res.getString("room"));
       }
       return user;
	}
    
    public Teacher loadTeacher(String id) throws SQLException
    {
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM `teachers` WHERE `id` = ?");
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        Teacher teacher = extractTeacher(res, id);
        statement.close();
        res.close();
        return teacher;
    }
    
    
    
    
    
    
    
    
    
    
    
    //schd
    public LinkedList<String> getWeekSchd(String id) throws SQLException {
		String pos = getPosition(id);
		LinkedList<String> schd = new LinkedList<>();
		String query = "";
		
		if(pos.equals("Student")) query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1";
		else query = "SELECT * FROM `teacher_course` WHERE `teacher` = ?"; //TODO teacher_course
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        
        	while (res.next())
            {
        		if(pos.equals("Student"))
            	schd.add(res.getString("name")+"                                         "+res.getString("c_day")
            	+"                     "+
        		res.getString("c_time"));
        		
        		else {
        			LinkedList<MiniCourse> courses = ListUtil.JsonToListCourses(res.getString("courses"));
        			for(MiniCourse course : courses) {
        				schd.add(course.getName()+"                                         "+course.getClassDay()
                    	+"                     "+
                		course.getClassTime());
        			}
        		}
            }
        
       
        statement.close();
        res.close();
        return schd;
	}
    
    
    
    public LinkedList<String> getExamSchd(String id) throws SQLException {
		String pos = getPosition(id);
		LinkedList<String> schd = new LinkedList<>();
		String query = "";
		
		if(pos.equals("Student")) query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1";
		else query = "SELECT * FROM `teacher_course` WHERE `teacher` = ?"; 
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        
        	while (res.next()) {
        		if(pos.equals("Student"))
        			schd.add(res.getString("name")+"   "+res.getString("e_date")+"   "+res.getString("e_time"));
        		
        		else {
        			LinkedList<MiniCourse> courses = ListUtil.JsonToListCourses(res.getString("courses"));
        			for(MiniCourse course : courses) {
        				schd.add(course.getName()+"                                         "+course.courseExam());
        			}
        		}
            }
        
       
        statement.close();
        res.close();
        return schd;
	}
    
    
    
    
    
	
	
	
	
	
  
	
	
	
	//edu
	public LinkedList<String> getFullScores(String id) throws SQLException {
		LinkedList<String> list = new LinkedList<>();
		LinkedList<Double> sc_list = new LinkedList<>();
		String query = "";
		
		query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1";
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        
        	while (res.next())
            {
        		String score = "N/A";
        		if(res.getString("score_stat").equals("Reg")) {
        			sc_list.add(res.getDouble("score"));
        			score = res.getDouble("score")+"";
        		}
        		list.add(res.getString("course_id")+"   Score: "+score);
            }
        
       
        statement.close();
        res.close();
        return list;
	}
	
	
	public Double getGPA(String id) throws SQLException {
		String query = "";
		
		query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1 AND `score_stat` = 'Reg'";
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        Double scoreSum = 0.0;
        int credits = 0;
        
        	while (res.next())
            {
        		int credit = res.getInt("credit");
        		credits += credit;
        		Double scr = res.getDouble("score");
        		scoreSum += scr*credit;
            }
        Double gpa = scoreSum/credits;
       
        statement.close();
        res.close();
        return gpa;
	}
	
	
	public int passedCredits(String id) throws SQLException {
		String query = "";
		
		query = "SELECT * FROM `stu_course` WHERE `student_id` = ? AND `taken` = 1 AND `passed` = 1";
		
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        int credits = 0;
        
        	while (res.next())
            {
        		int credit = res.getInt("credit");
        		credits += credit;
            }
       
        statement.close();
        res.close();
        return credits;
	}

    
	
	
	
	
	
	
	
	
	
	
	//chat
	public LinkedList<String> getMyChats(String id) throws SQLException {
		LinkedList<String> myChats = new LinkedList<>();
		
		String query = "SELECT * FROM `chats` WHERE `user_one`=? OR `user_two`=? ORDER BY `time` DESC";
		PreparedStatement statement = connection.prepareStatement(query);
		statement.setString(1, id);
		statement.setString(2, id);
        ResultSet res = statement.executeQuery();
        
        while (res.next()) {
        	String other_id = res.getString("user_two");
        	if(other_id.equals(id)) other_id = res.getString("user_one");
        	
        	String status = "";
        	LinkedList<Message> messages = ListUtil.JsonToListMessage(res.getString("messages"));
        	Message message = getLastMessage(messages);
        	
        	if(message != null) {
    			try {
    				String text = message.getText().split(":")[1];
    				status += other_id+": ";
    				status += text;
    			} catch (Exception e) {
    				status += other_id+": ";
    				status += message.getText();
    			}
    		} else {
    			status += other_id+": ";
    		}
        	
        	myChats.add(status);
		}
        statement.close();
        res.close();
        
        return myChats;
	}
   
    
    private Message getLastMessage(LinkedList<Message> messages) {
    	try {
    		if(messages.size()>0) {
    			Collections.sort(messages, new Comparator<Message>() {

    				@Override
    				public int compare(Message o1, Message o2) {
    					return -o1.getTimeSent().compareTo(o2.getTimeSent());
    				}
    	    		
    			});   
    			return messages.get(0);    		    
    		} else {
				return null;
			}
		} catch (Exception e) {
			return null;
		}
    }
    
    
	public ArrayList<Message> getMessages(int id) throws SQLException {
		ArrayList<Message> messages = new ArrayList<>();
		
		String query = "SELECT * FROM `chats` WHERE `id`=?";
		PreparedStatement statement = connection.prepareStatement(query);
		statement.setInt(1, id);
        ResultSet res = statement.executeQuery();
        
        while (res.next()) {
        	LinkedList<Message> messagesLinkedList = ListUtil.JsonToListMessage(res.getString("messages"));
        	Collections.sort(messages, new Comparator<Message>() {

				@Override
				public int compare(Message o1, Message o2) {
					return -o1.getTimeSent().compareTo(o2.getTimeSent());
				}
	    		
			});
        	messages = new ArrayList<>(messagesLinkedList);
		}
        statement.close();
        res.close();
        
        return messages;
	}

	public int getChatId(String id, String other_id) throws SQLException {
		String query = "SELECT * FROM `chats` WHERE (`user_one`=? AND `user_two`=?) OR (`user_one`=? AND `user_two`=?)";
		PreparedStatement statement = connection.prepareStatement(query);
		statement.setString(1, id);
		statement.setString(2, other_id);
		statement.setString(3, other_id);
		statement.setString(4, id);
        ResultSet res = statement.executeQuery();
        int chat_id = 0;
        
        while (res.next()) {
        	chat_id = res.getInt("id");
		}
        statement.close();
        res.close();
        return chat_id;
	}

	public LinkedList<Message> getAdminMessages(String id) throws SQLException {
		LinkedList<Message> messages = new LinkedList<>();
		String query = "SELECT * FROM `admin_chats` WHERE `sender_id`=?";
		PreparedStatement statement = connection.prepareStatement(query);
		statement.setString(1, id);
        ResultSet res = statement.executeQuery();
        
        while (res.next()) {
        	messages.add(ListUtil.getMessage(res.getString("message")));
		}
        statement.close();
        res.close();
        return messages;
	}
    
    
    

}

package interfaces;

public interface Listener {

	void listen(String string);
	
}

package extra_roles.admin.view;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import chat.ChatController;

import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.LinkedList;
import java.awt.event.ActionEvent;

public class AdminChat extends JFrame {

	private JPanel contentPane;
	private ChatController controller = new ChatController();
	private JList<String> list;

	

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public AdminChat() throws SQLException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		panel.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		list = new JList();
		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 2) {
					String id = controller.getClientId();
					String other_id = list.getSelectedValue().split(":")[0];
					int chatId = controller.getChatId(id, other_id);
					controller.goToChatRoom(chatId, id, other_id);
				}				
			}
		});
		scrollPane.setViewportView(list);
		setModel(controller.getMyCurrentChats());
	}
	
	
	private void setModel(LinkedList<String> linkedList) {
		DefaultListModel<String> dListModel = new DefaultListModel<>();
		if(linkedList != null) {
			for(String string : linkedList) {
				dListModel.addElement(string);
			}
			list.setModel(dListModel);
		} else {
			controller.visitHome();
		}
	}
	
	public void refresh() {
		try {
			setModel(controller.getMyCurrentChats());
		} catch (Exception e) {
			// TODO: handle exception
		}
	}


}

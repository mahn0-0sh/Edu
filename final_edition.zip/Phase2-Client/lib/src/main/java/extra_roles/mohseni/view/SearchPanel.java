package extra_roles.mohseni.view;

import javax.swing.JPanel;
import javax.swing.JTextField;

import extra_roles.mohseni.MohseniController;

import javax.swing.JScrollPane;

import java.util.LinkedList;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class SearchPanel extends JPanel {
	
	private JTextField textField;
	private JList<String> list;
	private DefaultListModel<String> model = new DefaultListModel<>();
	private LinkedList<String> infos;
	private MohseniController controller = new MohseniController();

	/**
	 * Create the panel.
	 */
	public SearchPanel() {
		
		setLayout(null);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				searchFilter(textField.getText());
			}
		});
		textField.setBounds(180, 11, 96, 20);
		add(textField);
		textField.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 40, 430, 249);
		add(scrollPane);
		
		list = new JList<String>();
		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 2) {
					String id = list.getSelectedValue().split("\\s+")[0];
					
					String status = controller.getProfileStatus(id);
					String base64 = controller.getBase64(id);
					
					ProfileDialog dialog;
					try {
						dialog = new ProfileDialog(status, base64);
						dialog.setVisible(true);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}				
			}
		});
		scrollPane.setViewportView(list);
		

	}
	
	private void searchFilter(String filter) {
		DefaultListModel<String> filterListModel = new DefaultListModel<>();
		for(String string : infos) {
			String lowName = string.toLowerCase();
			if(lowName.startsWith(filter.toLowerCase())) filterListModel.addElement(string);
		}
		list.setModel(filterListModel);
	}
	
	void setDefModel(LinkedList<String> linkedList) {
		model = new DefaultListModel<>();
		setInfos(linkedList);
		for(String info : infos) model.addElement(info);
		list.setModel(model);
	}

	public LinkedList<String> getInfos() {
		return infos;
	}

	public void setInfos(LinkedList<String> infos) {
		this.infos = infos;
	}
	
	

}

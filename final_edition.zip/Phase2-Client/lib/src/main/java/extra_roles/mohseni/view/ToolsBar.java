package extra_roles.mohseni.view;

import javax.swing.JPanel;

import interfaces.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class ToolsBar extends JPanel implements ActionListener {
	
	private JButton searchBtn;
	private JButton filterBtn;
	private JButton exitBtn;
	private Listener listener;
	
	public ToolsBar() {
		
		searchBtn = new JButton("Search");
		searchBtn.addActionListener(this);
		add(searchBtn);
		
		filterBtn = new JButton("Filter");
		filterBtn.addActionListener(this);
		add(filterBtn);
		
		exitBtn = new JButton("Exit");
		exitBtn.addActionListener(this);
		add(exitBtn);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if((JButton)e.getSource() == searchBtn) listener.listen("search");
		if((JButton)e.getSource() == filterBtn) listener.listen("filter");
		if((JButton)e.getSource() == exitBtn) listener.listen("exit");
	}

	public Listener getListener() {
		return listener;
	}

	public void setListener(Listener listener) {
		this.listener = listener;
	}

	
}

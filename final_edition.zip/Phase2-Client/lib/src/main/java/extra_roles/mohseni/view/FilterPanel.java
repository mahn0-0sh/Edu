package extra_roles.mohseni.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;

import extra_roles.mohseni.MohseniController;
import shared.util.FileStuff;

import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.Dimension;
import java.awt.event.ActionEvent;

public class FilterPanel extends JPanel {

	private MohseniController controller = new MohseniController();
	/**
	 * Create the panel.
	 */
	public FilterPanel() {
		setLayout(null);
		setSize(new Dimension(425, 300));
		
		JLabel lblNewLabel = new JLabel("Filters:");
		lblNewLabel.setBounds(10, 11, 49, 14);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Degree:");
		lblNewLabel_1.setBounds(10, 36, 80, 25);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Department:");
		lblNewLabel_1_2.setBounds(10, 72, 80, 25);
		add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Year:");
		lblNewLabel_1_2_1.setBounds(10, 108, 80, 25);
		add(lblNewLabel_1_2_1);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(10, 148, 240, 141);
		add(textArea);
		
		String[] degrees = {"BACHELOR", "MASTER", "DOCTORATE"};
		String[] deps = {"Math", "CE", "EE"};
		String[] years = {"1400", "1399", "1398"};
		
		JComboBox degreeComboBox = new JComboBox(degrees);
		degreeComboBox.setBounds(100, 37, 80, 22);
		add(degreeComboBox);
		
		JComboBox depComboBox = new JComboBox(deps);
		depComboBox.setBounds(100, 73, 80, 22);
		add(depComboBox);
		
		JComboBox yearComboBox = new JComboBox(years);
		yearComboBox.setBounds(100, 109, 80, 22);
		add(yearComboBox);
		
		
		JButton btnNewButton = new JButton("Send");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String recp = (String) degreeComboBox.getSelectedItem()+"`"+(String) depComboBox.getSelectedItem()+"`"+(String) yearComboBox.getSelectedItem();
			    controller.sendTextMessage(textArea.getText(), recp);
			}
		});
		btnNewButton.setBounds(260, 266, 137, 23);
		add(btnNewButton);
		
		JButton btnSendFile = new JButton("Send file");
		btnSendFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String recp = (String) degreeComboBox.getSelectedItem()+"`"+(String) depComboBox.getSelectedItem()+"`"+(String) yearComboBox.getSelectedItem();
				String s[] = FileStuff.chooseFile();
				controller.sendMediaMessage(s[0], s[1] , recp);
			}
		});
		btnSendFile.setBounds(260, 235, 137, 23);
		add(btnSendFile);

	}
}

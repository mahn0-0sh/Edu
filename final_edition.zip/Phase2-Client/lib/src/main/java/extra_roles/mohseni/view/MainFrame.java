package extra_roles.mohseni.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.LinkedList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import constants.Constants;
import extra_roles.mohseni.MohseniController;
import interfaces.Listener;
import shared.util.Config;

import javax.swing.JScrollPane;

public class MainFrame extends JFrame {

	private JPanel contentPane;
	private ToolsBar toolsBar;
	private SearchPanel searchPanel;
	private FilterPanel filterPanel;
	private MohseniController controller = new MohseniController();
	private JScrollPane scrollPane;
	private LinkedList<String> infos;


	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "x"),
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "y"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "w"), 
				  new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "h")); 
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		
		toolsBar = new ToolsBar();
		toolsBar.setListener(new Listener() {
			
			@Override
			public void listen(String string) {
				if(string.equals("search")) showSearchPanel();
				if(string.equals("filter")) showFilterPanel();
			}
		});
		contentPane.add(toolsBar, BorderLayout.NORTH);
		
		scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
	}

	private void showSearchPanel() {
		searchPanel = new SearchPanel();
		searchPanel.setDefModel(controller.getStuInfos());
		scrollPane.setViewportView(searchPanel);
		scrollPane.repaint();
	}
	
	private void showFilterPanel() {
		filterPanel = new FilterPanel();
		filterPanel.setSize(new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "sw"), 
				new Config(Constants.PANEL_SIZE).getProperty(Integer.class, "sh"));
		scrollPane.setViewportView(filterPanel);
		scrollPane.repaint();
		scrollPane.revalidate();
	}

	public void refresh() {
		LinkedList<String> infos = controller.getStuInfos();
		try {
			if(infos != null) searchPanel.setDefModel(controller.getStuInfos());
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}

package extra_roles.mohseni;

import java.util.LinkedList;

import client.Client;
import client.Methods;
import client.controller.Controller;
import client.network.ServerController;
import shared.response.Response;

public class MohseniController extends Controller {
	
	static Client client;
	static ServerController serverController;

	public LinkedList<String> getStuInfos() {
		Response response = serverController.getStuInfos();
		return listFromResp(response);
	}

	public static void setClient(Client client2, ServerController serverController2) {
		client = client2;
		serverController = serverController2;
	}

	public String getProfileStatus(String id) {
		Response response = serverController.getMohseniProfileStatus(id);
		if(response != null) return Methods.mohseniProStatus(response);
		return null;
	}

	public String getBase64(String id) {
		Response response = serverController.getBase64Info(id);
		if(response != null) return (String) response.getData("info");
		return null;
	}

	public void sendTextMessage(String text, String recp) {
		serverController.sendMohseniTextMsg(text, recp);
	}

	public void sendMediaMessage(String encode, String ext, String recp) {
		serverController.sendMohseniMediaMesg(encode, ext, recp);
	}

}

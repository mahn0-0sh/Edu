package extra_roles.mohseni.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import shared.util.extra.FileUtil;

import javax.swing.JLabel;

public class ProfileDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();

	

	/**
	 * Create the dialog.
	 * @throws IOException 
	 */
	public ProfileDialog(String status, String base64) throws IOException {
		String[] s = status.split("`");
		setBounds(100, 100, 450, 315);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblName = new JLabel(s[0]);
			lblName.setBounds(10, 11, 105, 14);
			contentPanel.add(lblName);
		}
		{
			JLabel lblCode = new JLabel(s[1]);
			lblCode.setBounds(10, 36, 105, 14);
			contentPanel.add(lblCode);
		}
		{
			JLabel lblId = new JLabel(s[2]);
			lblId.setBounds(10, 61, 105, 14);
			contentPanel.add(lblId);
		}
		{
			JLabel lblPhone = new JLabel(s[3]);
			lblPhone.setBounds(10, 86, 105, 14);
			contentPanel.add(lblPhone);
		}
		{
			JLabel lblEmail = new JLabel(s[4]);
			lblEmail.setBounds(10, 111, 105, 14);
			contentPanel.add(lblEmail);
		}
		{
			JLabel lblDep = new JLabel(s[5]);
			lblDep.setBounds(10, 136, 105, 14);
			contentPanel.add(lblDep);
		}
		{
			JLabel lblSup = new JLabel(s[6]);
			lblSup.setBounds(10, 161, 105, 14);
			contentPanel.add(lblSup);
		}
		{
			JLabel lblYear = new JLabel(s[7]);
			lblYear.setBounds(10, 186, 105, 14);
			contentPanel.add(lblYear);
		}
		{
			JLabel lblDegree = new JLabel(s[8]);
			lblDegree.setBounds(10, 211, 105, 14);
			contentPanel.add(lblDegree);
		}
		{
			JLabel lblPic = new JLabel("pic");
			lblPic.setBounds(355, 11, 70, 95);
			contentPanel.add(lblPic);
			
			if(base64 != null && base64 != "") {
				ByteArrayInputStream inputStream = new ByteArrayInputStream(FileUtil.decode(base64));                         
			    BufferedImage bufImage = ImageIO.read(inputStream);
			    ImageIcon icon = new ImageIcon(bufImage);
			    lblPic.setIcon(icon);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}

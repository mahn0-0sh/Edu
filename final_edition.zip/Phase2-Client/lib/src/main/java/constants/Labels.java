package constants;

import shared.util.Config;

public class Labels {
	
	private String exitBtn = new Config(Constants.BUTTON_TEXT).getProperty(String.class, "exit");
	private String homeBtn = new Config(Constants.LABEL_TEXT).getProperty(String.class, "home");

}
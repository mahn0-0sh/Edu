package constants;

import shared.util.Config;

public class Constants {
	
    public static final String LABEL_TEXT = System.getProperty("user.dir")+"\\src/main/resources/config/label_text.properties";
    public static final String CONFIG_ADDRESS = System.getProperty("user.dir")+"\\src/main/resources/config/config.properties";
    public static final String BUTTON_TEXT = System.getProperty("user.dir")+"\\src/main/resources/config/button_text.properties";
    public static final String PANEL_SIZE = System.getProperty("user.dir")+"\\src/main/resources/config/panel_size.properties";
    
    //public static final Config CONFIG = new Config(CONFIG_ADDRESS);   "./resources/config.properties" 
    
}

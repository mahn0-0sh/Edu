package student;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import constants.Constants;
import login.LogginWindow;
import login.PhaseController;
import shared.UpdatePane;
import shared.util.Config;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JTextField;

public class TempScores extends JFrame {
	
	private String courseLbl = new Config(Constants.LABEL_TEXT).getProperty(String.class, "course");
	private String scoreLbl = new Config(Constants.LABEL_TEXT).getProperty(String.class, "score");
	private String courseIdLbl = new Config(Constants.LABEL_TEXT).getProperty(String.class, "regPer");
	private String registerProtestLbl = new Config(Constants.LABEL_TEXT).getProperty(String.class, "registerProtest");
	private String viewProtest = new Config(Constants.LABEL_TEXT).getProperty(String.class, "viewProtest");
	
	private String homeBtn = new Config(Constants.BUTTON_TEXT).getProperty(String.class, "home");
	private String exitBtn = new Config(Constants.BUTTON_TEXT).getProperty(String.class, "exit");

	private JPanel contentPane;
	private JTable table;
	private JTextField courseIDField;
	private PhaseController controller = new PhaseController();
	private String id;

	
	public TempScores(String id) {
		this.id = id;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane); 
		contentPane.setLayout(null);
		
		refresh();
	}
	
	
	private void initPage(LinkedList<String> list) {
		JLabel lblCourse = new JLabel(courseLbl);
		lblCourse.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblCourse.setBounds(10, 11, 227, 14);
		contentPane.add(lblCourse);
		
		JLabel lblScore = new JLabel(scoreLbl);
		lblScore.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblScore.setBounds(247, 11, 49, 14);
		contentPane.add(lblScore);
		
		UpdatePane.updateTempScores(contentPane, list);
		
		JButton btnNewButton = new JButton(homeBtn);
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton.setBounds(381, 8, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton(exitBtn);
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton_1.setBounds(480, 8, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel(courseIdLbl);
		lblNewLabel_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1.setForeground(new Color(147, 112, 219));
		lblNewLabel_1.setBounds(381, 42, 72, 14);
		contentPane.add(lblNewLabel_1);
		
		courseIDField = new JTextField();
		courseIDField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		courseIDField.setBounds(463, 40, 106, 20);
		contentPane.add(courseIDField);
		courseIDField.setColumns(10);
		
		JButton btnNewButton_2 = new JButton(registerProtestLbl); //TODO
		btnNewButton_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mini_id = courseIDField.getText();
				controller.protestToScore(mini_id); //TODO check if it is temp
			}
		});
		btnNewButton_2.setBackground(new Color(147, 112, 219));
		btnNewButton_2.setBounds(381, 67, 188, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton(viewProtest);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showProtestFeedbackDialog();
			}
		});
		btnNewButton_3.setBackground(new Color(147, 112, 219));
		btnNewButton_3.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnNewButton_3.setBounds(381, 101, 188, 23);
		contentPane.add(btnNewButton_3);
	}

	
	
	public void refresh() {
		LinkedList<String> list = controller.getTempScores(id);
		if(list != null) {
			contentPane.removeAll();
			initPage(list);
			contentPane.repaint();
			contentPane.revalidate();
		} else {
			controller.visitHome();
		}
	}


}

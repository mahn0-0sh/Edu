package student;
import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.checkerframework.checker.units.qual.s;

import shared.ExamSched;
import shared.WeekSched;
import shared.model.*;
import shared.util.Config;
import chat.view.ChatRoomGUI;
import chooseCourse.view.CourseChoose;
import client.Client;
import client.ConnectionStatus;
import constants.Constants;
import login.LogginWindow;
import login.PhaseController;
import resources.ProfilePic;

import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;

import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.time.LocalDateTime;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Point;
import java.awt.Color;

public class StudentMain extends JFrame {

	private Logger logger = LogManager.getLogger(StudentMain.class);
	private JLabel nameLabel;
	private JLabel emailLabel;
	private JLabel vaziatL;
	private JLabel lastVisitLbl;
	private JLabel supervL;
	private JLabel mojavezL;
	private JLabel signUpTimeL;
	private JLabel currentTimeLbl;
	private JMenuBar menuBar;
	private JMenu extraMenu;
	private PhaseController controller = new PhaseController();
	private JButton recBtn;
	private JLabel offLbl;
	
	private String dateFormat = new Config(Constants.CONFIG_ADDRESS).getProperty(String.class, "dateFormat");
	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern(dateFormat);
	 
	

	
	public StudentMain(String status) {
		initPane();
		initCurrentTime();
		initConstantLabels();
		String[] s = "m`m`m`m`m`m`m`m`m`m`".split("`");
		try {
			s = status.split("`");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		name(s[0]);
		email(s[1]);
		vaziat(s[2]);
		supervisor(s[3]);
		mojavez(s[4]);
		signupTime(s[5]);
		lastVisit(s[6]);
		picLbl(); 
	    initMenuBar();
		exitBtn();
		chooserMenu();
		
		
		recBtn = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "reconnect"));
		recBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.reconnect();
				
			}
		});
		recBtn.setBounds(721, 15, 125, 23);
		getContentPane().add(recBtn);
		recBtn.setVisible(false);
		
		offLbl = new JLabel(new Config(Constants.LABEL_TEXT).getProperty(String.class, "offline"));
		offLbl.setBounds(299, 352, 180, 14);
		getContentPane().add(offLbl);
		offLbl.setVisible(false);
		
		if(!ConnectionStatus.getStatus().isOnline()) {
			recBtn.setVisible(true);
			offLbl.setVisible(true);
		}
		
	    setTimer(); 
	}
	
	
	private void setTimer() {
		
		try {
			
			String[] timeStrings = signUpTimeL.getText().split("\\+");
			String start = timeStrings[0];
			String end = timeStrings[1];
			ShowTask task = new ShowTask();
			task.menu = extraMenu;
			
			DisposeTask dtask = new DisposeTask();
			dtask.menu = extraMenu;
			
			Timer timer = new Timer();
			Date date = null; 
			
			date = new SimpleDateFormat(dateFormat).parse(start);
			timer.schedule(task, date);
			
			date = new SimpleDateFormat(dateFormat).parse(end);
			timer.schedule(dtask, date);
		} catch (Exception e) {
			logger.info("date problem");
			logger.info(e);
		}
		
	}
	
	public void picLbl() {
		JLabel picLbl = new JLabel();
		picLbl.setBounds(32, 43, 100, 110);
		getContentPane().add(picLbl);
	    picLbl.setIcon(ProfilePic.pic);
	}
	
	public void initMenuBar() {
		menuBar = new JMenuBar();
		menuBar.setBackground(new Color(230, 230, 250));
		setJMenuBar(menuBar);
		
		//Registration
		JMenu regMenu = new JMenu(new Config(Constants.LABEL_TEXT).getProperty(String.class, "regMenu"));
		regMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		regMenu.setForeground(new Color(0, 0, 0));
		regMenu.setBackground(new Color(255, 240, 245));
		menuBar.add(regMenu);
		
		JMenuItem cListItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "courseList"));
		cListItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		cListItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			     
			    controller.showCoursesList();
			     
			}
		});
		regMenu.add(cListItem);
		
		JMenuItem tListItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "teacherList"));
		tListItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		tListItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			    	controller.showTeachersList();
				
			}
		});
		regMenu.add(tListItem);
		
		
		
		
		//Service
		JMenu serMenu = new JMenu(new Config(Constants.LABEL_TEXT).getProperty(String.class, "serMenu")); //TODO offline mode
		serMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		serMenu.setForeground(new Color(0, 0, 0));
		serMenu.setBackground(new Color(175, 238, 238));
		menuBar.add(serMenu);
		
		JMenuItem weekItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "weekSchd"));
		weekItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		weekItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.showWeekSchd();
				
			}
		});
		serMenu.add(weekItem);
		
		JMenuItem exItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "examSchd"));
		exItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		exItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
			     controller.showExamSchd();
			    
				
			}
		});
		serMenu.add(exItem);
		
		
		
		
		
		
		
		
		
		
		
		JMenuItem reqItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "request"));
		reqItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		reqItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { //TODO
				
			     controller.showReqPage();
			     
			}
		});
		serMenu.add(reqItem);
		
		
		
		
		
		
		
		//Record
		JMenu recMenu = new JMenu(new Config(Constants.LABEL_TEXT).getProperty(String.class, "recMenu"));
		recMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		recMenu.setForeground(new Color(0, 0, 0));
		recMenu.setBackground(new Color(255, 240, 245));
		menuBar.add(recMenu);
		
		JMenuItem tempItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "tempScores"));
		tempItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		tempItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.showTempScores();
				
			}
		});
		recMenu.add(tempItem);
		
		JMenuItem eduItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "eduStatus"));
		eduItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		eduItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.showEduStatus();
				
			}
		});
		recMenu.add(eduItem);
		
		
		
		
		
		
		//Profile
		JMenu proMenu = new JMenu(new Config(Constants.LABEL_TEXT).getProperty(String.class, "profile"));
		proMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		proMenu.setForeground(new Color(0, 0, 0));
		proMenu.setBackground(new Color(175, 238, 238));
		menuBar.add(proMenu);
		
		JMenuItem proItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "profileDet"));
		proItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		proItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.showProfile();
				
			}
		});
		proMenu.add(proItem);
		
		JMenuItem cwItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "cw"));
		cwItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		cwItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.showCWMain();
				
			}
		});
		proMenu.add(cwItem);
		
		JMenuItem chatItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "chat"));
		chatItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		chatItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.showChatMain();
				
			}
		});
		proMenu.add(chatItem);
		
		JMenuItem msgItem = new JMenuItem(new Config(Constants.LABEL_TEXT).getProperty(String.class, "msgs"));
		msgItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		msgItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				controller.showMsgMain();
				
			}
		});
		proMenu.add(msgItem);
		
	}
	
	public void exitBtn() {		
		JButton exitButton = new JButton(new Config(Constants.BUTTON_TEXT).getProperty(String.class, "exit"));
		exitButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		exitButton.setBounds(10, 11, 89, 23);
		getContentPane().add(exitButton);
	}
	
	
	
	public void initPane() {
	//	getContentPane().setBackground(backColor);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		getContentPane().setLayout(null);
	}
	
	public void initCurrentTime() {
		//Current time
		currentTimeLbl = new JLabel(); 
		currentTimeLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		currentTimeLbl.setBounds(155, 15, 117, 14);
	//	currentTimeLbl.setForeground(colorTextMain);
		getContentPane().add(currentTimeLbl);
		Thread clock = new Thread()
		{
			public void run() {
				try {
					while(true) {
					LocalDateTime now2 = LocalDateTime.now(); 
					currentTimeLbl.setText(dtf.format(now2));
					sleep(1000);
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				};
		clock.start();		
	}
	
	
	public void initConstantLabels() {
		JLabel lblNewLabel = new JLabel(new Config(Constants.LABEL_TEXT).getProperty(String.class, "status"));
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.ITALIC, 13));
		lblNewLabel.setBounds(271, 89, 117, 14);
	//	lblNewLabel.setForeground(colorTextMain);
		getContentPane().add(lblNewLabel);
		
		JLabel lblSupervisor = new JLabel(new Config(Constants.LABEL_TEXT).getProperty(String.class, "supervisor"));
		lblSupervisor.setFont(new Font("Traditional Arabic", Font.ITALIC, 13));
		lblSupervisor.setBounds(271, 114, 117, 14);
	//	lblSupervisor.setForeground(colorTextMain);
		getContentPane().add(lblSupervisor);
		
		JLabel lblNewLabel_1_1 = new JLabel(new Config(Constants.LABEL_TEXT).getProperty(String.class, "regPer"));
		lblNewLabel_1_1.setFont(new Font("Traditional Arabic", Font.ITALIC, 13));
		lblNewLabel_1_1.setBounds(271, 139, 117, 14);
	//	lblNewLabel_1_1.setForeground(colorTextMain);
		getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel(new Config(Constants.LABEL_TEXT).getProperty(String.class, "regTime"));
		lblNewLabel_1_1_1.setFont(new Font("Traditional Arabic", Font.ITALIC, 13));
		lblNewLabel_1_1_1.setBounds(271, 164, 117, 14);
	//	lblNewLabel_1_1_1.setForeground(colorTextMain);
		getContentPane().add(lblNewLabel_1_1_1);
	}
	
	public void name(String name) {
		nameLabel = new JLabel(name);
		nameLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
	//	nameLabel.setForeground(colorTextMain);
		nameLabel.setBounds(32, 164, 204, 14);
		getContentPane().add(nameLabel); 
	}
	
	public void email(String email) {
		emailLabel = new JLabel(email);
		emailLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
	//	emailLabel.setForeground(colorTextMain);
		emailLabel.setBounds(32, 189, 204, 14);
		getContentPane().add(emailLabel);
	}
	
	public void vaziat(String string) {
		vaziatL = new JLabel(string);
	//	vaziatL.setForeground(colorText);
		vaziatL.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		vaziatL.setBounds(398, 89, 148, 14);
		getContentPane().add(vaziatL);
	}
	
	public void supervisor(String string) {
		supervL = new JLabel(string);
	//	supervL.setForeground(colorText);
		supervL.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		supervL.setBounds(398, 114, 130, 14);
		getContentPane().add(supervL);		
	}
	
	public void mojavez(String string) {
		mojavezL = new JLabel(string);
	//	mojavezL.setForeground(colorText);
		mojavezL.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		mojavezL.setBounds(398, 139, 130, 14);
		getContentPane().add(mojavezL);
	}
	
	public void signupTime(String string) {
		signUpTimeL = new JLabel(string);
	//	signUpTimeL.setForeground(colorText);
		signUpTimeL.setFont(new Font("Traditional Arabic", Font.PLAIN, 13));
		signUpTimeL.setBounds(398, 164, 272, 14);
		signUpTimeL.setPreferredSize(signUpTimeL.getPreferredSize());
		getContentPane().add(signUpTimeL);
	}
	
	public void lastVisit(String string) {
		lastVisitLbl = new JLabel(string);
		lastVisitLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lastVisitLbl.setBounds(362, 15, 148, 14);
	//	lastVisitLbl.setForeground(colorTextMain);
		getContentPane().add(lastVisitLbl);
		
	/*	try {
			lastVisitLbl.setText(stdM.getLastVisit());
		} catch (Exception e) {
			lastVisitLbl.setText("");
		} */
	}
	
	

	
	
	private void chooserMenu() {
		extraMenu = new JMenu("Extra");
		extraMenu.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		menuBar.add(extraMenu);
		
		JMenuItem chooserItem = new JMenuItem("Chooser page");
		chooserItem.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		chooserItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(mojavezL.equals("NO")) JOptionPane.showMessageDialog(null, "You are not allowed");
				else controller.courseChooseGUI();
			}
		});
		extraMenu.add(chooserItem);	
		
	//TODO	extraMenu.setVisible(false);
		extraMenu.setVisible(true);
	}
	
	
	public void refresh() {
		
		String status = controller.getMainStatus();
		
		if(status != null) {
			String[] s = status.split("`");

			nameLabel.setText(s[0]);
			emailLabel.setText(s[1]);
			vaziatL.setText(s[2]);
			supervL.setText(s[3]);
			mojavezL.setText(s[4]);
			signUpTimeL.setText(s[5]);
			lastVisitLbl.setText(s[6]);
		} else {
				System.out.println("I'm going home");
				controller.visitHome();
		}
		
		
	}
 }



class ShowTask extends TimerTask {
	JMenu menu;

	@Override
	public void run() {
		menu.setVisible(true);
	}
	
}


class DisposeTask extends TimerTask {
	JMenu menu;
	private PhaseController controller = new PhaseController();

	@Override
	public void run() {
		controller.correctChoices();
		menu.setVisible(false);
	}
	
}

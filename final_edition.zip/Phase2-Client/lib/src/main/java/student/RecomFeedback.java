package student;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.LinkedList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.ReqController;

import javax.swing.JScrollPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.ActionEvent;

public class RecomFeedback extends JFrame {

	private JPanel pane;
	private JList list;
	private ReqController controller = new ReqController();
	
	public RecomFeedback() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		pane = new JPanel();
		pane.setBorder(new EmptyBorder(5, 5, 5, 5));
		pane.setLayout(new BorderLayout(0, 0));
		setContentPane(pane);
		
		JPanel panel = new JPanel();
		pane.add(panel, BorderLayout.NORTH);
		
		JButton btnNewButton = new JButton("Home");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		panel.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		pane.add(scrollPane, BorderLayout.CENTER);
		
		list = new JList<String>();
		scrollPane.setViewportView(list);
		setModel();
		
		MouseListener mouseListener = new MouseAdapter() {
		      public void mouseClicked(MouseEvent mouseEvent) {
		        if (mouseEvent.getClickCount() == 2) {
		        	
		        	String selected = (String) list.getSelectedValue();
		        	if(selected.split(" - ")[1].equals("ACCEPTED")) {
		        		RecomDialog dialog = new RecomDialog(controller.getRecomText(selected.split(" - ")[0]));
		        		dialog.setVisible(true);
		        	} else {
						System.out.println(selected.split(" - ")[1]);
					}
		        	
		        }
		      }
		    };
		    list.addMouseListener(mouseListener);
	}
	
	private void setModel() {
		DefaultListModel<String> model = new DefaultListModel<>();
		LinkedList<String> recomList = controller.getRecomList();
		if(recomList != null) {
			for(String string : recomList) model.addElement(string);
			list.setModel(model);
		} else {
			controller.visitHome();
		}		
	}

}

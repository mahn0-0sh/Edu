package student;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import enums.ReqType;
import login.LogginWindow;
import login.PhaseController;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;

public class Minor extends JFrame {

	private JPanel contentPane;
	static Minor frameStatic;
	private PhaseController controller = new PhaseController();

	static Logger logger = LogManager.getLogger(Minor.class);

	
	public Minor() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Destination department:");
		lblNewLabel.setForeground(new Color(0, 0, 230));
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel.setBounds(10, 11, 223, 28);
		contentPane.add(lblNewLabel);
		
		String[] departmentStrings = {"Math","CE","EE","Chemistry", "Physics"};
		JComboBox comboBox = new JComboBox(departmentStrings);
		comboBox.setFont(new Font("Traditional Arabic", Font.BOLD, 11));
		comboBox.setForeground(new Color(123, 104, 238));
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == comboBox) {
					try {
						double gpa = -1;
						
						try {
							gpa = controller.getGPA(null);
						}catch (Exception e1) {
							// TODO: handle exception
						}
						
						if(gpa>=15) {
							
							ReqType reqType = ReqType.MINOR;
							String recp = "";
							controller.sendReq(reqType, "", (String) comboBox.getSelectedItem());
						
				/*		try {
							int q = mainPage.stdM.minorReqDepartments.size();
							int p = mainPage.stdM.minorReqFeedbacks.size();
						} catch (Exception e1) {
							mainPage.stdM.minorReqDepartments = new ArrayList<String>();
							mainPage.stdM.minorReqFeedbacks = new ArrayList<String>();
						}
						
					mainPage.stdM.minorReqDepartments.add(depString);
					mainPage.stdM.minorReqFeedbacks.add("Pending"); */
						
	    	//		Requests.sendMinorReqToIN(StudentMain.stdM, StudentMain.stdM.getStringDepartment(), depString);
							JOptionPane.showMessageDialog(null, "Request sent.");	    			
	    			
	    	//		logger.info(StudentMain.stdM.getName()+" requested a minor with "+depString);
	    			
					} else {
						JOptionPane.showMessageDialog(null, "Your GPA is less than 15.");
					}
	    			
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null, "Unsuccessful."); 
					logger.error(e1);
					}
				}
			}
			});
		comboBox.setBounds(243, 7, 178, 32);
		contentPane.add(comboBox);
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton.setBackground(new Color(255, 240, 245));
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 9));
		btnNewButton.setBounds(607, 16, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnHomepage = new JButton("Homepage");
		btnHomepage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnHomepage.setBackground(new Color(255, 240, 245));
		btnHomepage.setFont(new Font("Traditional Arabic", Font.PLAIN, 9));
		btnHomepage.setBounds(607, 50, 89, 23);
		contentPane.add(btnHomepage);
	}
}

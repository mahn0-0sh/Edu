package student;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import login.PhaseController;

import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.awt.event.ActionEvent;

public class ProtestFeedbackDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private DefaultListModel<String> dListModel = new DefaultListModel<>();
	private PhaseController controller = new PhaseController();
	private JList<String> list = new JList<>();

	

	/**
	 * Create the dialog.
	 */
	public ProtestFeedbackDialog() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(253, 245, 230));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(10, 11, 416, 208);
			contentPanel.add(scrollPane);
			
				
			list = new JList();
			list.setModel(dListModel);
			scrollPane.setViewportView(list);
			refresh();
			
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(230, 230, 250));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
	}



	public void refresh() {
		LinkedList<String> protests = controller.getProtestFeedbacks(); 
		if(protests != null) {
			dListModel = new DefaultListModel<>();
			try {
				for(int i=0; i<protests.size(); i++){
					dListModel.addElement(protests.get(i));
				}
			} catch (Exception e) {
				dListModel.addElement("");
			}
			list.setModel(dListModel);
		} else {
			controller.visitHome();
		}
	}

}

package student;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import enums.Dissertation;
import enums.ReqType;
import enums.StudentDegree;
import login.PhaseController;

import javax.swing.JComboBox;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;

public class RequestStu extends JFrame {

	private JPanel contentPane;
	private PhaseController controller = new PhaseController();
	private StudentDegree degree = controller.getDegree();
	private JButton minorBtn;
	private JButton recomBtn;

	
	public RequestStu() {
		initStuff();
		
		if(degree == StudentDegree.BACHELOR) {
			initializeBachelor();
		}
		if(degree == StudentDegree.MASTER) {
			initializeMaster();
		}
		if(degree == StudentDegree.DOCTORATE) {
			initializeDoctorate();
		} 
	}
	
	
	private void initStuff() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		recomBtn = new JButton("View recommendation feedbacks");
		recomBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.showStuRecomFeed();
			}
		});
		recomBtn.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		recomBtn.setBounds(462, 45, 222, 23);
		contentPane.add(recomBtn);
		recomBtn.setVisible(false);
		
		JButton btnNewButton = new JButton("Home page");
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton.setBounds(462, 11, 106, 23);
		contentPane.add(btnNewButton);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnExit.setBounds(578, 11, 106, 23);
		contentPane.add(btnExit);
	}
	
	
	
	
	//Bachelor
	private void initializeBachelor() {
		String[] requests = {"Recommendation","Certificate","Minor","Withdrawal"};
		JComboBox comboBox = new JComboBox(requests);
		comboBox.setForeground(new Color(0, 0, 0));
		comboBox.setBackground(new Color(255, 240, 245));
		comboBox.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == comboBox) {
				//	ReqType reqType = null;
					
	    			int index = comboBox.getSelectedIndex();
	    			String recp = "";
	    			String dep = "";
	    			
	    			switch (index) {
					case 0:
						controller.showRecomPage();
						break;
                    case 1:
                    	controller.showCertificate();
						break;
					case 2:
						dep = JOptionPane.showInputDialog("Wich department?");
                    	controller.sendReq(ReqType.MINOR, recp, dep);
                    	dep = "";
						break;
                    case 3:
                    	ReqType reqType = ReqType.WITHDRAW;
                    	controller.sendReq(reqType, recp, dep);
						break;
		
					default:
						break;
					}
	    			
	    			
				}
			}
		});
		comboBox.setBounds(10, 11, 345, 22);
		contentPane.add(comboBox);
		
		recomBtn.setVisible(true);
	}
	
	
	
	
	
	
	
	
	//Master
	void initializeMaster() {
		String[] requests = {"Recommendation","Certificate","Withdrawal","Dorm"};
		JComboBox comboBox = new JComboBox(requests);
		comboBox.setForeground(new Color(0, 0, 0));
		comboBox.setBackground(new Color(255, 240, 245));
		comboBox.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == comboBox) {
	    			int index = comboBox.getSelectedIndex();
	    			
	    			switch (index) {
					case 0:
						controller.showRecomPage();
						break;
                    case 1:
                    	controller.showCertificate();
						break;
                    case 2:
                    	ReqType reqType = ReqType.WITHDRAW;
                    	controller.sendReq(reqType, "", "");
						break;
					case 3:
						Random random = new Random();
						if(random.nextBoolean()) {
							JOptionPane.showMessageDialog(null, "Your request has been accepted.");
						} else {
							JOptionPane.showMessageDialog(null, "Your request has been denied.");
						}
						break;
					default:
						break;
					}
	    			
	    		}
			}
		});
		comboBox.setBounds(10, 11, 345, 22);
		contentPane.add(comboBox);
		
		recomBtn.setVisible(true);
	}
	
	
	
	
	
	
	
	
	
	//Doctorate
	void initializeDoctorate() {
		String[] requests = {"Certificate","Withdrawal","Dissertation"};
		JComboBox comboBox = new JComboBox(requests);
		comboBox.setForeground(new Color(0, 0, 0));
		comboBox.setBackground(new Color(255, 240, 245));
		comboBox.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == comboBox) {
	    			int index = comboBox.getSelectedIndex();
	    			
	    			switch (index) {
                    case 0:
                    	controller.showCertificate();
						break;
                    case 1:
                    	ReqType reqType = ReqType.WITHDRAW;
                    	controller.sendReq(reqType, "", "");
						break;
                    case 2:
						String date = Dissertation.getRandom(); //TODO config
						JOptionPane.showMessageDialog(null, "Your defense meeting is on "+date);
						break;
					default:
						break;
					}
	    			
	    		}
			}
		});
		comboBox.setBounds(10, 11, 345, 22);
		contentPane.add(comboBox);
	}


}

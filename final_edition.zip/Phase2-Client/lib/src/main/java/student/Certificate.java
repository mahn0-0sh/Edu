package student;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import login.LogginWindow;
import login.PhaseController;

import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Certificate extends JFrame {

	private JPanel contentPane;
	Logger logger = LogManager.getLogger(Certificate.class);
	private PhaseController controller = new PhaseController();

	public Certificate() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 9));
		btnNewButton.setBounds(693, 11, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnHomepage = new JButton("Homepage");
		btnHomepage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnHomepage.setFont(new Font("Traditional Arabic", Font.PLAIN, 9));
		btnHomepage.setBounds(693, 45, 89, 23);
		contentPane.add(btnHomepage);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel.setBounds(10, 15, 561, 387);
		contentPane.add(lblNewLabel);
		
		String message = controller.getCertificate();
		lblNewLabel.setText(message);	
		
	}
}

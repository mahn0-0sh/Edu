package student;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import shared.UpdatePane;
import shared.model.*;
import teacher.TeacherMain;
import client.ConnectionStatus;
import login.LogginWindow;
import login.PhaseController;

import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class EducationalStatus extends JFrame {

	private JPanel contentPane;	
	private PhaseController controller = new PhaseController();
	
	public EducationalStatus(String id) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		refresh(id);
	}
	
	private void initPane(LinkedList<String> fullScores, Double gpa, int credits) {
		JButton btnNewButton = new JButton("Home page");
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton.setBounds(650, 11, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Course");
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel.setBounds(10, 11, 182, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblScore = new JLabel("Score");
		lblScore.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 14));
		lblScore.setBounds(202, 11, 72, 14);
		contentPane.add(lblScore);
		
		JLabel lblCreditsPassed = new JLabel("Credits passed:");
		lblCreditsPassed.setForeground(new Color(255, 0, 255));
		lblCreditsPassed.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 12));
		lblCreditsPassed.setBounds(284, 14, 102, 14);
		contentPane.add(lblCreditsPassed);
		
		JLabel lblGpa = new JLabel("GPA:");
		lblGpa.setForeground(new Color(255, 0, 255));
		lblGpa.setFont(new Font("Traditional Arabic", Font.BOLD | Font.ITALIC, 12));
		lblGpa.setBounds(284, 39, 102, 14);
		contentPane.add(lblGpa);
		
		JLabel creditsPassedLbl = new JLabel(credits+"");
		creditsPassedLbl.setForeground(new Color(0, 0, 255));
		creditsPassedLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		creditsPassedLbl.setBounds(407, 13, 72, 14);
		contentPane.add(creditsPassedLbl);
		
		
		
		JLabel gpaLbl = new JLabel(gpa+"");
		gpaLbl.setForeground(new Color(0, 0, 255));
		gpaLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		gpaLbl.setBounds(407, 38, 72, 14);
		contentPane.add(gpaLbl);
		
		UpdatePane.updateFinalScores(contentPane, fullScores);
		
		
		
		JButton btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 10));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		btnNewButton_1.setBounds(650, 45, 89, 23);
		contentPane.add(btnNewButton_1);
	}
	
	
	
	public void refresh(String id) {
		Double gpa = controller.getGPA(id);
		int credits = controller.getCredits(id);
		LinkedList<String> scores = controller.getFullScores(id);
		
		if(scores != null) {
			initPane(scores, gpa, credits);
		} else {
			controller.visitHome();
		}
	}
	

}

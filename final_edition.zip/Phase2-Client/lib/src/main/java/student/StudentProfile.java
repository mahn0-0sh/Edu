package student;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import shared.model.*;
import client.Client;
import client.ConnectionStatus;
import login.LogginWindow;
import login.PhaseController;
import resources.ProfilePic;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class StudentProfile extends JFrame {

	private JPanel contentPane;
	private JTextField phoneField;
	private JTextField emailField;
	private PhaseController controller = new PhaseController();
	private Logger logger = LogManager.getLogger(StudentProfile.class);
	private JLabel nameLbl, codeLbl, idLbl;
	private JLabel phoneLabel, emailLabel, departLabel;
	private JLabel gpaLbl, supvisorLbl, yearLbl;
	private JLabel degreeLbl, statusLbl;
	
	public StudentProfile(String status) {
		String[] s = status.split("/");
		initPane();
		
		initConstantLabels();
		
		nameCodeID(s[0], s[1], s[2]);
		phoneEmailDep(s[3], s[4], s[5]);
	    gpaSuperYear(s[6], s[7], s[8]);
	    degreeStatus(s[9], s[10]);
		
		pic();
		
		if(ConnectionStatus.getStatus().isOnline()) {
			phoneBtn();
			emailBtn();
			phoneField();
			emailField();
		}
		
		homeBtn();
		exitBtn();
		
	}
	
	void initPane() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	}
	void emailField() {
		emailField = new JTextField();
		emailField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		emailField.setColumns(10);
		emailField.setBounds(50, 285, 209, 20);
		contentPane.add(emailField);
	}

	void phoneField() {
		phoneField = new JTextField();
		phoneField.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		phoneField.setBounds(50, 251, 209, 20);
		contentPane.add(phoneField);
		phoneField.setColumns(10);
	}
	
	void emailBtn() {
		JButton btnNewButton_1 = new JButton("Change email address");
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.changeData(emailField.getText(), "email");
			}
		});
		btnNewButton_1.setBounds(269, 284, 204, 23);
		contentPane.add(btnNewButton_1);
	}
	void phoneBtn() {
		JButton btnNewButton = new JButton("Change phone number");
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.changeData(phoneField.getText(), "phone");
			}
		});
		btnNewButton.setBounds(269, 250, 204, 23);
		contentPane.add(btnNewButton);
	}
	
	void exitBtn() {
		JButton exitButton = new JButton("Exit");
		exitButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.exit();
			}
		});
		exitButton.setBounds(10, 11, 89, 23);
		contentPane.add(exitButton);
	}

	void homeBtn() {
		JButton homepageButton = new JButton("Home page");
		homepageButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		homepageButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		homepageButton.setBounds(506, 11, 127, 23);
		contentPane.add(homepageButton);
	}
	
	void nameCodeID(String s1, String s2, String s3) {
		nameLbl = new JLabel(s1);
		nameLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		nameLbl.setBounds(127, 69, 192, 14);
		contentPane.add(nameLbl);
		
		codeLbl = new JLabel(s2);
		codeLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		codeLbl.setBounds(127, 94, 192, 14);
		contentPane.add(codeLbl);
		
		idLbl = new JLabel(s3);
		idLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		idLbl.setBounds(127, 122, 192, 14);
		contentPane.add(idLbl);
	}
	void phoneEmailDep(String s1, String s2, String s3) {
		phoneLabel = new JLabel(s1);
		phoneLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		phoneLabel.setBounds(472, 69, 192, 14);
		contentPane.add(phoneLabel);
		
		emailLabel = new JLabel(s2);
		emailLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		emailLabel.setBounds(472, 95, 192, 14);
		contentPane.add(emailLabel);
		
		departLabel = new JLabel(s3);
		departLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		departLabel.setBounds(472, 122, 192, 14);
		contentPane.add(departLabel);
	}
	void gpaSuperYear(String s1, String s2, String s3) {
		gpaLbl = new JLabel(s1);
		gpaLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		gpaLbl.setBounds(127, 147, 192, 14);
		contentPane.add(gpaLbl);
				
		
		supvisorLbl = new JLabel(s2);
		supvisorLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		supvisorLbl.setBounds(127, 172, 192, 14);
		contentPane.add(supvisorLbl);
		
		
		yearLbl = new JLabel(s3); // add field
		yearLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		yearLbl.setBounds(472, 147, 192, 14);
		contentPane.add(yearLbl);
	}
	
    void degreeStatus(String s1, String s2) {		
		degreeLbl = new JLabel(s1);
		degreeLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		degreeLbl.setBounds(472, 172, 192, 14);
		contentPane.add(degreeLbl);
		
    	statusLbl = new JLabel(s2);
		statusLbl.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		statusLbl.setBounds(127, 197, 192, 14);
		contentPane.add(statusLbl);
    }
	
	
	private void initConstantLabels() {
		JLabel lblNewLabel_2 = new JLabel("Status:");
		lblNewLabel_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(50, 196, 66, 14);
		contentPane.add(lblNewLabel_2);
		
		
		JLabel lblNewLabel = new JLabel("Full Name:");
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel.setBounds(50, 69, 81, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblCode = new JLabel("Code:");
		lblCode.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblCode.setBounds(50, 94, 81, 14);
		contentPane.add(lblCode);
		
		JLabel lblNewLabel_1_1 = new JLabel("ID:");
		lblNewLabel_1_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1_1.setBounds(50, 121, 81, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("Phone number:");
		lblNewLabel_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(368, 69, 105, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Email:");
		lblNewLabel_1_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1_2.setBounds(368, 94, 105, 14);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Department:");
		lblNewLabel_1_2_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1_2_1.setBounds(368, 121, 105, 14);
		contentPane.add(lblNewLabel_1_2_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("GPA:");
		lblNewLabel_1_1_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1_1_1.setBounds(50, 146, 81, 14);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Supervisor:");
		lblNewLabel_1_1_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1_1_2.setBounds(50, 171, 81, 14);
		contentPane.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_2_1_1 = new JLabel("Year of arrival:");
		lblNewLabel_1_2_1_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1.setBounds(368, 147, 105, 14);
		contentPane.add(lblNewLabel_1_2_1_1);
		
		JLabel lblNewLabel_1_2_1_2 = new JLabel("Degree:");
		lblNewLabel_1_2_1_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 12));
		lblNewLabel_1_2_1_2.setBounds(368, 172, 105, 14);
		contentPane.add(lblNewLabel_1_2_1_2);
	}
	
	private void pic() {
		JLabel picLbl = new JLabel();
		picLbl.setBounds(253, 15, 94, 108);
		contentPane.add(picLbl);
		picLbl.setIcon(ProfilePic.pic); //TODO
	}

	public void refresh() {
		String status = controller.getProfileStatus();
		if(status != null) {
			String[] s = status.split("/");
			nameLbl.setText(s[0]);
			codeLbl.setText(s[1]);
			idLbl.setText(s[2]);
			phoneLabel.setText(s[3]);
			emailLabel.setText(s[4]);
			departLabel.setText(s[5]);
			gpaLbl.setText(s[6]);
			supvisorLbl.setText(s[7]);
			yearLbl.setText(s[8]);
			degreeLbl.setText(s[9]);
			statusLbl.setText(s[10]);
		} else {
			controller.visitHome();
		}
	}
}

package student;
import java.awt.BorderLayout;
import enums.ReqType;
import login.LogginWindow;
import login.PhaseController;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Recommendation extends JFrame {

	private Logger logger = LogManager.getLogger(Recommendation.class);
	private JPanel contentPane;
	private JTextField textField;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private PhaseController controller = new PhaseController();

	public Recommendation() {
		initStuff();
		
		textField = new JTextField();
		textField.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		textField.setBounds(136, 8, 116, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Send request");
		btnNewButton.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				    ReqType reqType = ReqType.RECOM;
				
				try {
					String recp = textField.getText();
				    controller.sendReq(reqType, recp, "");
				
				    JOptionPane.showMessageDialog(null, "Request sent.");
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, "Teacher not found.");
				}
				
			}
		});
		btnNewButton.setBounds(10, 60, 116, 23);
		contentPane.add(btnNewButton);
		
		
		
	}
	
	
	private void initStuff() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter teacher ID:");
		lblNewLabel.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		lblNewLabel.setBounds(10, 11, 116, 14);
		contentPane.add(lblNewLabel);
		
		
		
		
		btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton_1.setBounds(546, 7, 89, 23);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("Homepage");
		btnNewButton_2.setFont(new Font("Traditional Arabic", Font.PLAIN, 11));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.visitHome();
			}
		});
		btnNewButton_2.setBounds(546, 41, 89, 23);
		contentPane.add(btnNewButton_2);
		
	}
}
